# Registro de evolución técnica del proyecto

**Continuidad del frente IA:** [RETP-145](#retp-145), enlace público lote–G1 conforme intraproceso. Siguiente objeto G2: correspondencia con operación gobernada existente. Workflow V2 vigente; trazabilidad integral, reserva y garantías materiales pendientes.

**Antecedente de relevo de fila 7:** [RETP-105](#retp-105), integración y entrega representacional de fila 7 a Ciberseguridad; efecto registral al incorporarse este asiento a main. Los estados anteriores conservan su corte.
| RETP-2026-103 | 08/09/2026 | — | ADVERSARIAL_Y_CORRECCION | Fila 7 / fronteras de verificación | ADVERSARIAL_CONCLUIDA_CORRECCIONES_VERIFICADAS_NO_PROMOVIDAS |
| RETP-2026-104 | 08/09/2026 | — | FIJACION_DE_MATRIZ_REVISADA | Fila 7 / integridad documental | MATRIZ_REVISADA_FIJADA_Y_VERIFICADA_NO_PROMOVIDA |

## 1. Finalidad

Este documento ofrece la lectura humana del tramo vigente del historial técnico del Lenguaje SV. El archivo `REGISTRO_EVOLUCION_TECNICA_PROYECTO.csv` mantiene la numeración RETP y la relación completa de asientos.

El detalle comprendido entre `RETP-2026-000` y `RETP-2026-047` permanece preservado en:

`docs/calidad/historico/REGISTRO_EVOLUCION_TECNICA_PROYECTO_HASTA_RETP_2026_047.md`.

La continuidad documental se organiza así:

`histórico 000–047 → registro vigente desde 048 → CSV maestro de numeración`.

## 2. Tabla del tramo vigente

| ID | Fecha | Hora | Tipo | Ámbito / fase | Estado |
|---|---|---|---|---|---|
| RETP-2026-048 | 18/08/2026 | 11:34:13 | REAPERTURA_GOBERNADA | Lenguaje SV / Ruta A / retorno a FFL-A | cerrado |
| RETP-2026-049 | 18/08/2026 | 11:58:10 | CIERRE_BLOQUE_Y_APERTURA_SECUENCIAL | Lenguaje SV / FFL-A → FFL-B | cerrado |
| RETP-2026-050 | 18/08/2026 | 12:28:08 | DECISION_GOBIERNO_TECNICO | Lenguaje SV / FFL-B / materialización diagnóstica subordinada | cerrado |
| RETP-2026-051 | 18/08/2026 | 13:05:54 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J2.2 parcial / E112 | cerrado |
| RETP-2026-052 | 18/08/2026 | 13:15:04 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J2.3 / E113 | cerrado |
| RETP-2026-053 | 18/08/2026 | 13:25:03 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J4.3 / E307 | cerrado |
| RETP-2026-054 | 18/08/2026 | 13:30:27 | SORPRESA_TECNICA_Y_REVERSION | Lenguaje SV / FFL-B / primer intento E406 revertido | cerrado |
| RETP-2026-055 | 18/08/2026 | 21:35:25 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / P0-A / estado evaluable | cerrado |
| RETP-2026-056 | 18/08/2026 | 21:35:25 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / P0-B / J3.3 / E212-E211 | cerrado |
| RETP-2026-057 | 18/08/2026 | 22:11:00 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J4.3 / E406 | cerrado |
| RETP-2026-058 | 19/08/2026 | 06:32:40 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J1.4 / E011 | cerrado |
| RETP-2026-059 | 19/08/2026 | 07:03:00 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / proyección estructural / E213-E214 | cerrado |
| RETP-2026-060 | 19/08/2026 | 09:21:19 | RECEPCION_DOCTRINAL_LATENTE | Lenguaje SV / fundamentos / no clausura certificada | cerrado |
| RETP-2026-061 | 19/08/2026 | 12:04:50 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / `resolve` / E206-E207 efectivos | cerrado |
| RETP-2026-062 | 19/08/2026 | 20:40:45 | CORRECCION_ESTRUCTURAL | Lenguaje SV / FFL-B / `graph_decl` | cerrado |
| RETP-2026-063 | 19/08/2026 | 21:11:57 | CAMBIO_DOCUMENTACION_PUBLICA | Lenguaje SV / documentación principal | cerrado |
| RETP-2026-064 | 19/08/2026 | 21:31:26 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J2.3 / régimen `Simple` / E114 | cerrado |
| RETP-2026-065 | 19/08/2026 | 21:50:14 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J3.3 / `Supervisable` | cerrado |
| RETP-2026-066 | 19/08/2026 | 22:18:33 | SINCRONIZACION_REGISTRAL_Y_CALIDAD | Lenguaje SV / calidad / actualización de registros | cerrado |
| RETP-2026-067 | 19/08/2026 | 22:31:48 | CAMBIO_FUNCIONAL_GOBERNADO | Lenguaje SV / FFL-B / J3.2 parcial / firma de `gate` / E215 | cerrado |
| RETP-2026-068 | 19/08/2026 | 23:40:14 | CIERRE_BLOQUE_Y_SINCRONIZACION_REGISTRAL | Lenguaje SV / cierre de FFL-B / deuda técnica delimitada | cerrado |
| RETP-2026-069 | 20/08/2026 | 07:23:44 | APERTURA_BLOQUE_Y_PREPARACION_PROBATORIA | Lenguaje SV / FFL-C / pruebas y evidencia | cerrado |
| RETP-2026-070 | 20/08/2026 | 08:16:26 | CIERRE_BLOQUE_Y_SINCRONIZACION_DE_EVIDENCIA | Lenguaje SV / FFL-C / cierre probatorio | cerrado |
| RETP-2026-071 | 29/08/2026 | NO_CONSTA | INTEGRACION_PUBLICACION_Y_CIERRE_DE_CONFORMIDAD | Lenguaje SV / Beta B2 / realización estable bilingüe / cierre DFL-007 | cerrado |
| RETP-2026-072 | 04/09/2026 | 22:04:26 | FIJACION_ARQUITECTONICA | Lenguaje SV / arquitectura de software / núcleo, frontera y host | cerrado |
| RETP-2026-073 | 05/09/2026 | 13:42:20 | FIJACION_RESTRICCIONES_DE_DISENO | Lenguaje SV / pilares / frontera de autoridad dominio-agente-núcleo | cerrado |
| RETP-2026-074 | 05/09/2026 | 14:56:55 | CIERRE_INTRINSECO_GOBERNADO | Lenguaje SV / N0-01 / unicidad de `Codomain` | cerrado |
| RETP-2026-075 | 06/09/2026 | NO_CONSTA | FIJACION_ARQUITECTONICA_Y_SUFICIENCIA_DE_CIERRE | Lenguaje SV / perfiles / contratos / ensamblaje / frontera | cerrado_documental |
| RETP-2026-076 | 06/09/2026 | NO_CONSTA | ACTUALIZACION_RECTORA_DE_CONTINUIDAD | Lenguaje SV / cierre nuclear / retornos IMM-CYB / perfiles / R2-R4 | cerrado_documental |
| RETP-2026-077 | 06/09/2026 | 22:26:33 | RECEPCION_Y_RECONCILIACION_GOBERNADA | Lenguaje SV / PR61 / N0-01 / relevo a oráculos | recepción delimitada; promoción por PR61 |
| RETP-2026-078 | 06/09/2026 | NO_CONSTA | REPARACION_DE_ORACULOS | Lenguaje SV / fila 2 / PT02-PT04-PT13 | reparación delimitada; promoción por candidata exacta |
| RETP-2026-079 | 06/09/2026 | NO_CONSTA | CIERRE_INTRINSECO_GOBERNADO | Lenguaje SV / K1 / N0-02 | cierre relacional delimitado; promoción por candidata exacta |
| RETP-2026-080 | 06/09/2026 | NO_CONSTA | CIERRE_INTRINSECO_GOBERNADO | Lenguaje SV / K1 / N0-03 | cierre de proyección delimitado; promoción por candidata exacta |
| RETP-2026-081 | 07/09/2026 | NO_CONSTA | CIERRE_INTRINSECO_GOBERNADO | Lenguaje SV / K1 / N0-04 | cierre referencial delimitado; promoción por candidata exacta |
| RETP-2026-082 | 07/09/2026 | NO_CONSTA | RETIRADA_GOBERNADA_Y_CONTINUIDAD | Lenguaje SV / oráculos / K1 | retirada delimitada; promoción por candidata exacta |
| RETP-2026-083 | 07/09/2026 | NO_CONSTA | CIERRE_INTRINSECO_GOBERNADO | Lenguaje SV / K1 / BridgeSet | cierre limitado; promoción por candidata exacta |
| RETP-2026-084 | 07/09/2026 | NO_CONSTA | DICTAMEN_Y_CIERRE_INTRINSECO | Lenguaje SV / K1 / Horizon.events | cierre limitado; promoción por candidata exacta |
| RETP-2026-085 | 07/09/2026 | NO_CONSTA | RECEPCION_DOCUMENTAL | Lenguaje SV / K1 / Documento III | cotejo delimitado; promoción por candidata exacta |
| RETP-2026-086 | 07/09/2026 | NO_CONSTA | DICTAMEN_Y_CIERRE_NOMINAL | Lenguaje SV / K1 / Domain.parameters | cierre nominal; promoción por candidata exacta |
| RETP-2026-087 | 07/09/2026 | NO_CONSTA | CIERRE_CORRECTIVO_Y_CONCORDANCIA | Lenguaje SV / K1 / DFL-010 | cierre delimitado; promoción por candidata exacta |
| RETP-2026-088 | 07/09/2026 | NO_CONSTA | DELIMITACION_GOBERNADA_Y_RELEVO | Lenguaje SV / K1-T → F | ruta productiva no habilitada; salida acotada tras candidata verificada |
| RETP-2026-089 | 07/09/2026 | NO_CONSTA | CONTRATO_CANDIDATO_Y_RELEVO | Lenguaje SV / F → F-IF | contrato por operación; ligaduras, suficiencia y pérdida localizadas; contraste pendiente |
| RETP-2026-090 | 07/09/2026 | NO_CONSTA | CONTRASTE_SINTETICO_Y_RELEVO | Lenguaje SV / F-IF → G-H | seis espacios documentales; pérdida por operación; relevo IMM tras candidata verificada |
| RETP-2026-091 | 07/09/2026 | NO_CONSTA | RECEPCION_DOCUMENTAL | Lenguaje SV / fila 7 | Recepción G/H: suficiencia no acreditada para ejecutar Q0 |
| RETP-2026-092 | 07/09/2026 | NO_CONSTA | MANDATO_Y_RESTAURACION_DOCUMENTAL | Lenguaje SV / fila 7 | Español obligatorio y revisión integral final: DFL-011 |
| RETP-2026-093 | 07/09/2026 | NO_CONSTA | CORRECCION_LOCAL_Y_COBERTURA | Lenguaje SV / fila 7 | TransitionData: cierre local candidato H04/H05 y corpus compartido 14+95 |
| RETP-2026-094 | 08/09/2026 | NO_CONSTA | CORRECCION_DE_ORACULO_Y_REGISTROS | Lenguaje SV / fila 7 | E115: cuatro causas discriminadas y prueba de intercambio |
| RETP-2026-095 | 08/09/2026 | NO_CONSTA | CORRECCION_DE_TESTIGO_Y_ORACULO | Lenguaje SV / fila 7 | CANDIDATA_VERIFICADA_NO_PROMOVIDA |

## 3. Entradas detalladas

### RETP-2026-048 — Reapertura por Ruta A

- **Hecho:** se levanta la pausa preventiva del 16/08/2026 en el alcance autorizado y FFL-A pasa a ser la prioridad inmediata.
- **Fundamento:** las comprobaciones previas sobre continuidad semántica y arquitectónica no muestran un bloqueo del ámbito técnico inmediato.
- **Decisión:** reabrir únicamente desde FFL-A y mantener sin apertura los bloques posteriores no autorizados.
- **Estado:** cerrado.

### RETP-2026-049 — Cierre de FFL-A y apertura secuencial de FFL-B

- **Hecho:** FFL-A se cierra bajo Vía B con deuda residual explícita; FFL-B pasa a ser el único bloque técnico activo.
- **Fundamento:** la matriz diagnóstica y la tabla de correspondencias funcionales permiten localizar la divergencia restante sin exigir igualdad nominal completa entre la IR y el catálogo efectivo.
- **Decisión:** mantener FFL-C, FFL-D y FFL-E sin apertura mientras no exista una decisión posterior expresa.
- **Estado:** cerrado.

### RETP-2026-050 — Regla de materialización diagnóstica de FFL-B

- **Hecho:** FFL-B queda limitado a obligaciones ya representables, con fundamento normativo expreso, diagnóstico inequívoco y prueba trazable.
- **Decisión:** todo nuevo diagnóstico efectivo deberá conservar la correspondencia entre definición, emisión, prueba y documentación pública.
- **Estado:** cerrado.

### RETP-2026-051 — J2.2 parcial / E112

- **Hecho:** `CoupledState` sólo puede diferir de su vector de partida en posiciones pertenecientes al `BridgeSet` declarado.
- **Límite:** no queda acreditada la procedencia completa de cada actualización desde un `Connector` concreto.
- **Decisión:** cerrar únicamente la condición posicional mediante `E112`.
- **Estado:** cerrado.

### RETP-2026-052 — J2.3 / E113

- **Hecho:** se comprueban la posición puente de la arista, su concordancia con `Connector.target_position` y la compatibilidad del codominio de la célula transmisora con el conector.
- **Decisión:** utilizar `E113 — EdgeConnectorMismatch` como diagnóstico efectivo de estas incompatibilidades y mantener separada la numeración definida en la IR.
- **Estado:** cerrado.

### RETP-2026-053 — J4.3 / E307

- **Hecho:** cada tipo de suceso de `TransitionData.events` debe pertenecer al `Horizon` referido.
- **Decisión:** materializar esta condición mediante `E307`, sin ampliar la semántica de sucesos.
- **Estado:** cerrado.

### RETP-2026-054 — Incidencia técnica y reversión del primer intento E406

- **Hecho:** la primera modificación destinada a E406 fue revertida porque la comparación de cambios excedía el alcance necesario.
- **Decisión:** restaurar el estado anterior y exigir una modificación estrictamente acotada antes de reintentar E406.
- **Estado:** cerrado.

### RETP-2026-055 — P0-A / estado evaluable

- **Hecho:** `evaluate` acepta `CellState` y `CoupledState`, mientras `Frame.cell_states` conserva exclusivamente `CoupledState`.
- **Evidencia:** conformidad **42/42**, interfaz de línea de órdenes **3/3** y SEC-0 **3/3**.
- **Decisión:** preservar la distinción entre estado simple y estado acoplado.
- **Estado:** cerrado.

### RETP-2026-056 — P0-B / J3.3 / E212-E211

- **Hecho:** `supervise.meta_eval` debe ser un `EvalResult`; `E212` protege el tipo y `E211` la procedencia desde una célula con rol `Supervisor`, incluida la ruta mediante `CoupledState`.
- **Evidencia:** conformidad **44/44**, interfaz de línea de órdenes **3/3** y SEC-0 **3/3**.
- **Decisión:** mantener separados el error de tipo y el error de procedencia.
- **Estado:** cerrado.

### RETP-2026-057 — J4.3 / E406

- **Hecho:** `E406 — InsufficientTransitionData` rechaza `TransitionData` con `induced_parameters` vacío.
- **Evidencia:** conformidad **45/45**, interfaz de línea de órdenes **3/3** y SEC-0 **3/3**.
- **Límite:** una lista no vacía no demuestra por sí sola la suficiencia para reconstruir el operador inducido.
- **Estado:** cerrado.

### RETP-2026-058 — J1.4 / E011

- **Hecho:** cada salida literal de `AdmissibilityTable.table` debe pertenecer al `output_codomain` declarado.
- **Evidencia:** conformidad **46/46**, interfaz de línea de órdenes **3/3** y SEC-0 **3/3**.
- **Límite:** la condición no agota J1.4 ni acredita ejecución material de `GateResult`.
- **Estado:** cerrado.

### RETP-2026-059 — Proyección estructural / E213-E214

- **Hecho:** `E213` exige una fuente que produzca un resultado proyectable y `E214` exige que el campo pertenezca al esquema del resultado correspondiente.
- **Evidencia:** conformidad **48/48**, interfaz de línea de órdenes **3/3** y SEC-0 **3/3**.
- **Límite:** la comprobación no ejecuta el resultado ni calcula el valor proyectado.
- **Estado:** cerrado.

### RETP-2026-060 — Recepción latente de no clausura certificada

- **Hecho:** la publicación «No clausura certificada en sistemas finitos de resolución» queda recibida con estatuto `LATENTE_LEGITIMO`, sin modificación de código, gramática ni IR.
- **Fundamento:** DOI `10.21428/39829d0b.f0892864` y documentación de fundamentos del Sistema SV.
- **Evidencia temporal:** commit `be68345d…`, 19/08/2026 a las **09:21:19** (Europe/Madrid).
- **Decisión:** preservar la recepción sin traducirla automáticamente a construcciones del lenguaje.
- **Estado:** cerrado.

### RETP-2026-061 — E206/E207 efectivos en `resolve`

- **Hecho:** `E206 — ResolveMissingContext` y `E207 — ResolveMissingMechanism` son diagnósticos efectivos para la ausencia de `context` y `mechanism` en la forma superficial de `resolve`.
- **Evidencia:** conformidad **50/50**, interfaz de línea de órdenes **3/3** y SEC-0 **3/3**; lote funcional `02dc7c4e…` a las **12:04:50** (Europe/Madrid). La integración documental posterior se produjo a las 19:02:26 y no sustituye la hora del hito funcional.
- **Límite:** no se cierra J1.6, no se tipan `Context` ni `Mechanism` y no se ejecuta una resolución material de `U`.
- **Estado:** cerrado.

### RETP-2026-062 — Retirada de `conflicts` de `graph_decl`

- **Hecho:** `conflicts` deja de formar parte de `graph_decl`, `GraphDecl` y del descenso a IR. `CompositionGraph` conserva `nodes`, `edges`, `relation` y `regime`.
- **Fundamento:** la definición de `CompositionGraph` no contiene ese campo y la superficie v0.1 no dispone de una declaración completa de `ConflictOperator`.
- **Evidencia:** commit `058befbd6402c80ac7bc1d10eab0d8d035126531`; conformidad **51/51**, interfaz de línea de órdenes **3/3**, SEC-0 **3/3** y `graph_conflicts_fuera_de_v0_1.svp` → `E001`.
- **Límite:** la retirada del campo no materializa `MissingConflictOperator` ni elimina el régimen `General`.
- **Estado:** cerrado.

### RETP-2026-063 — Actualización del README principal

- **Hecho:** el README principal se actualiza para reflejar el estado técnico vigente, conservar los fundamentos y antecedentes médicos del Sistema SV, mantener la dedicatoria final y ofrecer una orientación pública acorde con el repositorio actual.
- **Evidencia:** commits `e0a58ea6af6a370960b244e9c9f06636994523d6` y `a2c4cdfdc17408ce6a989a8a1c52a8b3ff7d5e02`; la comparación respecto del estado anterior afecta únicamente a `README.md`.
- **Límite:** la actualización documental no modifica la implementación, la gramática, la IR ni el contrato diagnóstico.
- **Estado:** cerrado.

### RETP-2026-064 — J2.3 / régimen `Simple` / E114

- **Hecho:** en régimen `Simple`, cada par `(target, position)` puede recibir como máximo una arista; la concurrencia se rechaza mediante `E114 — SimpleRegimeConcurrency`.
- **Evidencia:** commit `0911d246050a9f739a3b8235f3bfd861584b4273`; conformidad **52/52**, interfaz de línea de órdenes **3/3**, SEC-0 **3/3** y emisión exacta de E114.
- **Límite:** la comprobación no se extiende al régimen `General`; `MissingConflictOperator` permanece sin materializar.
- **Estado:** cerrado.

### RETP-2026-065 — Contenido estructural de `Supervisable`

- **Hecho:** `CellTarget` exige un `EvalResult`, `ComposedTarget` un `GateResult` y `SystemTarget` un `CompositionGraph`. Una referencia existente de tipo incompatible se rechaza mediante `E006`; `E205` continúa reservado a la exigencia de constructor explícito.
- **Evidencia:** commit `59e055ea8a66437c91558e1e8096eb5c6e670b8c`; conformidad **55/55**, interfaz de línea de órdenes **3/3**, SEC-0 **3/3** y tres casos negativos específicos con E006.
- **Límite:** no se cierra la semántica completa de J3.3. La aceptación positiva de `SystemTarget(CompositionGraph)` fue comprobada de forma adicional, pero en este hito todavía no disponía de un caso válido específico conservado en la batería principal.
- **Decisión:** cerrar únicamente la correspondencia estructural entre cada constructor y su contenido.
- **Estado:** cerrado.

### RETP-2026-066 — Sincronización de los registros de calidad

- **Hecho:** los documentos vivos de calidad se actualizan para incorporar RETP-062 a RETP-065, reflejar la conformidad **55/55**, registrar las limitaciones todavía abiertas y corregir el tablero de bloques.
- **Fundamento:** el registro de evolución terminaba en RETP-061, la deuda viva no recogía E114 ni el tipado de `Supervisable`, el README de calidad mantenía **52/52** y el tablero mostraba FFL-C, FFL-D y FFL-E como abiertos pese a la secuencia vigente.
- **Evidencia temporal:** commit `359c61bc…`, 19/08/2026 a las **22:18:33** (Europe/Madrid).
- **Alcance:** sólo se modificaron documentos de `docs/calidad/`; el historial CSV hasta RETP-061 se conservó sin alteración.
- **Decisión:** mantener FFL-B como único bloque técnico activo y FFL-C, FFL-D y FFL-E en estado pendiente hasta decisión expresa.
- **Estado:** cerrado.

### RETP-2026-067 — Firma posicional de `gate` / E215

- **Hecho:** `E215 — GateTableSignatureMismatch` exige que la secuencia de `EvalResult` recibida por `gate` coincida, en número y codominio por posición, con `AdmissibilityTable.input_codomains`.
- **Fundamento:** la IR v0.2 conserva la firma ordenada de codominios de entrada y la implementación ya permite obtener el codominio de cada evaluación desde `CellState` o `CoupledState`.
- **Evidencia:** commit `15398f3441c80168f5d09866b0cba4e74221a6aa`; conformidad **57/57**, interfaz de línea de órdenes **3/3**, SEC-0 **3/3**; dos casos negativos específicos con E215 y comprobaciones positivas adicionales.
- **Límite:** la validación no ejecuta la tabla ni calcula `GateResult.output`.
- **Decisión:** cerrar únicamente la firma estructural de entrada de `gate`.
- **Estado:** cerrado.

### RETP-2026-068 — Cierre de FFL-B

- **Hecho:** FFL-B se cierra tras E215 y la revisión final de las obligaciones restantes.
- **Fundamento:** las obligaciones todavía abiertas identificadas exigen ampliar representación, semántica o ejecución: `ConflictOperator` en régimen `General`, procedencia completa de `CoupledState`, suficiencia reconstructiva de `TransitionData`, producción de `CriticalityResult`, ejecución de `GateResult.output` y semántica ejecutiva completa de `SupervisionResult`.
- **Evidencia:** base funcional `15398f3441c80168f5d09866b0cba4e74221a6aa`; conformidad **57/57**, interfaz de línea de órdenes **3/3** y SEC-0 **3/3**; deuda viva y tablas de correspondencias actualizadas; commit documental `d7b15e9…` a las **23:40:14** (Europe/Madrid).
- **Decisión:** cerrar FFL-B con deuda técnica explícita y mantener FFL-C, FFL-D y FFL-E en estado pendiente. Cualquier reapertura o apertura posterior requerirá decisión expresa y fundamento técnico identificable.
- **Estado:** cerrado.

### RETP-2026-069 — Apertura y preparación probatoria de FFL-C

- **Hecho:** FFL-C se abre para comprobar la suficiencia de la evidencia reproducible, con escritura funcional limitada a `tests/` y modo de solo lectura sobre `src/`, gramática, AST, IR, validador, catálogo diagnóstico y manual.
- **Fundamento:** FFL-B estaba cerrado y el tablero exigía una decisión expresa antes de activar el bloque de pruebas y evidencia.
- **Evidencia:** commit de apertura `910af1dd0c7ba1f811f4b77a7872626e1c3e695d` a las **07:23:44**; caso permanente `SystemTarget(CompositionGraph)` en `a0af722b0ba51cabd5d5fea9c7d719d3ba775e5d`; caracterización de E006 en `1e7ffa795fe0528888834dd35d09c321cb00c9f3`; inventario de cobertura en `3d48c422915b0e0bed65ba2e7ce8b807d7a94c33`.
- **Límite:** no se modifica implementación, gramática, IR, validador, catálogo diagnóstico ni manual.
- **Decisión:** persistir únicamente las comprobaciones que acreditan afirmaciones técnicas ya existentes y clasificar las ausencias de cobertura sin ampliar el lenguaje.
- **Estado:** cerrado.

### RETP-2026-070 — Cierre de FFL-C

- **Hecho:** una verificación independiente en modo de solo lectura ejecuta las cuatro baterías sobre `3d48c422915b0e0bed65ba2e7ce8b807d7a94c33`, con árbol limpio antes y después y código de retorno 0 en todos los ejecutores.
- **Evidencia:** conformidad **58/58** — 10 casos válidos y 48 inválidos; pruebas rápidas de la interfaz de línea de órdenes **3/3**; SEC-0 **3/3**; caracterización de E006 **4/4**; ausencia de divergencias de resultado.
- **Cobertura:** los 48 casos inválidos cubren directamente 37 de los 47 códigos efectivos. Los diez restantes se clasifican por inalcanzabilidad desde la superficie vigente, ruta diagnóstica alternativa o preservación estructural, sin fabricar casos mediante ampliación del lenguaje.
- **Límite:** la evidencia no ejecuta `GateResult.output`, no materializa la semántica completa de supervisión, no incorpora `ConflictOperator` ni produce `CriticalityResult`. La deuda de precisión de E006 permanece documentada.
- **Decisión:** cerrar FFL-C y mantener FFL-D y FFL-E pendientes, sin apertura automática de ningún bloque posterior.
- **Estado:** cerrado.

### RETP-2026-071 — Integración, publicación y cierre de conformidad de B2

- **Hecho:** B2 queda integrada y publicada como realización estable bilingüe `SVP-ES` / `SVP-EN`; se cierran los dominios gramaticales DG-01, DG-02 y DG-03 sobre identidad canónica, se constituye normativamente la capa de perfiles fuente, se corrige la navegación efectiva del Historial Beta y se completan las reconciliaciones DD-01 y VH-01 exigidas por DFL-007.
- **Fundamento:** la verificación ampliada de B2 descubrió huecos heredados de conformidad gramatical y desajustes documentales que afectaban a una base previamente cerrada. El cierre exige corrección material, regresión permanente, reconciliación normativa y revalidación de dependencias, no la mera publicación del artefacto.
- **Evidencia:** PR #55; corte de realización `c1acf943a7a44ce81080881e59283de8a2019606`; WebAssembly `378956` bytes, SHA-256 `95c7d1e0313567ef099c6e426a7fcee8ff4a5ac8adb670265f859f1bf03caab3`; paquete de despliegue `167503` bytes, SHA-256 `566200f97bfea86a0b7ce7c4919bac9d5367a67b8cba719eef1c573942d696f5`; conformidad 79/79; `sv_core` 210/210; dominios cerrados 5/5; seis sondas DG en navegador; `sv_wasm` 2/2; documentación ejecutable 17/17; comprobación material del Historial Beta; acta de conformidad de 29/08/2026.
- **Decisión:** cerrar DFL-007, re-cerrar el perímetro R0 afectado, revalidar R1 y levantar únicamente la suspensión de R2 causada por esa deuda. R2 recupera su estado abierto previo.
- **Límites:** `ConflictOperator` y J2.3 para concurrencia en régimen `General` permanecen abiertos; R2 no queda cerrado; R3 y R4 no se inician; Garantía I y Garantía II permanecen `NO_PROBADO`; la verificación externa independiente del corte final se registrará por separado.
- **Criterio registral:** el ciclo B2 se registra como un único hito material; el detalle mecánico de sus correcciones permanece en Git y en la evidencia enlazada.
- **Estado:** cerrado.

### RETP-2026-072 — Arquitectura de software: núcleo, frontera y host

- **Hecho:** se constituye un único núcleo semántico en Rust, un contrato de frontera canónico pendiente de especificación y un host operacional desacoplado. WebAssembly es candidata inicial no exclusiva; .NET es candidata de host; FFI permanece condicionada a necesidad y prueba.
- **Fundamento:** la integración hospitalaria, la periferia conectada y la ciberseguridad exigen responsabilidades explícitas sin trasladar protocolos, conectores ni reglas de dominio al núcleo.
- **Evidencia:** [acta técnica de arquitectura de software](./ACTA_TECNICA_DE_ARQUITECTURA_DE_SOFTWARE_NUCLEO_FRONTERA_Y_HOST_SV_2026_09_04.md); base `main@736ea643d7f65ba4bf26dbbb321383b8becc8d64`; revisión estructural de `PR #61@fafd65b887658d8aecf429aa1fb78b7f78174e92`, incluidos los dos comparadores que aplican `sort_keys=True` y los 68 casos inválidos sin contraejemplo de `failure_symbol != Bottom`.
- **Decisión:** conservar una sola fuente semántica en `sv_core`; especificar la frontera antes de elegir el host; mantener plataforma, ABI, conectores y persistencia sujetos a prototipo, licencias y comparación reproducible; declarar por separado perfiles fuente, perfiles de dominio y cobertura de agentes.
- **Límites:** no se integra la PR #61, no se abre fase material, no se incorpora el laboratorio privado, no se fija .NET ni WebAssembly como solución definitiva y no se autoriza uso clínico ni datos reales.
- **Estado:** cerrado.

### RETP-2026-073 — Pilares y restricciones de diseño del Lenguaje SV

- **Hecho:** se fija una pieza rectora que preserva la célula exacta como vector plano, ordenado y posicional de longitud `n=b²`; separa `U` de cualquier fallo o relleno; y delimita la autoridad entre las unidades de dominio, las unidades de agente, el Lenguaje, la frontera, el host y cualquier IA auxiliar. La raíz incorpora `AGENTS.md` como puerta operativa de lectura obligatoria, identificación del corte y detención ante contradicción.
- **Fundamento:** la realización vigente acredita `b≥3`, la derivación de `n` y la longitud del vector, pero no representa todavía el contrato completo dominio→células→agente. Esa ausencia no puede permitir que el núcleo decida tamaños, distribuya inventarios, rellene posiciones o acepte en silencio una constitución incompleta.
- **Evidencia:** [Pilares y restricciones de diseño](./PILARES_Y_RESTRICCIONES_DE_DISENO_DEL_LENGUAJE_DE_COMPUTACION_SV_2026_09_05.md); `AGENTS.md`; base `main@ec00a5464239df081d0165fd09a1b738c579555b`; inspección de `frontend.rs`, `ir.rs`, `wellformed.rs`, `svp_validator.py`, `svp_ir.py` e IR v0.3; contraste con los fundamentos algebraico-semánticos, la doctrina de `U` y la arquitectura general de agentes especializados.
- **Decisión:** el dominio constituye sus células y asignaciones; el agente recibe esa constitución y declara cobertura y capacidades; el Lenguaje valida y preserva sin suplantar. Se prohíben inferencia, redondeo, relleno, reordenación, reparación silenciosa y conversión de fallos a `U`. La ausencia de representación se declara como obligación pendiente.
- **Límites:** no se elige `b` para ningún dominio, no se decide el número de células, no se asignan parámetros, no se constituye un bus o un perfil central, no se selecciona host y no se abre fase material. La ejecución algebraica completa en `sv_core` permanece no acreditada.
- **Corrección registral:** se repara la serialización CSV de `RETP-2026-072`, que había quedado encapsulada como una sola celda, sin alterar su contenido material.
- **Estado:** cerrado.

### RETP-2026-074 — N0-01: unicidad de `Codomain`

- **Hecho:** se impone en Python y Rust que `Codomain` sea una secuencia finita explícita, no vacía y sin miembros repetidos. El incumplimiento produce `E004 (InvalidCodomain)` y el ensamblaje falla cerrado.
- **Fundamento:** la semántica de conjunto de `Codomain` no admite repetición. Aceptarla permitiría una representación ambigua o con pérdida y divergencias entre realizaciones.
- **Evidencia:** [radiografía N0](../arquitectura/N0_RADIOGRAFIA_DE_OBJETOS_INVARIANTES_Y_ORACULOS_DEL_NUCLEO_SV_2026_09_04.md); [acta N0-01](../arquitectura/ACTA_TECNICA_N0_01_UNICIDAD_DE_CODOMAIN_2026_09_04.md); base `main@230a205b08f4c54c9c8d9c1c7ad35b2f6ddbbfc4`; sincronización `c1975b9077284aeb240378ff00cd1253e25495b2`; verificación local Python: conformidad 80/80, CLI 3/3, caracterización E006 4/4 y `compileall`; cabeza final `a4f00b96809e48ecc1c4b01da17bf9ef24400cdf`: Conformidad SVP #277 (`33967778938`), R0 Rust #206 (`33967778943`), R0-8 Baseline nativa #157 (`33967779060`) y R0 WASM paridad de tres vías #152 (`33967778928`), todas `success`. La adversarial posterior confirma N0-01 e individualiza fuera de su radio `E107/J1.5`, la repetición de `BridgeSet`, la multiplicidad de `Horizon.events` y la identidad diagnóstica Rust textual.
- **Decisión:** mantener N0-01 como invariante intrínseco y representable; no reparar ni reordenar el codominio; no extender el cierre a orden, totalidad de salida ni N0-02 y siguientes.
- **Límites:** no decide células, valores de `b`, parámetros, dominios, agentes, bus, host u operación algebraica; no acredita ejecución soberana adicional en `sv_core`. Tampoco cierra por analogía `Ternarizer`, `BridgeSet`, la multiplicidad de `Horizon.events` ni la estructuración de diagnósticos Rust; esos extremos quedan individualizados en la radiografía y DFL-001.
- **Estado:** cerrado.
### RETP-2026-075 — Perfiles, contratos y ensamblaje: suficiencia para el cierre

- **Hecho:** se fija en Calidad el marco canónico de representación, dominio y soporte tecnológico, con identidades, versiones y contratos distintos; se delimitan los tres ensamblajes, las obligaciones de suficiencia que deben llegar al Lenguaje antes de su cierre y la prueba previa en laboratorio de las realizaciones tecnológicas.
- **Fundamento:** Pilares y arquitectura RETP-072/073; perfiles fuente ES/EN; contrato FFL-E de suficiencia representacional por operación; transición desde OP-IMM-001; secuencia N0; candidata y matriz del registro experimental 020.
- **Evidencia:** [acta canónica](./ACTA_TECNICA_DE_PERFILES_CONTRATOS_Y_ENSAMBLAJE_DEL_LENGUAJE_SV_2026_09_06.md); base main 230a205b08f4c54c9c8d9c1c7ad35b2f6ddbbfc4; PR61 ad8e8dd30930e35b75bf5f2fad78938d36233b78; laboratorio e97fed715ff5e3ae19bbaccaf2852e9cd3288377; publicación 566aef09824f080c5cc09722223b5ac7327a32b4. Lectura y contraste documental, actualización de AGENTS.md y entradas prioritarias; ninguna nueva campaña material acredita esta acta.
- **Decisión:** exigir encaje contractual y suficiencia demostrable para las operaciones incluidas en el cierre; recibir evidencia tecnológica previa con su alcance; reutilizar artefactos y oráculos existentes; mantener una sede canónica y su vínculo desde Documentación de laboratorios.
- **Límites:** no añade tipos a la DSL/IR, no implementa álgebra, no selecciona host o ABI, no constituye dominio/agente, no integra R1 con el laboratorio ni cierra fases operacionales. Las realizaciones y garantías conservan sus propios estados.
- **Numeración y continuidad:** RETP-074 ya está asignado a N0-01 en la PR #61 pendiente de integración; se conserva esa identidad sin importar su asiento ni presentar su cambio como incorporado a main. RETP-075 corresponde exclusivamente a esta fijación documental.
- **Estado:** cerrado en su alcance documental.

### RETP-2026-076 — Secuencia rectora desde PR #61 y obligaciones tecnológicas por etapa

- **Hecho:** se actualiza el acta de transición desde OP-IMM-001 mediante adenda rectora de continuidad, sin sustituir el expediente histórico ni crear otra acta paralela.
- **Fuentes:** transición integrada, radiografía N0 del head ad8e8dd30930e35b75bf5f2fad78938d36233b78, actas privadas R0/R1 V2 conservadas en el laboratorio (registro 024), Pilares RETP-073, arquitectura RETP-072/073, perfiles RETP-075, matriz tecnológica 020 y contratos R2-0/entorno soberano.
- **Decisión:** conservar PR61/N0-01 → oráculos → K1 → F/F-IF → G/H IMM → incorporación Lenguaje → I/J CYB → resolución Lenguaje → puerta algebraica con K1-T → comprobación IMM/CYB → K2 → contrato operacional → consolidación; después, realización R2/R3/R4 y agentes en el alcance y dependencias que les correspondan. Distribuir PT01–PT14 por cada punto, reutilizando evidencia y exigiendo ensayo previo de las realizaciones a promover.
- **Precisión:** N1/N2 son niveles de IR; no se inventan fases con esos nombres. G/H no constituye cierre integral de todos los universos inmunológicos. R2 conserva su apertura contractual y su ejecución pendiente; R0/R1 conservan sus cierres históricos.
- **Evidencia:** [adenda rectora](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#adenda-secuencia-20260906), main de entrada 605d900fc535aec4b0010820499b93e44d111f5c; custodia privada de antecedentes 20da3c781286bee1966c22cf1fc7a4755be35b9b. Verificación documental de identidad, enlaces, preservación y concordancia registral; sin nueva campaña de ejecución.
- **Límites:** no modifica gramática, IR, código, corpus ni workflows; no fusiona PR61, no abre materialmente R2/R3/R4, no constituye dominio/agente ni selecciona host. La preparación posterior de PR61 debe reconciliar main y conservar 074/075/076.
- **Estado:** cerrado en alcance documental; la secuencia y sus obligaciones no se dan por ejecutadas.

### RETP-2026-077 — Recepción de PR #61 / N0-01 sobre main vigente

- **Hecho:** se reconcilia la cabeza N0-01 `ad8e8dd30930e35b75bf5f2fad78938d36233b78` con main `981159d6428197d1ad1d748649f1d8f690b2f588`, base común `230a205b08f4c54c9c8d9c1c7ad35b2f6ddbbfc4`. Los asientos 074, 075 y 076 conservan íntegros texto e identidad en ambos formatos; 077 registra su recepción, no otro cierre semántico.
- **Fuentes:** AGENTS, Pilares RETP-073, perfiles RETP-075, transición RETP-076, radiografía N0, acta de unicidad y registros aplicables. Las adendas de recepción actualizan la continuación sin borrar los estados históricos.
- **Evidencia:** [acta N0-01 §8](../arquitectura/ACTA_TECNICA_N0_01_UNICIDAD_DE_CODOMAIN_2026_09_04.md#recepcion-20260906): conformidad 80/80, CLI 3/3, E006 4/4, Rust 210+3+5+2 pruebas y 17 documentales, R0-7 12+68, compilación WASM; conservación literal de las doce salidas de cada emisor frente a main y de los doce oráculos comprometidos. El negativo nuevo exige rc=1, E004/InvalidCodomain y ausencia de IR. La identidad de la cabeza reconciliada, sus cuatro controles CI y la integración se documentan en [PR #61](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/pull/61), sin trasladar los verdes antiguos.
- **Perfiles:** PT01/PT04/PT14: candidato y artefactos identificados, diagnóstico y entorno comprobados; ES/EN y ensamblaje conservados en Rust, referencia Python en su alcance vigente. No aplica contenido clínico o CYB. El registro experimental 018 conserva su corpus histórico de 79 y no acredita los 80 ni el ensamblaje de esta PR.
- **Decisión:** recibir exclusivamente unicidad de Codomain, radiografía y deuda asociada. La recepción es efectiva en main cuando PR61 conste fusionada tras los controles de su candidato exacto. La [transición §18](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#recepcion-n0-01-20260906) deja como siguiente paso la reparación de oráculos y, después, K1 desde N0-02.
- **Límites:** la equivalencia JSON normalizada no acredita identidad literal entre emisores, ni un código de salida no nulo demuestra por sí solo el diagnóstico esperado. Esas reparaciones generales siguen en la fila 2. No se modifica adicionalmente el código reconciliado, no se cambian toolchains, no se publica el Playground ni se cierra K1, álgebra, núcleo o R2/R3/R4.
- **Estado:** recepción delimitada; promoción y corte de salida comprobables en el expediente PR61.

### RETP-2026-078 — Reparación de oráculos y continuidad K1

- **Hecho y fundamento:** se reemplaza la comparación JSON que perdía miembros u orden; se capturan bytes y se exige rechazo controlado con retorno 1, ausencia de IR e identidad diagnóstica. Fuente: main `91dc5a3`, Pilares, perfiles, secuencia, N0 y recepción RETP-077.
- **Evidencia:** [acta de oráculos](./ACTA_TECNICA_REPARACION_DE_ORACULOS_2026_09_06.md), 80 casos conservados, 16 pruebas del observador, un control conforme y tres divergencias detectadas; destinos nativo/WASI/navegador según los controles del candidato exacto. Los doce esperados permanecen íntegros.
- **Alcance:** PT02/PT04/PT13, identidad y entorno PT01/PT14. Comprobadores y documentación; la fuente Python, el núcleo Rust, la gramática y la IR conservan su identidad.
- **Límites:** N0-02/N0-03 conservan semántica repetida y proyección; DFL-008 conserva pérdida CRLF; DFL-001 conserva la diferencia de fase y representación diagnóstica. Detectar no cierra estas deudas ni acredita un soporte productivo.
- **Decisión y estado:** reparación efectiva tras promoción del expediente con los cuatro flujos correctos sobre la candidata exacta. La [transición §19](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#oraculos-20260906) deja como siguiente paso K1 desde N0-02.

### RETP-2026-079 — N0-02: relación total y unívoca de OutputSemantics

- **Hecho y fundamento:** sobre main `ed61af2fb80641866356a7138cc87763eab005d9`, tras PR #65, J1.1 y la radiografía N0-02 se concretan en J-K1 de IR v0.3 §6.2. Cada CellSpec exige exactamente una interpretación por miembro de su Codomain. Se conservan textos compartidos y orden independiente; no se infiere ni repara.
- **Realización:** Python y Rust validan la relación antes de emitir su proyección; E115 — InvalidOutputSemantics identifica claves repetidas, ausentes y ajenas. E102 conserva referencia ausente o de tipo incorrecto. Gramática, esquema IR y serializador conservan sus versiones.
- **Evidencia:** [acta N0-02](../arquitectura/ACTA_TECNICA_N0_02_TOTALIDAD_Y_UNICIDAD_DE_OUTPUT_SEMANTICS_2026_09_06.md), corpus 85/85, cinco pruebas Python y seis Rust específicas, 210+3+5+2 pruebas Rust anteriores y 17 documentales; doce salidas por emisor preservadas frente a la base y cuatro nuevos negativos antes admitidos. Los cuatro flujos y la integración se identifican en el expediente asociado a la rama enlazada por el acta.
- **Perfiles:** PT04/PT13/PT14 y conservación PT01/PT02; ES/EN y ensamblaje Rust, referencia EN Python. La evidencia de laboratorio 016/018 mantiene alcance e identidad; no se promueve otra plataforma ni se amplía el corpus histórico de 018.
- **Límites:** N0-03 conserva una semántica duplicada no enlazada como testigo de proyección defectuosa; DFL-008 conserva CRLF y DFL-001 la concordancia diagnóstica general. El banco de sensibilidad v2 exige un control, un rechazo N0-02 y tres divergencias abiertas detectadas, sin sumarlas a conformidad.
- **Decisión y estado:** cierre relacional efectivo al integrar la candidata exacta con los cuatro flujos correctos. La [transición §20](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#cierre-n0-02-20260906) deja N0-03 como siguiente paso dentro de K1. No se cierran K1, álgebra, núcleo ni R2/R3/R4.

### RETP-2026-080 — N0-03: unicidad de miembros y estabilidad de proyección JSON

- **Hecho y fuente:** main `016b2f4d1f896dcbd4e8d177e8db4e736e2cd571`, tras PR #66; radiografía N0-03, oráculos RETP-078/079 y transición §20. La semántica duplicada no enlazada seguía admitida y producía pérdida de miembros en Python y homónimos en Rust.
- **Decisión y realización:** J-J0 en IR v0.3 §6.3 y comprobación complementaria de todas las semánticas, con E115 y precedencia relacional conservada. Se precisa su texto general Python. Los dos mapas variables del esquema quedan identificados; Connector conserva su guarda. No se cambia el emisor ni su versión.
- **Evidencia:** [acta N0-03](../arquitectura/ACTA_TECNICA_N0_03_UNICIDAD_DE_MIEMBROS_Y_ESTABILIDAD_DE_PROYECCION_JSON_2026_09_06.md), corpus 88/88, N0-03 Python 3/3 y Rust 5/5, observador 19/19 y regresiones anteriores correctas. Trece salidas por emisor y trece esperados conservados. El banco v3 conserva cinco fuentes: control, dos rechazos E115 y dos divergencias CRLF detectadas. Los cuatro flujos y la promoción se identifican en el expediente asociado a la candidata enlazada.
- **Perfiles:** PT04/PT13/PT14 con PT01/PT02; ES/EN y ensamblaje Rust, referencia EN Python. Laboratorio 016/018 recibido dentro de sus límites; no se amplía su corpus histórico ni se promueve una plataforma.
- **Límites:** el recorrido JSON no constituye un importador de IR ni un serializador canónico Rust completo. DFL-001 y DFL-008 siguen abiertas; las pruebas no acreditan suficiencia operacional universal ni una demostración mecanizada de todos los programas.
- **Estado y relevo:** cierre efectivo al integrar la candidata exacta con los cuatro flujos correctos. La [transición §21](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#cierre-n0-03-20260906) fija N0-04 como siguiente trabajo de K1. No se cierra K1, núcleo o R2/R3/R4.

### RETP-2026-081 — N0-04: referencia real de arquitectura del horizonte

- **Fuente y decisión:** main `f9aa3ebada0db222bb9d196f94a9b42dac185f97`, PR #67; Pilares, perfiles, secuencia §21 y radiografía N0-04. J-H0 precisa la resolución de `ArchitectureId` de IR v0.2 como `CompositionGraph` declarado y bien formado.
- **Realización:** resolutores existentes Python/Rust, aplicados a todos los horizontes después de validaciones previas. Agent conserva su comprobación de igualdad con el horizonte del dominio; la admisión completa exige referente real. E006/E402 y rechazos textuales Rust mantienen su contrato; 51 códigos, misma gramática, esquema IR y emisores.
- **Evidencia:** [acta N0-04](../arquitectura/ACTA_TECNICA_N0_04_REFERENCIA_REAL_DE_ARQUITECTURA_DEL_HORIZONTE_2026_09_07.md), corpus 91/91, cuatro pruebas Python y cinco Rust; regresiones previas correctas. Trece positivos y 74 negativos conservan salidas literales por vía; se declara el positivo histórico colgante y la corrección de su fuente/esperado. Cinco sondas de sensibilidad conservadas.
- **Perfiles:** PT04/PT13/PT14 con PT01/PT02; EN Python, ES/EN y ensamblaje mixto Rust. Laboratorio 016/018 conserva alcance; no se promueve otra realización tecnológica ni se amplían retrospectivamente sus pruebas.
- **Límites y relevo:** DFL-001/008 y resto de K1/K1-T abiertos. Cierre efectivo tras los cuatro flujos correctos y promoción del candidato exacto. [Transición §22](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#cierre-n0-04-20260907): sigue unicidad de CoupledSpec.bridges bajo BridgeSet; N0-05/N0-07 permanecen en K2. No se consolida el núcleo ni se abre una garantía material.

### RETP-2026-082 — Retirada Python y continuidad K1

- **Entrada y fuente:** main a09b9ef, PR #68; decisión humana, Pilares, perfiles y transición §22. El acto queda en la [adenda de oráculos §9](ACTA_TECNICA_REPARACION_DE_ORACULOS_2026_09_06.md#retirada-python-20260907).
- **Cambio y evidencia:** retirada del compilador y API Python, conservación de 14 esperados/77 negativos y núcleo en este commit. Conformidad directa 91/91, 18 pruebas del observador, CLI, 3 SEC.0 y 5 sondas nativas; WASI/navegador exigidos sobre la candidata exacta antes de integrar. Historial enlazado, sin nuevo oráculo generado por la realización.
- **Límites y relevo:** DFL-001 abierta; DFL-008 sale de la vía activa por retirada, no por corrección histórica. DFL-010 conserva el defecto compartido de campos repetidos. DFL-009 difiere servicio nativo y Cloudflare/Workers u otros hasta fila 9, retorno del primer universo CYB. Continúa K1 por BridgeSet, no F. PT01/PT02/PT04/PT13/PT14; no se promueve una plataforma ni se amplía el laboratorio histórico.
- **Estado:** efectivo tras los cuatro flujos correctos e integración de la candidata identificada en la PR correspondiente.

### RETP-2026-083 — Unicidad de BridgeSet y relevo K1

- **Entrada y fundamento:** a09b9ef, PR #68, retirada RETP-082 en commit separado; definición de BridgeSet y J1.2, Pilares, perfiles y secuencia §14. J-B0 se precisa en IR v0.3 §6.5.
- **Cambio y evidencia:** se rechazan repeticiones Nat sin deduplicar ni ordenar; vacío y precedencia del rango conservados. Tres pruebas intrínsecas, corpus 92/92 y 18 testigos ES/EN/ensamblaje; comparación literal de los 91 casos anteriores y 14 esperados intactos. Nativo/WASI/navegador exigidos antes de integrar la candidata exacta.
- **Límites:** sin nuevos campos, operaciones, versiones o código diagnóstico; DFL-001 sigue abierta. PT01/PT02/PT04/PT13/PT14; no nueva plataforma ni ampliación de evidencia histórica del laboratorio.
- **Decisión y relevo:** cierre limitado efectivo tras cuatro flujos correctos e integración. [Radiografía §15](../arquitectura/N0_RADIOGRAFIA_DE_OBJETOS_INVARIANTES_Y_ORACULOS_DEL_NUCLEO_SV_2026_09_04.md#cierre-bridgeset-20260907) y transición §24 fijan K1/Horizon.events; F pendiente. DFL-009 conserva su recepción al retornar del primer universo CYB.

### RETP-2026-084 — Tipos declarados del horizonte y multiplicidad

- **Entrada:** main 16232b6, PR #69; Documento III release1 §§3.2–3.5/4.1/9, IR v0.2 nivel3/J4.3, Pilares, perfiles y secuencia. [Radiografía §16](../arquitectura/N0_RADIOGRAFIA_DE_OBJETOS_INVARIANTES_Y_ORACULOS_DEL_NUCLEO_SV_2026_09_04.md#horizon-events-20260907) conserva el cotejo.
- **Decisión:** J-H1 exige unicidad local de tipos en Horizon.events; rechaza repeticiones sin ordenar ni deduplicar. Instancias en datos distintos y tipos compartidos entre horizontes permanecen. No se modifica TransitionData ni se deduce una axiomática de horizonte vacío.
- **Evidencia:** 93/93, tres pruebas de integración, 20 testigos ES/EN/ensamblaje; 92 observables previos y 14 esperados conservados. El testigo N0-04 [B,A,B] se sustituye explícitamente por [B,A] para su comprobación de orden, y pasa al nuevo rechazo. Los cuatro flujos exigen nativo/WASI/navegador sobre la candidata exacta.
- **Estado y relevo:** efectivo tras integración verificada; transición §25 fija K1/Domain.parameters y multiplicidad de parameter_id. DFL-001/005/010 y K1-T conservan alcance; F pendiente. DFL-009 sigue diferida al retorno del primer universo CYB. PT01/PT02/PT04/PT13/PT14; no nueva plataforma ni ampliación retrospectiva de laboratorio.

### RETP-2026-085 — DOI del Documento III y cotejo de actualización

- **Entrada y objeto:** main `02cd27d`, PR #70; precisión humana sobre la release citada. Se reciben Pilares, perfiles, secuencia §25, Frontera e IR. El [DOI estable](https://doi.org/10.21428/39829d0b.bb86c65d) sustituye cuatro enlaces a release1.
- **Evidencia y resultado:** [radiografía §16.3](../arquitectura/N0_RADIOGRAFIA_DE_OBJETOS_INVARIANTES_Y_ORACULOS_DEL_NUCLEO_SV_2026_09_04.md#reconciliacion-documento-iii-20260907); cotejo completo del texto del autor, commits `1afa2ab` y `b8fd329`, con identidades de blob. Nota audiovisual, presentación y notación 𝒯 → 𝒰 del operador inducido; definiciones y límites aplicables se conservan. Frontera §3 recibe la notación corregida.
- **Límite:** HTTP 403 impidió cotejar directamente la página editorial actual. La conclusión se limita al texto identificado del repositorio del autor; no certifica otra edición ni identidad literal de la página remota. RETP-084 conserva la consulta histórica; no se reescribe su evidencia.
- **Verificación y relevo:** revisión documental y Conformidad SVP exigida sobre candidata exacta; código, corpus y workflows conservados. J-H1 y la evidencia nativo/WASI/navegador de PR #70 mantienen su alcance. Sigue K1/Domain; F y deudas pendientes conservan sus puertas, incluida DFL-009 en retorno CYB.

### RETP-2026-086 — Domain: unicidad nominal y ligaduras pendientes

- **Entrada y fundamento:** main `4536bd0`, PR #71; Pilares, perfiles, secuencia §25 y N0-06/§7. Documentos V §5.1 y IV §§4.2–4.3/6.1–6.4 en el corte del autor `b8fd329`; [radiografía §17](../arquitectura/N0_RADIOGRAFIA_DE_OBJETOS_INVARIANTES_Y_ORACULOS_DEL_NUCLEO_SV_2026_09_04.md#domain-parameters-20260907) identifica blobs y alcance. IR v0.3 §6.7 precisa J-D0 antes de su realización.
- **Cambio y evidencia:** rechazo de nombres repetidos dentro de Domain, preservando orden y diagnósticos previos. Conformidad 94/94; tres pruebas de integración; banco de 24 testigos ES/EN/ensamblaje. Los 93 observables anteriores y los 14 esperados se conservan. Cuatro flujos exigidos sobre candidata exacta, incluidos nativo/WASI/navegador.
- **Límite adversarial:** el numeral `parameter_id` no identifica por sí solo la instancia `(C,j)`. No se inventan ligaduras, cardinalidades ni prohibiciones de vacío o multiplicidad; diez testigos conservan esas representaciones sin acreditarlas como dominio completo. DFL-005 recibe la insuficiencia con puerta obligatoria en F para operaciones que dependan de ella. No se reactiva fallo→U del antecedente IV.
- **Decisión y relevo:** cierre nominal efectivo tras integración verificada. [Transición §26](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#domain-relevo-20260907): concordancia diagnóstica/deuda/corpus, DFL-010 y K1-T antes de F. PT01/PT02/PT04/PT13/PT14; mismas versiones y plataformas. DFL-009 conserva retorno CYB; acceso editorial aplazado. No se cierra N0-06 entero, K1, dominio ni núcleo.

### RETP-2026-087 — Campos opcionales sin pérdida y concordancia vigente

- **Entrada y fundamento:** main `000a7d2`, PR #72; Pilares, perfiles y transición §26. Gramática v0.1 §§5.4–5.5 heredada por v0.2 §1; precisión v0.2 §14. [N0 §18](../arquitectura/N0_RADIOGRAFIA_DE_OBJETOS_INVARIANTES_Y_ORACULOS_DEL_NUCLEO_SV_2026_09_04.md#campos-opcionales-20260907) concentra inventario, cambio y evidencia.
- **Cambio:** rechazo de repetición e inversión de campos opcionales en relación/patrón antes de sobrescribir; guardas de metadata/transition conservadas. Mismas listas, estructuras, emisores y versiones. Catálogo de 51 códigos declarado y emisión textual diferenciados; matriz/CSV de agosto conservados como historia, sin declarar completa DFL-001 ni cobertura E011 por su testigo sintáctico.
- **Evidencia:** 100/100, dos pruebas de integración, 64 testigos ES/EN/ensamblaje; 94 observables previos y 14 esperados idénticos. Los seis nuevos negativos antes se admitían. Cuatro flujos exigidos sobre candidata exacta con nativo/WASI/navegador y bancos previos. PT01/PT02/PT04/PT13/PT14; no nueva plataforma ni ampliación del laboratorio histórico.
- **Decisión y relevo:** DFL-010 cerrada en el inventario tras integración verificada. [Transición §27](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#campos-opcionales-relevo-20260907) conserva fila 3: sigue cierre o delimitación expresa K1-T. F aún pendiente; DFL-005 obligatoria allí para ligaduras, DFL-009 en retorno CYB y acceso editorial aplazado.

### RETP-2026-088 — K1-T: delimitación productiva y relevo a F

- **Entrada y fundamento:** main `1d3ebd22d30f61604fd51dc3d3d9864d1f0d7ac4`, PR #73; Pilares, perfiles, transición §27 y N0 §7. Gramática 0.2 con producciones heredadas, IR 0.2/J1.5 bajo IR 0.3 §2; Documento IV §§5.2–5.3 en el corte del autor `b8fd329`, blob `66ee444`, sin reactivar su fallo→U histórico.
- **Dictamen:** [N0 §19](../arquitectura/N0_RADIOGRAFIA_DE_OBJETOS_INVARIANTES_Y_ORACULOS_DEL_NUCLEO_SV_2026_09_04.md#k1-t-20260907) e IR 0.3 §2.4 delimitan la ruta productiva observación→Tri no habilitada. Se conservan cinco nombres declarativos; no se los interpreta como conjuntos, función o prueba de partición. No se incorpora una operación ni API de ejecución.
- **Rectificación:** trece atribuciones sintácticas a E001 se adscriben a sus producciones; E001 conserva InvalidTriValue y E107 su estatuto IR pendiente, sin emisión efectiva. Se explicita la corrección de RETP-087, manteniendo los asientos históricos. La tabla resumen recibe también 085–087, ya presentes en el detalle y CSV.
- **Evidencia:** 100/100, workspace y 40 testigos K1-T (20 conservaciones/20 rechazos, ES/EN y ensamblaje); 100 observables anteriores y 14 esperados conservados. Cuatro flujos exigidos sobre candidata exacta, incluidos nativo/WASI/navegador y bancos previos. Sin cambio de emisores, estructura ni versiones; PT01/PT02/PT04/PT13/PT14.
- **Decisión y relevo:** delimitación efectiva tras integración verificada; [transición §28](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#k1-t-relevo-20260907) recibe salida acotada de K1 y fija F. DFL-005 y necesidades de transducción se reciben allí antes de operaciones dependientes. E107/J1.5 sigue pendiente para producción; DFL-001/008 mantienen límites, DFL-009 retorno CYB, N0-05/N0-07 K2. No se cierran álgebra, dominio, núcleo ni R2/R3/R4.

### RETP-2026-089 — Contrato candidato F y relevo a F-IF

- **Entrada y fuentes:** main `4d5f93b612003352a63c8c01bf99e1000a6d0125`, PR #74; Pilares, perfiles, transición completa hasta §28, FFL-E, valoración/adversarial/sincronización IMM corregidas, N0/K1, IR y representación Rust; matriz tecnológica 020 en `374a10b`. El corte clínico recibido permanece `3bea6b7`.
- **Producto:** [F-SV/0.1-candidata](../arquitectura/CONTRATO_CANDIDATO_F_DOMINIO_REPRESENTACION_Y_SUFIENCIA_POR_OPERACION_2026_09_07.md): identidad/versiones y terna, perímetro, operaciones, instancias/ligaduras, transducción pendiente, recuperabilidad por operación, información lateral, responsabilidad y soporte. Su versión es documental, no una ampliación de Gramática/IR.
- **Adversarial:** diferencia suficiencia demostrada, pérdida demostrada y suficiencia no acreditada. Control exhaustivo externo de cuatro estados: una representación con pérdida conserva Q_cuenta y pierde Q_izquierda; información lateral explícita no acredita recuperación desde la representación sola. No es célula, prueba clínica, ejecución SV ni campaña F-IF.
- **Recepción:** DFL-005 recibe mínimo por operación y ligaduras antes de admitir capacidades dependientes; K1-T conserva producción no habilitada. Se reutilizan la reconciliación IMM 15↔44 y PT01–PT14, con límites de 012/016/018; §6 precisa la sucesión K1 y retirada Python frente a la valoración histórica.
- **Verificación:** revisión contractual, enlaces, cálculo finito y concordancia RETP; Conformidad SVP exigida en candidata exacta. Los blobs ejecutables, normas de Gramática/IR/perfiles, corpus, esperados, workflows y Playground se conservan. La paridad PR #74 conserva su corte, sin atribuirse como nueva prueba del contrato.
- **Decisión:** formulación de fila 4 efectiva al integrar candidata verificada. [Transición §29](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#contrato-f-relevo-20260907) abre como siguiente paso fila 5/F-IF con sus seis testigos. No cierra las carencias de representación ni adelanta IMM/CYB, álgebra, K2 o materialidad. DFL-009 sigue en fila 9; acceso editorial aplazado.

### RETP-2026-090 — Seis testigos F-IF y relevo G/H

- **Entrada y fuentes:** main `7dd6ef5ea39fcd978d485d1e2db1f3caa8c4bca3`, PR #75; Pilares, perfiles, transición completa hasta §29, F-SV/0.1-candidata, FFL-E y campos actuales de IR. El corte IMM `3bea6b7` se conserva.
- **Producto:** [F-IF/1](../arquitectura/F_IF_SEIS_TESTIGOS_SINTETICOS_Y_RELEVO_G_H_2026_09_07.md), cases.json, observador externo, controles de sensibilidad y evidencia comprometida. Seis productos documentales de ocho estados; 18 operaciones de lectura y cadena F0/F1/F2 explícita. No es ampliación de SV ni constitución clínica.
- **Resultado:** 54 filas: 36 suficientes y 18 con pares de pérdida; 288 recuperaciones exactas y 144 sobre (H2,S,P); 24 controles técnicos y 12 pruebas del observador. La igualdad de H es literal; oráculos y cadena tienen identidades y no se actualizan automáticamente. Información lateral y pin de fuente son dependencias expresas.
- **Insuficiencias:** las pérdidas identifican las representaciones incapaces de responder cada Q. Las operaciones no se ofrecen como SV: cadena/certificado y ligaduras no materializados. DFL-005, K1-T y DFL-006 conservan sus puertas; G/H recibe aplicación/no aplicación a los requisitos reconciliados 15↔44. Los paquetes artificiales no amplían OP-IMM-001.
- **Verificación:** Conformidad SVP exigida en candidata exacta con la campaña añadida y corpus 100/100 preservado. Código Rust, Gramática/IR/perfiles y Playground intactos. La paridad PR #74 conserva su corte; no se la cuenta como ejecución nueva de F-IF. Se reutilizan PT y 012/016/018 con sus límites, sin garantía material adicional.
- **Decisión:** integración verificada completa fila 5 en alcance sintético; [transición §30](../dominios/inmunologia/ACTA_DE_CONFORMIDAD_DE_TRANSICION_SECUENCIAL_DESDE_OP-IMM-001_AL_LENGUAJE_SV_2026_09_03.md#f-if-relevo-20260907) entrega fila 6/G-H. No se adelantan CYB, álgebra, K2, frontera ni consolidación; DFL-009 sigue en fila 9 y acceso editorial aplazado.

### RETP-2026-091 — Recepción documental de G/H

- **Expediente:** [Markdown RETP-091](./RETP_2026_091_RECEPCION_GH_Y_APERTURA_FILA_7.md) y [CSV vinculado](./RETP_2026_091_RECEPCION_GH_Y_APERTURA_FILA_7.csv), ambos conservados. Este enlace al maestro se incorpora el 08/09/2026; no inventa una integración ni una ejecución anterior.
- **Identidad:** Lenguaje `bc3b22c9e9319e8f191390c8cfe9fa1577904d87`; retorno G/H `54fe0d89c9e59065eae2bc8a38f5ec0832ece4b9`; recepción candidata `9b32edda21072b3d2a138d9e92d95febdbc21ac4`, PR #77.
- **Dictamen:** `SUFICIENCIA_NO_ACREDITADA_PARA_EJECUTAR_Q0`. No afirma irrepresentabilidad; SP-01…SP-12 siguen sin ejecución integral.
- **Continuidad:** la fila 7 queda abierta en la candidata con PT01/PT03/PT04/PT14. DFL-005, H06/H07 y las restantes obligaciones conservan sus límites. Inmunología permanece en pausa; constituir el primer universo falsador de Ciberseguridad corresponde a su unidad cuando reciba una candidata apta.
- **Estado:** `RECIBIDO_EN_CANDIDATA_NO_INTEGRADA`.

### RETP-2026-092 — Restauración del mandato del español

- **Documentos autorizados:** [acta del español](./ACTA_DE_USO_DEL_ESPANOL_EN_TODOS_LOS_REPOSITORIOS_SV_2026_09_07.md) y [CSV RETP-092](./RETP_2026_092_USO_DEL_ESPANOL_EN_REPOSITORIOS_SV.csv). Este apartado es su enlace Markdown desde el maestro; no sustituye ni altera el acta.
- **Identidad de restauración, 08/09/2026:** fuente `149fcbc0c7cd5a1b9b5870272e5f7f1103376185`; objeto Git del acta `89be13febe50f2893e738471ab246e1ac33b45a7`; objeto Git del CSV `fe737cbe3a61e670ad1365b6d3cd1796e96e2a06`. Se restituyen exactamente los bytes autorizados.
- **Gobierno:** DFL-011 pertenece a la revisión integral del español en todos los repositorios SV, públicos y privados. El mandato rige desde su aprobación; la retirada posterior fue un error de la candidata.
- **Momento:** español correcto desde ahora en redacción nueva o revisada; revisión integral, una vez resuelto el trabajo técnico previo y antes del cierre del núcleo. No suspende la fila 7 ni autoriza modificaciones indiscriminadas de README o actas históricas.
- **Estado:** `PENDIENTE_DFL-011`; la revisión integral no se declara realizada.

### RETP-2026-093 — Incorporación del subcierre local al maestro

- **Expediente:** [Markdown RETP-093](./RETP_2026_093_CORRECCION_TRANSITIONDATA_Y_ORACULOS_NATIVOS.md), [CSV vinculado](./RETP_2026_093_CORRECCION_TRANSITIONDATA_Y_ORACULOS_NATIVOS.csv) y acta técnica allí enlazada. El enlace maestro se incorpora el 08/09/2026.
- **Corte y alcance:** `80aee0a48adb72710770adbfbe9f5d0d71585a6f`, con sucesión documental `1864ebfbcf198fdefe6b8fb879a32f2c5e844993`. H04/H05 locales y nueve negativos incorporados al corpus compartido `14+95`. Las ejecuciones y huellas originales permanecen en el expediente con su corte; no prueban por anticipado la corrección E115 de RETP-094.
- **Rectificación de identidades:** DFL-011 conserva el español; el nombre histórico `cell_ref` pasa de la referencia candidata DFL-011 a DFL-012; la independencia semántica pasa de DFL-012 a DFL-013. No se modifica la clave externa ni se cierra ninguna de estas obligaciones.
- **Estado:** `CANDIDATA_VERIFICADA_NO_PROMOVIDA` en el alcance y corte identificados. DFL-005, H06/H07 y la causalidad ejecutiva entre transición y marcos siguen abiertas.

<a id="retp-2026-094--discriminacion-causal-e115-y-rectificacion-registral"></a>

### RETP-2026-094 — Discriminación causal E115 y rectificación registral

- **Entrada:** PR #78 en `1864ebfbcf198fdefe6b8fb879a32f2c5e844993`, apilada sobre la recepción G/H de PR #77. La nueva candidata debe incorporar la restitución literal del español registrada en RETP-092.
- **Fundamento independiente:** [acta N0-02, §2](../arquitectura/ACTA_TECNICA_N0_02_TOTALIDAD_Y_UNICIDAD_DE_OUTPUT_SEMANTICS_2026_09_06.md) e IR 0.3 §6.2: para `CellSpec C`, `OutputSemantics S` y `Codomain K={A,B}`, cada miembro aparece una sola vez y no hay claves ajenas. Los esperados proceden de esa obligación aplicada a los testigos comprometidos, no de copiar la salida del compilador.

| Testigo | Claves repetidas | Claves ausentes | Claves ajenas |
|---|---|---|---|
| `output_semantics_vacia` | ninguna | A, B | ninguna |
| `output_semantics_clave_ausente` | ninguna | B | ninguna |
| `output_semantics_clave_ajena` | ninguna | ninguna | X |
| `output_semantics_clave_repetida` | A | ninguna | ninguna |

- **Cambio:** cuatro expectativas en `oracle_support.py` conservan los tres conjuntos discriminantes y los referentes C/S/K. El mecanismo sigue siendo comprobación de un fragmento específico dentro del rechazo controlado; no se afirma igualdad literal de todo `stderr`. No cambia la semántica Rust, el inventario de 14 válidos y 95 inválidos, los testigos ni sus JSON esperados.
- **Sensibilidad fijada:** `test_oracle_support.py` incorpora cuatro controles válidos, los doce intercambios dirigidos entre causas distintas y doce sustituciones de uno de los tres referentes. Con los tokens anteriores los veinticuatro contraejemplos no eran rechazados; tras la corrección se rechazan todos. Las 23 pruebas locales pasan y conservan los controles generales de retorno `1`, salida IR vacía y envoltorio de rechazo.
- **Límites de la clasificación:** ocho grupos de tokens compartidos reúnen veinte casos del inventario de 95; ese recuento no mide fidelidad diagnóstica. Se ha demostrado y corregido la pérdida discriminante del grupo E115 de cuatro casos. Los otros grupos y los 75 tokens únicos no reciben por ello una certificación causal. No se modifican los diagnósticos de `compose`, la resolución de alias ni sus obligaciones mediante esta corrección; DFL-001 continúa abierta.
- **Continuidad registral:** RETP-091/092/093 quedan enlazados desde el maestro; DFL-011 conserva el mandato del español, DFL-012 identifica `cell_ref` y DFL-013 la independencia semántica. La revisión integral del español es final y no bloquea fila 7. Las rectificaciones de identificadores en el expediente candidato RETP-093 se señalan con fecha propia.
- **Dependencia descubierta en la primera ejecución:** la cabeza `a23c834a9e1f14c2e5cf67dca3c458e08fca2606` pasó Conformidad SVP (`34180121748`) y R0-8 (`34180121875`), pero falló en R0 Rust (`34180121709`) y R0 WASM (`34180121701`). Dos fuentes del banco de sensibilidad reutilizaban la expectativa del corpus aunque declaraban CC/SS/KK y Alpha. Se corrigen `run_oracle_sensitivity.py` y su consumidor `r0_wasm_browser_manifest.py` para exigir expectativas propias de N0-02/N0-03, con y sin CellSpec. Dos controles positivos y cuatro sustituciones de contexto protegen esta separación. Se mantienen las mismas cinco fuentes del banco y los 95 negativos; no se rebaja la expectativa E115 ni se modifica Rust. El fallo y su sucesión quedan identificados, sin presentar aquel corte como conforme.
- **Verificación integrada exigida:** Conformidad SVP, R0 Rust, R0-8 y R0 WASM sobre la nueva cabeza, incluido corpus nativo/WASI/navegador. Los resultados anteriores conservan sus cortes. La prueba local del observador no se presenta como una compilación local nueva de Rust.
- **Estado inicial, conservado como antecedente:** `CORRECCION_LOCAL_VERIFICADA_CI_PENDIENTE_NO_PROMOVIDA`. DFL-005, H06/H07, la ejecución causal y la independencia semántica permanecen abiertas. No se cierra la fila 7 ni se entrega todavía una candidata a Ciberseguridad.


#### Verificación integrada de RETP-094 · 08/09/2026

Corte material verificado: `bf660b00c0c2b38c7e5e4327b1e89f0ec81348be`; recepción incorporada: `1cbe4b9e6d9c484e540f1385109b38badc800c4f`. Los cambios posteriores de este asiento sólo registran la evidencia. No se confunde esta verificación con la del corte fallido `a23c834a`.

| Comprobación | Ejecución | Resultado |
|---|---|---|
| R0-8 Baseline nativa | [34180315127](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315127) | conforme |
| Conformidad SVP | [34180315138](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315138) | conforme |
| R0 Rust | [34180315113](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315113) | conforme |
| R0 WASM paridad nativa y navegador | [34180315118](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315118) | conforme |

Resultados: 23 pruebas del observador; corpus compartido 14/14 válidos y 95/95 inválidos en nativo, WASI y navegador; 9/9 casos causales de fila 7; cinco fuentes del banco conservadas; 12/12 mutaciones dirigidas detectadas, sin supervivientes ni mutantes inválidos; 211/211 pruebas unitarias de `sv_core`, además de sus pruebas de integración. Referencia CI Rust/Cargo 1.98.0 sobre Ubuntu 24.04; compatibilidad adicional con 1.98.1. La comprobación local del observador utilizó Python 3.12.13. No se afirma identidad con un despliegue productivo.

| Paquete de evidencia | Artefacto | SHA-256 del archivo ZIP |
|---|---|---|
| `directed-mutation-sensitivity` | [10038665677](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315113/artifacts/10038665677) | `baad7fc1878bfc260e0e2ac613a8a350d0df6adf43945c3e16bb3d23ac302193` |
| `oracle-sensitivity` | [10038661363](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315113/artifacts/10038661363) | `e8e468c24d800dab002c8f6b3567333cfb05104096e4d7c3fdf2d46c4af39cd6` |
| `r0-8-baseline-native` | [10038664487](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315127/artifacts/10038664487) | `8b8ffa42b104475a56f90142e2d3bbeb3995305d10bcfa1edec60281dcf9eb4f` |
| `r0-wasm-three-way-parity` | [10038676790](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34180315118/artifacts/10038676790) | `3580d39657ea483716e3d57ecf70d24b9e2b6fb6acf9c0437c07c075f1471f3c` |

Los paquetes conservan las entradas, salidas, comandos, versiones y huellas producidos por los flujos correspondientes. La identificación del ZIP procede del metadato de Actions; no se declara una descarga y verificación local del ZIP. La identidad de la realización y de los observadores figura en los manifiestos de cada paquete.

**Estado de RETP-094: `CANDIDATA_VERIFICADA_NO_PROMOVIDA`.** La PR #77 ha pasado Conformidad SVP [34179902203](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34179902203) sobre `1cbe4b9e6d9c484e540f1385109b38badc800c4f`. El acta del español y RETP-092 mantienen sus objetos originales. La candidata correctiva sigue dependiendo de #77; la fila 7 y las obligaciones enumeradas permanecen abiertas. La referencia temporal de #78 a main sólo permite activar los flujos existentes y debe volver a `recepcion-gh-20260907` antes de dejar el relevo.

<a id="retp-095"></a>

### RETP-2026-095 — Testigo causal de salida de tabla fuera de codominio

- **Corte de entrada:** `5eea9bfd5b7646236568da82a9091acfe68f4082`, cabeza de PR #78, sobre PR #77 `1cbe4b9e6d9c484e540f1385109b38badc800c4f`; main continúa en `bc3b22c9e9319e8f191390c8cfe9fa1577904d87`. Se han leído AGENTS, Pilares, acta de perfiles, transición completa y registros aplicables. La autorización de subsanación se conserva; ambas solicitudes siguen candidatas.
- **Obligación y testigo previos al resultado:** [Gramática 0.2 §13](../../GRAMATICA_SUPERFICIAL_MINIMA_SV_v0_2.md#13-reconciliación-de-cierres-internos-heredados) exige cerrar `table` con `}` sin punto y coma adicional. El [catálogo efectivo §3/E011](../referencia/ERRORES_CANONICOS_SV_v0_2.md#3-precisiones-vigentes) exige que cada salida pertenezca al codominio declarado. El testigo cubre una vez A y B de KIn, declara KOut={OK,NO_OK} y usa FUERA como única salida ajena. Su condición esperada es pertenencia de salida, no sintaxis, aridad, entrada ni totalidad.
- **Hallazgo y precisión:** el testigo anterior terminaba su bloque interno en `};` y su expectativa aceptaba aquel error sintáctico. La limitación ya consta en RETP-078, RETP-087, la matriz de concordancia y DFL-001/§6. La guarda semántica existe en `validate_admissibility_table`: rechaza la salida ajena con `AdmissibilityTable T1: salida fuera de codominio`. No procede afirmar que la falta del literal E011 demuestre ausencia de esta guarda, ni presentar la brecha como no registrada.
- **Corrección mínima:** se elimina ese punto y coma, se precisa el comentario del testigo y se sustituye la expectativa sintáctica por la causa semántica y la identidad T1. No se cambia `sv_core/src`, Gramática, IR ni serializador. Corpus: 14 válidos y 95 inválidos; se corrige un testigo existente, sin añadir casos al inventario general. Los 14 JSON esperados permanecen intactos.
- **Identidad del testigo:** SHA-256 anterior `32141541dfd1bfdf067dd66d10ca4298c38d5359747f4b507c9be8598c5c6ec5`; corregido `6c9e279af988256348b5d6c73c6478ca035998dbe14dd8201dc367e2e6a0ddf1`. Los bytes anteriores se conservan en la confirmación de entrada.
- **Pruebas locales del observador:** 25/25. La expectativa acepta el rechazo semántico de T1 y rechaza cuatro sustituciones: error sintáctico anterior, tabla incompleta, entrada ajena y salida ajena de T2. Con el token anterior las dos pruebas nuevas fallan: se rechaza el control semántico y se admite indebidamente el error de sintaxis. Se conservan retorno 1, salida IR vacía y envoltorio controlado. Estas pruebas construyen mensajes y no se presentan como compilación local Rust.
- **Comprobaciones de realización exigidas:** tres pruebas Rust usan el fichero comprometido: rechazo semántico exacto; admisión al sustituir únicamente FUERA por NO_OK; rechazo sintáctico al reintroducir el cierre antiguo. La mutación dirigida AT01 retira exclusivamente la guarda de salida y debe hacer fallar la primera prueba. Se añade al banco precedente sin reclasificar su evidencia histórica de doce mutantes. Conformidad SVP, R0 Rust, R0-8 y R0 WASM comprobarán la candidata identificada; el mismo negativo corregido pertenece al corpus nativo/WASI/navegador.
- **Límites y continuidad:** E011 conserva su obligación catalogada, pero este cambio no introduce su código literal ni una estructura diagnóstica. No ejecuta la tabla ni GateResult.output. E204 y la causalidad no medida de otros testigos permanecen fuera del subcierre; no se deduce un porcentaje global de fidelidad. DFL-001, DFL-005, H06/H07 e independencia semántica continúan abiertas. DFL-011 y su acta permanecen intactas. La fila 7 sigue abierta y no se activa Ciberseguridad.
- **Estado inicial:** `CORRECCION_LOCAL_VERIFICADA_CI_PENDIENTE_NO_PROMOVIDA`. La comprobación integrada debe añadirse con su cabeza, ejecuciones y artefactos; ningún resultado previo acredita esta modificación.


#### Verificación integrada de RETP-095 · 08/09/2026

La candidata material `461acc633d364a2eca964539a3835529fbc72c58` supera los cuatro flujos. Actions comprueba la confirmación de ensayo `439f88802e8fc67a0deb56b454eb1ee433cff2d3`, con árbol `9c1b33e8d5008ce622b522bf66d8a4279267eb8a`, idéntico al de la candidata. La base sigue siendo main `bc3b22c9`; esa confirmación de ensayo no es una integración en main.

| Comprobación | Ejecución | Resultado |
|---|---|---|
| R0 Rust | [34183907220](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907220) | Conforme |
| Conformidad SVP | [34183907211](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907211) | Conforme |
| R0-8 Baseline nativa | [34183907292](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907292) | Conforme |
| R0 WASM paridad nativa y navegador | [34183907306](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907306) | Conforme |

Rust/Cargo 1.98.0 sobre Ubuntu 24.04 es la referencia; Rust/Cargo 1.98.1 se comprueba adicionalmente como compatibilidad de `stable`. Los registros de ejecución confirman:

- observador: 25/25 pruebas;
- tres pruebas Rust de tabla: rechazo semántico exacto, control válido por sustitución de una salida y rechazo del cierre sintáctico anterior;
- corpus: 14/14 válidos y 95/95 inválidos en nativo, WASI y navegador; el testigo corregido recorre el corpus compartido;
- AT01 detectada; campaña dirigida 13/13, cero supervivientes y cero mutaciones inválidas. El banco conserva parches, órdenes, salidas y comprobaciones de restauración; no es un porcentaje exhaustivo de cobertura;
- los bancos anteriores de conformidad, sensibilidad, F-IF y perfiles mantienen sus comprobaciones y límites.

| Paquete | Artefacto | Bytes del ZIP | SHA-256 declarado por Actions |
|---|---|---|---|
| `directed-mutation-sensitivity` | [10039850030](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907220/artifacts/10039850030) | 49418 | `2274d34c84c14c0d84036e7ccd9df36623e1591ba52331e30571d4c2875b00f0` |
| `oracle-sensitivity` | [10039845019](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907220/artifacts/10039845019) | 5015 | `61b2b7477feaf30f689661b35c2547ab44a1413c5d851711adde3d0dfa1c1846` |
| `r0-8-baseline-native` | [10039846755](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907292/artifacts/10039846755) | 406236 | `c88311d428a769548f7cf430aae7a26a72933b65765371e6d1b55da44cc1cb30` |
| `r0-wasm-three-way-parity` | [10039860570](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34183907306/artifacts/10039860570) | 1838740 | `e94fd7210714ce71fedc360467857f992419dd35fa890223ee8ec06cc7b6cbf5` |

Se han leído los registros de los trabajos y los metadatos de artefactos; sus huellas no se presentan como una descarga y recálculo local de esos ZIP. El control semántico esperado procede del catálogo y del testigo, y la causa exacta se exige en la prueba Rust y en el corpus. La ausencia del literal E011 sigue siendo deuda diagnóstica, independiente de la guarda ahora ejercida.

**Estado:** `CANDIDATA_VERIFICADA_NO_PROMOVIDA`. La cola de evidencia actualiza únicamente los tres registros de Calidad y conserva el permiso ejecutable `100755` del comprobador de mutaciones, sin cambiar su contenido probado. La cabeza final conserva su propia comprobación en el expediente de PR #78. Se restablecerá la base `recepcion-gh-20260907` tras verificarla; la PR continúa dependiendo de #77. DFL-001 y fila 7 permanecen abiertas.

<a id="retp-096"></a>

### RETP-2026-096 — Integración secuencial de la recepción y del subcierre correctivo

**Fecha:** 08/09/2026. **Estado:** `RECEPCION_Y_SUBCIERRE_INTEGRADOS_FILA_7_ABIERTA`.

La autorización de continuación permite promover los objetos revisados, sin modificar el mandato del español ni declarar cerrado el frente actual. Se han leído AGENTS, Pilares, acta de perfiles, transición completa, F, devolución G/H y registros vigentes. La revisión distingue evidencia de candidata, árbol probado e integración.

| Objeto | Cabeza comprobada | Integración en main | Árbol conservado |
|---|---|---|---|
| PR #77, recepción G/H y restitución literal | `1cbe4b9e6d9c484e540f1385109b38badc800c4f` | `5e0f2e1fb0861879ce9963b370f89dd8137e9388` | `717972e1abac4ab7ff388a2923d3cb04b3de4cf7` |
| PR #78, H04/H05 locales y oráculos RETP-093…095 | `29984b41ce68813e90fb3dbc0ba47de9593b8561` | `1706099aef4a0e3846706c3963e7c76313adaf68` | `3f1858439745236530b6f19c6761055f8a8478a2` |

La primera cabeza pasó [Conformidad SVP 34179902203](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34179902203). Antes de promover la segunda, se integró #77, se cambió la base de #78 a main y se creó una reconciliación de dos padres sin cambiar su árbol: la cabeza `29984b41…` conserva exactamente el árbol de `e5211264…`. No se presenta una comprobación antigua como ejecución nueva.

| Comprobación renovada de #78 | Ejecución | Resultado |
|---|---|---|
| R0 Rust, referencia y compatibilidad adicional | [34187196322](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34187196322) | Satisfactorio |
| R0-8 Baseline nativa | [34187196355](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34187196355) | Satisfactorio |
| Conformidad SVP | [34187196408](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34187196408) | Satisfactorio |
| Paridad nativa/WASI/navegador | [34187196441](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34187196441) | Satisfactorio |

Las cuatro ejecuciones identifican `29984b41…` como cabeza. Los trabajos nativo y navegador y sus pasos terminaron satisfactoriamente. GitHub confirma ambas fusiones y sus firmas verificadas; los árboles de integración coinciden con los examinados. El resultado no acredita una segunda realización semántica ni la causalidad exhaustiva del corpus.

La restauración del español conserva el acta, blob `89be13febe50f2893e738471ab246e1ac33b45a7`, y RETP-092 CSV, blob `fe737cbe3a61e670ad1365b6d3cd1796e96e2a06`. DFL-011 conserva su identidad y su revisión integral final. Ningún README, acta histórica o repositorio de dominio se ha modificado.

**Sucesión de estado:** RETP-091…095 conservan las afirmaciones y los cortes de sus candidatas históricas; este asiento documenta su integración efectiva. `main@1706099a…` contiene ya G/H y el subcierre H04/H05, E115 y E011. DFL-001, DFL-005, H06/H07 y la realización causal de transiciones siguen abiertas. La fila 7 continúa mediante [el contrato de continuidad y ligaduras por operación](../arquitectura/CONTRATO_DE_CONTINUIDAD_Y_LIGADURAS_POR_OPERACION_FILA_7_2026_09_08.md); no se emite candidata para CYB ni se abre la fila 8.

<a id="retp-097"></a>

### RETP-2026-097 — Coherencia local de trayectoria y contextos; contrato previo de ligaduras

**Entrada:** `main@1706099aef4a0e3846706c3963e7c76313adaf68`. **Contrato anterior a la realización:** `cb8843b20ac84330ad4a5b46fe544c95ab8e7766`, [continuidad y ligaduras por operación](../arquitectura/CONTRATO_DE_CONTINUIDAD_Y_LIGADURAS_POR_OPERACION_FILA_7_2026_09_08.md). **Estado inicial:** `CANDIDATA_MATERIAL_CI_PENDIENTE`.

La nueva comprobación del núcleo exige identidad de arquitectura entre todos los marcos de una trayectoria y los horizontes de sus transiciones. Comprueba también la pertenencia estructural de los marcos y trayectorias consultados, las especificaciones celulares, evaluaciones y entradas de compuerta de `ArchitectureView`, y la correspondencia de los tres referentes de `CoverageReport` con el dominio del agente. El mismo núcleo aplica la regla en compilación ordinaria, perfilada y ensamblaje; no hay una segunda implementación en el anfitrión.

La condición precede al resultado: once negativos comprometidos declaran J4.2/J5.1, el objeto atacado, la causa completa y la reparación de un único referente que debe producir un control válido. El banco Rust comprueba cada negativo en la entrada ordinaria, perfil inglés, perfil español y ensamblaje mixto en ambos órdenes. Las once mutaciones nuevas CX01…CX11 retiran guardas por separado; se añaden a las trece anteriores. Los testigos se conservan en `tests/row7_context/testigos.json` y en el corpus compartido. No se generan esperados desde una ejecución.

**Inventario previsto:** 14 válidos y 106 inválidos (once nuevos). Los catorce JSON esperados previos permanecen intactos. Se ha comprobado localmente la concordancia del inventario y las 25 pruebas previas del observador. Rust, conformidad nativa/WASI/navegador y la campaña de 24 mutaciones quedan pendientes de ejecución identificada. No hay compilador Rust local; las pruebas Rust se ejecutarán con la referencia de los flujos, Rust/Cargo 1.98.0 sobre Ubuntu 24.04; stable conserva su función adicional.

**Alcance:** cierre local candidato H06/H07 de coherencia estructural, sin ejecución de `query`, restricciones, transiciones o criticidad. La igualdad nominal de `interface` y `silent_u` no materializa sus contratos. Una `CellSpec` presente en un grafo no identifica un nodo único ni acredita cobertura o permisos. No se prueba relación append-only entre versiones persistentes. DFL-001, DFL-003/004/005 y DFL-006 permanecen abiertas; la matriz §5 del contrato es de tratamiento de este incremento, no la condición final de salida de fila 7.

**Continuidad obligatoria:** materializar DFL-005 a partir de las nueve obligaciones y refutadores de §4; comprobar el subconjunto realmente ofrecido y completar la matriz de pérdidas antes de emitir candidata para CYB. El banco de contextos no se utilizará para certificar ligaduras aún ausentes. Inmunología continúa en pausa y la fila 8 no se activa. Ningún README, acta histórica, norma del español, plataforma o repositorio de dominio cambia.

#### Verificación integrada de RETP-097 · 08/09/2026

La candidata material `abe5e544730f76f3052c9afd809446746df34c03` supera los cuatro flujos. El ensayo de Actions utiliza `ac1d5e87966cf78a2bd87bd749a2c30ca9ac145b`, con árbol `50be23a1efc386d84ff1fe766e49e41c2be8cc36`, idéntico al de la cabeza candidata; no es una integración en main.

| Comprobación | Ejecución | Resultado |
|---|---|---|
| R0 Rust | [34188332623](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332623) | Conforme |
| Conformidad SVP | [34188332639](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332639) | Conforme |
| R0-8 Baseline nativa | [34188332608](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332608) | Conforme |
| Paridad nativa/WASI/navegador | [34188332624](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332624) | Conforme |

Resultados leídos en los trabajos: 211 pruebas unitarias de `sv_core` y once pruebas nuevas de contexto satisfactorias; 14/14 válidos y 106/106 inválidos en el corpus compartido; once controles positivos de reparación puntual; perfiles español/inglés y ensamblaje mixto en ambos órdenes. Las 24 mutaciones dirigidas se detectan, incluidas CX01…CX11, sin supervivientes ni mutantes inválidos. Se conservan las pruebas anteriores; no se interpreta la muestra dirigida como cobertura exhaustiva.

| Paquete | Artefacto | Bytes ZIP | SHA-256 declarado por Actions |
|---|---|---|---|
| Mutaciones dirigidas | [10041303991](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332623/artifacts/10041303991) | 98485 | `ffde1e62ac26aa7292b5bf337d3f1f0d7b5e9cebca17084563b994b44559c9b1` |
| Sensibilidad del observador | [10041296428](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332623/artifacts/10041296428) | 5014 | `89de3704ed1d19de6dcde9a2b339c81795941636c511fd4eeb9daa94920489c0` |
| Línea base nativa | [10041298829](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332608/artifacts/10041298829) | 412618 | `e397a72bf2d37402d1731f7840b084b18a5466c9eea01434320c966bb1d8e6cd` |
| Paridad entre destinos | [10041310878](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34188332624/artifacts/10041310878) | 1870296 | `5c1d8ce074f155f4a28f771a1e342ea3e29fb837fb95b152e40bebffa8e91ed6` |

Se identifican metadatos de Actions y registros de ejecución; no se declara una descarga y recálculo local de esos ZIP. Referencia Rust/Cargo 1.98.0 sobre Ubuntu 24.04; stable permanece separado. El cambio posterior a la candidata material registra esta evidencia y precisa la discordancia de `ArchitectureView` entre la forma abstracta de IR 0.2 y la material, sin cambiar la realización ni sus testigos.

**Estado:** `CANDIDATA_VERIFICADA_NO_PROMOVIDA`, PR #79. La cabeza documental final conserva su comprobación exacta en el expediente de la PR. No hay todavía revisión adversarial externa de este nuevo incremento. El siguiente bloque material sigue siendo DFL-005; la coherencia local de contexto no acredita ligaduras, cobertura, permisos, consulta completa ni ejecución causal. La fila 7 permanece abierta.

<a id="retp-098"></a>

### RETP-2026-098 — Ligaduras por operación LIG/0.1

**Entrada exacta:** `eeb7cf47bfbbbc6b617107b5976cde358a460377`, PR #79 candidata y no integrada. Se adopta el [contrato material DFL-005](../arquitectura/CONTRATO_MATERIAL_DE_LIGADURAS_DFL_005_2026_09_08.md) como sucesor de §4 del contrato de continuidad. F-SV/0.1 §3.1 y G/H SP-01/02/05, incluido GH-DOC-07, justifican la sede y el alcance.

**Decisión previa:** entrada Rust tipada versionada en `sv_core`, enlazada al programa exacto y a una expectativa contractual aportada expresamente. Se valida una operación identificada y se recuperan sus usos ordenados, instancias, destinos, reglas referidas, compartición y alcance lateral. No se altera gramática ni proyección 0.1.0. La compilación declarativa no obtiene esta capacidad implícitamente.

**Testigos previos:** L01–L24 y sus controles constan en el contrato antes de la realización. Los ataques internos deben llegar a su condición; recalcular la huella contractual en ellos impide que la integridad enmascare la falta de una guarda. Artefactos y reglas llevan referentes exactos, pero sus bytes no autentican autoridad ni prueban significado clínico.

**Estado inicial:** `CONTRATO_PREVIO_REALIZACION_Y_PRUEBAS_PENDIENTES`. El incremento se apila sobre PR #79; no acredita su revisión externa ni la promueve. Matriz final de pérdidas, recuperación de respuestas con S, ejecución Q0, K1-T, productores y autoridad permanecen pendientes. Fila 7 abierta, CYB no emitida. Actas históricas, README y norma del español intactos.

**Realización candidata posterior al contrato `5fd6087a7fe7ec6b12c8c8f4e9c90a0c116a2eac`:** `sv_core::bindings` materializa LIG/0.1; el resultado posee construcción privada y conserva contrato, operación y programa. El banco contiene 44 negativos y nueve positivos, cada uno en compilación ordinaria, perfil español y ensamblaje en ambos órdenes. Un testigo de codificación fijado desde §2, calculado por un observador Python independiente, protege la huella sin copiar salida Rust. Se añaden 19 mutaciones dirigidas, hasta 43 en la campaña general. Estas cifras son inventario de pruebas, **no resultados ejecutados** en este punto.

**Distribución:** sondas aparte para nativo, WASI y navegador, con comparación literal de informes. La API productiva de `sv_wasm` y el corpus SVP 14+106 se conservan; LIG/0.1 tiene banco propio porque su entrada es tipada, no sintaxis SVP. Los cuatro flujos admiten bases `fila7-*` para comprobar candidatas apiladas sin presentar la PR #79 como integrada. No se cambia la versión Rust de referencia.

**Estado de realización:** `CANDIDATA_MATERIAL_PENDIENTE_DE_VERIFICACION`. Se registrará el corte exacto y sus resultados al terminar las ejecuciones. Falta contraste externo y matriz final de pérdidas; la fila 7 no se cierra por compilar esta interfaz.

**Verificación del corte material:** `c4c50a0677498c66dd77f7c5a61b5e2173fd291c`, árbol `554c3c7a02da93277f108546c54156e173f12414`. GitHub ejecutó la composición `6bd5375c2d9ce83718c262a17f807566a03f75c5`, con padres `eeb7cf47…` y `c4c50a06…`; su árbol coincide exactamente con el árbol material. Se han inspeccionado los registros completos de R0 Rust y de paridad, además de los estados de los cuatro flujos.

| Comprobación del corte material | Ejecución | Resultado |
|---|---|---|
| R0 Rust; referencia 1.98.0 / compatibilidad adicional 1.98.1 | [34193869757](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34193869757) | Conforme en ambos trabajos |
| Conformidad SVP | [34193869739](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34193869739) | 14/14 válidos y 106/106 inválidos |
| R0-8 nativa | [34193869735](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34193869735) | Conforme |
| Paridad nativa/WASI/navegador | [34193869688](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34193869688) | Conforme; informes LIG/0.1 literalmente idénticos |

**Resultados acotados:** 211 pruebas unitarias previas de `sv_core` y 45 pruebas de integración nuevas: 44 negativos individuales y una prueba que reúne nueve positivos. La sonda ejerce los 53 casos en cuatro entradas —ordinaria, perfil español y ensamblaje en ambos órdenes—: 212 resultados por destino, con control de reparación para cada negativo. `43/43` mutantes dirigidos detectados, incluidos `LB01…LB19`; cero supervivientes y cero inválidos. La codificación coincide con el testigo independiente `beff99707d648d591714e431b462bf61546da931771a6168cd80b1c8037f7dc0`. No se deduce de esas cifras cobertura universal ni una segunda realización semántica.

| Artefacto de Actions | Identificador | Bytes declarados por GitHub | SHA-256 declarado por GitHub |
|---|---|---:|---|
| Mutaciones dirigidas | 10043171096 | 161965 | `4a27b24060ede1addad7ee4f74af7b4eb48cccc454a15fa90be354f1a99ddfc2` |
| Sensibilidad del observador | 10043154978 | 5014 | `575e8d0eeb4afff7232369438da42b03362d1a3d5ba9179a3dfb6a39767aecf8` |
| R0-8 | 10043158762 | 414226 | `25d183bb3fe62a6d860d08d4c272c5388703d6e2d02bbc33e3d8a3abc0a9a84c` |
| Paridad, incluidas sondas e informes LIG | 10043175787 | 2634607 | `f644f0f09054e5d207b820aa72a28a454de567e8d54d8a706dc92287bf718d4e` |

Las huellas de archivo de esta tabla proceden de los metadatos de Actions; no se afirma haber recalculado localmente el SHA-256 de los ZIP. Las ejecuciones y sus registros sí se han inspeccionado. El banco y los esperados están comprometidos, disponibles para reproducción; las sondas conservadas son artefactos de pruebas, no adaptadores productivos.

**Decisión actual:** `CANDIDATA_VERIFICADA_NO_PROMOVIDA`, PR #80 apilada sobre #79. La cola documental sólo registra evidencia; las comprobaciones de su cabeza exacta quedan enlazadas en la PR. DFL-005 ya tiene una realización verificable de ligaduras LIG/0.1; no queda por diseñar esa representación desde cero. Permanecen el contraste externo de #79/#80, la resolución final por operación de las pérdidas G/H y la candidata completa de fila 7. Los documentos referidos conservan identidad, pero su semántica y autoridad no se dan por ejecutadas ni autenticadas. La fila 7 permanece abierta.

<a id="retp-099"></a>

### RETP-2026-099 — Resolución por operación del retorno G/H y transporte LIG

**Entrada:** `d374e1cb373a3dcd141faf482f9501ceb47a7e0b`, PR #80 no promovida, sobre PR #79. **Fuente G/H:** `54fe0d89c9e59065eae2bc8a38f5ec0832ece4b9`. Se adopta [GH-LIG/0.1](../arquitectura/RESOLUCION_DE_PERDIDAS_GH_Y_TRANSPORTE_LIG_2026_09_08.md) antes de realizar su sonda. La matriz enlaza los 15 G10, 44 LSV y 81 enlaces recibidos con capacidades concretas, exclusiones, responsables y condiciones de reapertura. Mantiene las doce SP como no ejecutadas integralmente y no declara suficiencia Q0.

**Objeto material:** transportar los dieciséis estados GH-DOC por `validate_bindings`, con tres representaciones F0/H/HS. Se esperan 48 transportes, 16 recuperaciones F0, 16 recuperaciones con S, 16 controles conservados en H y ocho pérdidas H demostradas. Son obligaciones y recuentos previos, no resultados ejecutados. Los resultados proceden del testigo G/H; el núcleo sólo valida ligaduras y conserva bytes. La sonda no constituye los 27 parámetros, no ejecuta clínica y no introduce una operación SV.

**Realización candidata:** ocho pruebas Rust del transporte y sondas para nativo/WASI/navegador; entradas regeneradas desde G/H sin resultados Rust; observador externo con 16 ataques y causas exigidas. El control sintético local del observador rechaza 16/16 ataques y admite reserialización; ese control no constituye ejecución del núcleo. La ejecución integrada aún está pendiente.

**Estado:** `CONTRATO_Y_RESOLUCION_CANDIDATOS_PENDIENTES_DE_PRUEBA`. Las fuentes originales se identifican por bytes, SHA-256 y blob Git; el inventario público es una extracción, no una reverificación de las 44 fuentes primarias. Falta ejecutar y revisar esta candidata. Fila 7 abierta; CYB no abierta; PR #79/#80 sin promoción.


**Verificación material:** `bcf25c5b566a6535ba1c3851346fbb355b98ae84`, árbol `1396245f5ef0d14528dc2fa2347350d460b898ab`. La composición de Actions `32b07237ee5696f78dc23fbc696f02e41b42a856` tiene padres `d374e1cb…` y `bcf25c5b…` y exactamente el mismo árbol; no es una integración en main. El contrato previo quedó fijado en `b75b090687daecfacb4be05a836d2bd97359a68e`.

| Comprobación | Ejecución | Resultado |
|---|---|---|
| R0 Rust, referencia 1.98.0 y compatibilidad adicional 1.98.1 | [34199496426](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34199496426) | Conforme |
| Conformidad SVP | [34199496454](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34199496454) | Conforme |
| R0-8 nativa | [34199496495](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34199496495) | Conforme |
| Paridad nativa/WASI/navegador | [34199496428](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34199496428) | Conforme; informes GH-LIG literalmente idénticos |

**Resultado leído en los registros completos:** 48 transportes admitidos, 16 recuperaciones F0, 16 recuperaciones con S declarada, 16 controles conservados en H y ocho pérdidas H demostradas. Ocho pruebas Rust nuevas satisfactorias; se mantienen las 211 unitarias previas. El observador rechaza 16/16 ataques por la causa fijada y admite el control reserializado. La campaña previa de núcleo conserva 43/43 mutantes dirigidos detectados, sin supervivientes ni inválidos. No se suman ambas campañas como un porcentaje universal.

| Paquete de evidencia | Artefacto | Bytes ZIP declarados por GitHub | SHA-256 declarado por GitHub |
|---|---|---:|---|
| directed-mutation-sensitivity | 10045252545 | 161954 | `b15f36e615ae86d9b7cf96b6dea74a27ab5d281d5faa3de89b8bbc3e581b0ed1` |
| oracle-sensitivity | 10045231173 | 5014 | `f2f4651664e15d04f7969752dac30e296a5d3e961c3916f4358c87952d45cff7` |
| gh-lig-documental | 10045225622 | 6979 | `5055e58b73dd70ad0d6514bda2e2c717cee396e0842c42abff92fe43ca182533` |
| r0-wasm-three-way-parity | 10045257855 | 3382205 | `0572e01f215520ac5a64c704f77088345f956ed00f84892702fd8f09570da7be` |

Las huellas de ZIP proceden de metadatos de Actions; no se declara recálculo local de esos archivos. Las fuentes y entradas están comprometidas, los registros de ejecución se han inspeccionado y la campaña es reproducible por sus órdenes públicas.

**Estado actual:** `CANDIDATA_VERIFICADA_NO_PROMOVIDA`, PR #81 sobre #80. La matriz queda contrastada en su inventario y en el transporte documental ensayado; su suficiencia como entrega de fila 7 requiere revisión, no la decide el verificador. Las doce SP integradas siguen no ejecutadas. La cola de evidencia no altera el núcleo, las sondas ni sus esperados originales; la comprobación de la cabeza final se enlaza en la PR. Continúan sin promoción #79/#80/#81 y sin emisión a CYB. No queda por realizar este transporte; permanecen el contraste externo y la decisión sobre el alcance de la candidata completa. Ninguna operación excluida se ofrece por el hecho de estar documentada.

<a id="retp-100"></a>

### RETP-2026-100 — Recálculo externo de huellas contractuales GH-LIG

**Entrada exacta:** `b58b4c88d30c1de3548cac9b4ac16ebbf7250717`, PR #81 no promovida. La revisión externa aportada por el Director reproduce las pérdidas y transportes, pero refuta que el observador compruebe el valor de `contract_sha256`. Se reproduce el defecto en el observador anterior con 48 huellas a cero y entradas sintéticas derivadas de G/H; no se atribuye ese control a una ejecución Rust.

**Decisión previa:** aplicar [GH-LIG §7](../arquitectura/RESOLUCION_DE_PERDIDAS_GH_Y_TRANSPORTE_LIG_2026_09_08.md#7-rectificacion-del-observador-contractual--retp-100). Publicar la representación contractual completa, cotejarla con el testigo y recalcular su codificación y SHA-256 fuera del emisor. La batería atacará tanto huellas aisladas como falsificaciones simétricas de H y modificaciones coherentes de contrato/huella. El esquema del informe de pruebas pasa a 0.2; LIG/0.1, gramática, serializador y realización productiva permanecen.

**Rectificación de alcance:** sólo #81 conserva intactos los archivos de realización del núcleo. La pila #79/#80 incluye nuevas capacidades y guardas de bienformación, que sí cambian la aceptación de entradas. El número de inserciones no demuestra identidad semántica. La prosa de la matriz permanece sometida a revisión humana, expresamente fuera de lo que acredita el verificador.

**Realización candidata:** contrato íntegro en la sonda, codificación JavaScript independiente y correspondencia completa con la plantilla/testigo recibidos. El vector fijo de RETP-098 concuerda con el nuevo codificador. La autoprueba reúne 28 ataques previstos: los 16 anteriores (MG09 ahora exige recálculo) y doce nuevos, incluidos F0/HS, ambas H falsas, todas las huellas cero y contratos modificados con huella recalculada. La ejecución integrada aún está pendiente.

**Primer ensayo de corrección:** `e40473aaabeef59761bc613549e30356c0b21fa8`: R0 Rust, conformidad y R0-8 conformes; recálculo 48/48 y ataques 28/28 en nativo/WASI. La ejecución de paridad `34202052200` falló al capturar `PENDIENTE` en el navegador; ese corte no pasa la puerta completa. Se ajusta la sonda de navegador para cargar ambas entradas antes de compilar/instanciar WASM síncronamente, conservando presupuesto e igualdad literal. El ensayo posterior debe verificarse de nuevo.

**Estado:** `CORRECCION_DEL_OBSERVADOR_PENDIENTE_DE_PRUEBA`. Se conservan los resultados y límites de RETP-099 en su corte; el nuevo incremento requiere su propia verificación. Fila 7 abierta; candidatas sin promover; doce SP integradas sin ejecución acreditada.


**Verificación de la corrección:** `acfd168670ca69af33cc2966d9fce0fc9dd3adcd`, árbol `bbc4a4d4ee7a5937e401cfed993e778abe5f7745`. La composición de Actions `5d6ad5fd32c00d41e80efa4180c37c58456df475` tiene ese mismo árbol, con padres `d374e1cb…` y `acfd1686…`; no es integración en main.

| Comprobación | Ejecución | Resultado |
|---|---|---|
| Conformidad SVP | [34202350649](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34202350649) | Conforme |
| R0-8 Baseline nativa | [34202350672](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34202350672) | Conforme |
| R0 WASM paridad nativa y navegador | [34202350725](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34202350725) | Conforme |
| R0 Rust | [34202350608](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34202350608) | Conforme |

Los registros completos de Rust y paridad acreditan **48/48 huellas contractuales recalculadas**, 28/28 ataques rechazados por su causa, control reserializado admitido e identidad literal de informes en nativo/WASI/navegador. Se conservan 48 transportes, 16 recuperaciones F0, 16 HS, 16 controles H y ocho pérdidas H. La campaña previa conserva 43/43 mutantes dirigidos detectados; no se suman esas muestras como cobertura universal.

MH01/MH02 detectan F0/HS falsas; MH03 detecta ambas H con el mismo valor falso; MH04 detecta las 48 huellas cero. MH05–MH08 y MH12 alteran contrato y recalculan su huella: se rechazan por divergencia del testigo. MG09 ya no se presenta como vigilancia del valor por mera desigualdad: ahora falla por `CONTRATO_RECALCULO`. El codificador externo concuerda con el testigo fijo `beff99707d648d591714e431b462bf61546da931771a6168cd80b1c8037f7dc0`, anterior a esta sonda.

| Artefacto | Identificador | Bytes ZIP declarados por GitHub | SHA-256 declarado por GitHub |
|---|---|---:|---|
| directed-mutation-sensitivity | 10046352660 | 161959 | `253f11e95dd90e1ab1df73477bb25060a5632431676a451ca79a5861d238753a` |
| oracle-sensitivity | 10046328397 | 5015 | `90f6479bc3d486523bf90043fc903be96675269cf62c43ae969235e266463432` |
| gh-lig-documental | 10046322340 | 12124 | `dfa4119bcc3c8aaae9cb21dde020ec61ec62a0d249e6a18f9a7632dac7054e7f` |
| r0-wasm-three-way-parity | 10046354784 | 3418616 | `64368eb3c321a719d947d7769129ca7f43bce011ef7b5ca2708182f6399e4cf5` |

Se han inspeccionado ejecuciones y registros. Las huellas ZIP son metadatos de GitHub, no recálculos locales. Las entradas y el vector previo de codificación permanecen intactos. La primera ejecución fallida se conserva arriba; no se ha omitido ni reinterpretado como conforme. La corrección de sincronización del navegador conserva presupuesto e igualdad literal.

**Estado actual:** `CORRECCION_VERIFICADA_NO_PROMOVIDA`, PR #81. La cola registral posterior no cambia sondas, codificador ni esperados; la verificación de su cabeza exacta se identifica en la PR. Este cierre se limita al observador contractual. La semántica completa del programa portador, la ejecución del emisor y la suficiencia de la prosa de la matriz no quedan probadas por el informe aislado. Continúan fila 7 abierta, doce SP integradas no ejecutadas y revisión de candidatas #79–#81 pendiente antes de promoción.

## 4. Estado de continuidad

**Sucesión RETP-100, 08/09/2026 (candidata):** corregido y verificado el recálculo externo de huellas contractuales GH-LIG. La pila sigue no promovida y la prosa de resolución requiere revisión humana.

**Sucesión RETP-099, 08/09/2026 (candidata):** PR #81 verifica transporte G/H por LIG y conserva el inventario 15/44/81 con límites por operación. #79/#80/#81 siguen no promovidas; fila 7 abierta. Este asiento sucede a las descripciones candidatas anteriores sin retroeditarlas.

**Sucesión RETP-097, 08/09/2026 (candidata):** la coherencia local H06/H07 se ha verificado sobre `abe5e544…`, con cuatro flujos conformes. DFL-005 recibe contrato y refutadores previos, sin atribuirle todavía realización. PR #79 no promovida.

**Sucesión RETP-096, 08/09/2026:** las PR #77 y #78 están integradas en orden. El corte actual de entrada a la continuidad es `main@1706099aef4a0e3846706c3963e7c76313adaf68`; la fila 7 permanece abierta. Las entradas candidatas siguientes son antecedentes conservados, no el estado actual.

**Sucesión RETP-095, 08/09/2026 (candidata):** el testigo E011 y su oráculo se han corregido y verificado sobre `461acc633d364a2eca964539a3835529fbc72c58`, con los cuatro flujos conformes. Se preservan la guarda semántica existente y la deuda de emisión diagnóstica; no hay promoción ni cierre de fila 7.

**Sucesión de la PR #78, 08/09/2026 (candidata):** RETP-093 enlaza el subcierre local; RETP-094 corrige E115 y la numeración de deuda. El corte material `bf660b00c0c2b38c7e5e4327b1e89f0ec81348be` ha superado los cuatro flujos; su evidencia se identifica en RETP-094. Ninguno de los asientos constituye una fusión; la fila 7 sigue abierta.

**Sucesión registral de 08/09/2026 (PR #77, candidata):** RETP-091 recibe G/H y RETP-092 restituye el mandato del español. Estos asientos describen una candidata sin integrar; `main@bc3b22c9` conserva RETP-090. La fila 7 permanece abierta y la fila 8 no se activa. El estado B2 que sigue conserva su alcance histórico.

FFL-A, FFL-B, FFL-C y FFL-E permanecen cerrados; FFL-D permanece pendiente dentro de su alcance propio.

El estado de realización posterior al cierre correctivo B2 es:

```text
R0 = CERRADO, incluido el perímetro correctivo de DFL-007
R1 = CERRADO y revalidado sobre la base corregida
R2 = ABIERTO; levantada la suspensión específica causada por DFL-007
R3 = NO INICIADO
R4 = NO INICIADO

Garantía I  = NO_PROBADO
Garantía II = NO_PROBADO
```

La deuda técnica restante permanece registrada en `REGISTRO_DEUDA_VIVA_DEL_FRENTE_FINAL_DEL_LENGUAJE_SV.md`. El cierre de DFL-007 no materializa `ConflictOperator` ni completa J2.3 para concurrencia en régimen `General`. La verificación externa independiente del corte final permanece pendiente y se documentará separadamente.

## 5. Numeración registral

La numeración RETP se mantiene en `REGISTRO_EVOLUCION_TECNICA_PROYECTO.csv`.


<a id="retp-101"></a>

### RETP-2026-101 — Dependencias de verificación y preparación G/H sin Python

**Entrada:** `ccc007578e23df3a304208733687824e2f241438`, PR #81 no promovida. Se leen Pilares RETP-073, perfiles RETP-075, secuencia rectora y sucesiones RETP-082/096…100. El mandato del Director exige entrega final sin dependencia de Python; no se presume cumplido por haber retirado el compilador antiguo.

**Contrato previo:** [dependencias y entradas G/H](./DEPENDENCIAS_DE_VERIFICACION_Y_ENTRADAS_GH_2026_09_08.md). El incremento prevé retirar dos de los 19 scripts Python: generación G/H mediante herramienta Rust separada y referencia LIG mediante el codificador externo ya existente. GNU Coreutils/sha256sum permanece declarado como herramienta de preparación; Node como observador. El generador no importa sv_core. Los 17 Python restantes y la prueba de distribución final autónoma conservan su condición pendiente.

**Oráculos previos:** las 48 entradas mantendrán bytes y huellas, salvo el comentario de procedencia; el testigo G/H y el vector fijo LIG permanecen intactos. Dos lectores independientes rechazarán números fuera del subconjunto documental antes de perder representación, claves índice, duplicados, UTF-8 inválido y sustitutos aislados. No se restringe Nat ni se transforman números de dominio en cadenas. Se conservarán las 28 mutaciones y los tres destinos de RETP-100.

**Estado inicial:** `CONTRATO_PREVIO_IMPLEMENTACION_PENDIENTE`. No se declara todavía resultado dinámico ni se cambia el estado de #81, fila 7, las doce SP o Q0. Ningún README ni acta histórica recibe una edición.

**Realización verificada:** contrato previo `9f1f39328e363c92d17d2aaf3fb0e51efff23930`; material `a20afe9d76da173295f5c123614189b31d705974`; árbol `0cff4a5b0b907f1105e0519793fb9a56e2e6497d`. La [PR #82](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/pull/82) se apila sobre `ccc007578e23df3a304208733687824e2f241438` de #81. La fusión virtual comprobada `3a09cbdc7ffcadc69edd46af5297e381223c641d` tiene el mismo árbol material y padres `ccc00757…` y `a20afe9d…`; ninguna candidata se ha promovido.

| Comprobación sobre el material | Ejecución | Resultado |
| --- | --- | --- |
| R0 Rust, incluida compatibilidad adicional | [34209375380](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34209375380) | Conforme |
| Conformidad SVP | [34209375465](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34209375465) | Conforme |
| R0-8 nativo | [34209375394](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34209375394) | Conforme |
| Paridad nativa, WASI y navegador | [34209375404](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34209375404) | Conforme |

La referencia es Rust/Cargo 1.98.0 sobre Ubuntu 24.04. Las pruebas nuevas dan 7/7 en Rust y 6/6 en JavaScript, con causas fijadas antes de ejecutar. La herramienta autónoma regenera los 48 datos sin alterar un byte; sólo cambia el comentario de procedencia de su archivo. El vector fijo LIG mantiene `beff99707d648d591714e431b462bf61546da931771a6168cd80b1c8037f7dc0`. El espacio de trabajo conserva 211 unitarias de `sv_core` y todas sus suites sin fallos; el corpus da 14/14 válidos y 106/106 inválidos. Se detectan las 43/43 mutaciones previas, sin supervivientes ni inválidas.

El observador mantiene 48 transportes y 48 huellas recalculadas desde el contrato cotejado, 16 recuperaciones F0, 16 con información lateral, 16 controles H y ocho pérdidas de H. Sus 28/28 ataques caen por la causa exigida; el control reserializado es admitido. Los informes de transporte conservan identidad literal nativo/WASI/navegador. Esto preserva RETP-100 y no constituye una segunda semántica de SV.

| Artefacto publicado por GitHub | Identificador | Bytes | SHA-256 del archivo comprimido según GitHub |
| --- | --- | ---: | --- |
| gh-lig-documental | 10049139187 | 12124 | `4c90cad004b211e6bde1845e3b9f6ac6d4c3472aa9e9928b6b0ef90f994f4800` |
| oracle-sensitivity | 10049145180 | 5014 | `4933c69e1ec5ec3512b79ee1889e032742bce259b3f827808a21ce97e1310b9c` |
| directed-mutation-sensitivity | 10049171351 | 161962 | `4ae9652791e043bc396982b65a101ad3223aff62a53dfc0665cbc0a6a91d880f` |
| r0-8-baseline-native | 10049143461 | 414322 | `4d1c120c49e0b5c6d1ac768a88fa64bf879d24605c61c20a292fb020b77639de` |
| r0-wasm-three-way-parity | 10049167252 | 3418646 | `84f4a4722d7a07414908f585582dc1942a60ed309b62e6c55e403c4015c9bc74` |

Los resultados dinámicos se cotejan con los registros de ejecución. Los bytes y huellas de esta tabla proceden de los metadatos de GitHub; no se afirma una descarga y reverificación local de los archivos comprimidos. Las modificaciones posteriores a `a20afe9d…` sólo inscriben esta evidencia; su cabeza y comprobaciones figuran en la PR.

**Estado actual:** `CORRECCION_VERIFICADA_NO_PROMOVIDA`. Se han retirado dos archivos Python, quedan 17 bajo `tests/` y también fragmentos e invocaciones Python en CI. No se presenta el recuento de extensiones como inventario completo de dependencias. Node y GNU Coreutils permanecen explícitos. La distribución final sin Python y su prueba en entorno limpio, la revisión externa, la resolución completa de fila 7 y la ejecución de las doce SP permanecen pendientes. Acta del español, README y repositorios de dominio intactos.


<a id="retp-102"></a>

### RETP-2026-102 — Candidata completa y reproducción Rust sin intérpretes

**Mandato:** revisión externa fuerte sobre la candidata completa de fila 7 antes de CYB; se suprimen las pausas para revisión externa entre incrementos. Entrada `2f4581cc80307053e2b93b3f2e3be3a3caac8d82`. [Contrato previo y resolución de alcance](../arquitectura/CANDIDATA_DE_FILA_7_Y_REPRODUCCION_SIN_INTERPRETES_2026_09_08.md).

**Obligaciones previas:** paquete determinista de fuentes Rust y entradas literales, sin Python/JavaScript ni binarios previos; inventario de integridad y controles causales de alteración; construcción offline y pruebas en Ubuntu 24.04 sin intérpretes Python/Node; mantenimiento de los cuatro flujos y del observador externo. La herramienta de aislamiento no constituye plataforma.

**Estado inicial:** `CONTRATO_PREVIO_IMPLEMENTACION_PENDIENTE`. No se declara todavía reproducción aislada ni candidata material completa. La auditoría final abarca main@1706099… hasta el corte final; no sólo la última PR. SP/Q0 y fila 7 conservan sus límites; acta del español intacta.

**Realización comprobada:** contrato previo `66f22db1324411fbc40e8adf3a5f5f15c7b4d3d7`; material `bb23381ba63a0512180ffb80f849a7241520b4c8`; árbol `10101231bdc753516fb4f21155774508cbde46b5`. [PR #83](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/pull/83) se apila sobre #82 en `2f4581cc80307053e2b93b3f2e3be3a3caac8d82`. La fusión virtual `9ce6747562385c9201cb8835dc72253d7a07a619` tiene esos dos padres y el mismo árbol; el nuevo flujo comprueba directamente la cabeza material. Las cinco ejecuciones terminaron correctamente.

| Comprobación material | Ejecución | Resultado |
| --- | --- | --- |
| R0 Rust y compatibilidad adicional | [34212583875](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34212583875) | Conforme |
| Conformidad SVP | [34212583972](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34212583972) | Conforme |
| R0-8 nativo | [34212583946](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34212583946) | Conforme |
| Paridad nativa, WASI y navegador | [34212583932](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34212583932) | Conforme |
| Fuentes y ejecución sin intérpretes | [34212583983](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34212583983) | Conforme |

**Prueba aislada:** paquete de 227 archivos Git literales y dos objetos de inventario, sin Python/JavaScript ni binarios previos. Dos preparaciones producen el mismo archivo `fila7-fuentes.tar.gz`, SHA-256 `9f8cd42a400c1f908926735f2f82785b7bfd6423c1e0e6a9f1bbe64a7f9b268d`. Los cuatro controles de embalaje caen por `PAQUETE_TIPO`, `PAQUETE_INVENTARIO`, `PAQUETE_AUSENTE` y `PAQUETE_HUELLA`; el control íntegro pasa. Esta huella procede de la ejecución identificada; no se confunde con la del ZIP de custodia.

El entorno usa Ubuntu 24.04, imagen base `sha256:33ceb71981b602c1a7443a53469e4dba065f7503eab3078a2d7a57a2ab987517` e imagen ejecutada `sha256:b6dbb24eaa887ddd63c943664d64e771068c994737b86cda55916ad3062b97f2`. Se preserva su inventario de paquetes. Rust `1.98.0 (88d9e12ae 2026-08-18)` y Cargo `1.98.0 (797e8a9bc 2026-08-05)` están montados desde la herramienta de referencia. La ausencia de intérpretes Python/Node se comprueba por ejecutables y paquetes; sólo se montan paquete, herramienta Rust, conductor Bash y salida. Construcción y pruebas con red deshabilitada, Cargo offline y directorio Cargo vacío. La preparación de la imagen sí utiliza red; no se afirma construcción bit a bit del compilador o de cualquier entorno futuro.

Pasan 348 pruebas Rust del espacio de trabajo, incluidas 211 unitarias del núcleo y 17 de documentación ejecutable; también las suites LIG de 45 casos, contexto de 11 y G/H de 8. La regeneración comprueba los 48 datos, las dos sondas se ejecutan y la CLI admite ambos perfiles. El testigo de posición cero produce retorno 1, IR vacía y su causa exacta prevista. Tras la ejecución, los fuentes inventariados conservan sus huellas. Node ejecuta **fuera del contenedor** el observador externo: 48 huellas recalculadas, 16 recuperaciones F0, 16 HS con S declarada, 16 controles H y ocho pérdidas; 28/28 ataques detectados, incluido falsear ambas H simétricamente. El resto de los flujos mantiene 14/14 válidos, 106/106 inválidos, 43/43 mutaciones detectadas y paridad literal nativa/WASI/navegador.

| Artefacto publicado por GitHub | Identificador | Bytes | SHA-256 del ZIP según GitHub |
| --- | --- | ---: | --- |
| fila7-candidata-sin-interpretes | 10050429631 | 626579 | `90d8f401e10f405839974eb2e181b9fd5b01f478486bb819f4229a7fa2e7e646` |
| gh-lig-documental | 10050412775 | 12124 | `62bc21f36ea80e4f60a5d8add4b334083b20c9990de5600e870a97a718d41ffe` |
| oracle-sensitivity | 10050419176 | 5016 | `500f4d322936bf589dc0004db4d69badd773a4148ed64b21b0cd4b8ee664bb2c` |
| directed-mutation-sensitivity | 10050441019 | 161963 | `e59e60da6560e2916e813579f47d43b2a54ecfeb4ee94b3f4532788cdb71bdad` |
| r0-8-baseline-native | 10050416417 | 414317 | `de26cd00a1794f8028ab0f450f50326d51f00dae9c177b6529401ef3a8cb1db5` |
| r0-wasm-three-way-parity | 10050442974 | 3418627 | `6585831161aac1e8b80762e973fe2e8a29cfe3a1784364764c666192b27ca9ba` |

Los tamaños y huellas de los ZIP se cotejan con metadatos de GitHub, no se presentan como descargas reverificadas localmente. La evidencia de comportamiento procede de los registros de los trabajos. La cola registral posterior a `bb23381…` sólo inscribe estos resultados; su cabeza, ejecuciones y paquete correspondiente quedan identificados en la PR. El cambio de `CORTE_GIT.txt` genera una huella de paquete nueva incluso si los fuentes del producto permanecen idénticos.

**Estado: `CANDIDATA_COMPLETA_PARA_ADVERSARIAL_NO_PROMOVIDA`.** El alcance total desde `main@1706099…` incluye 578 inserciones en `sv_core/src` de #79/#80; no se presenta como núcleo intacto. La matriz cubre 15 requisitos, 44 formulaciones y 81 relaciones con responsables y límites. Quedan la revisión externa fuerte del conjunto y la decisión de entrega; no hay promoción, apertura CYB ni cierre Q0/SP. Persisten 17 archivos Python e invocaciones de CI en el repositorio completo. La ruta Rust aislada queda acreditada para esta candidata; no equivale a retirada global de herramientas ni a la distribución final. README, acta del español y dominios no cambian.


<a id="retp-103"></a>

### RETP-2026-103 — Adversarial completa y corrección de las fronteras de verificación

[Acta, contraejemplos, contrato previo y límites](ADVERSARIAL_DE_FILA_7_Y_FRONTERAS_DE_VERIFICACION_2026_09_08.md). Entrada `316facc2284858600d2c72fa44e8c715ab047373` sobre `main@1706099aef4a0e3846706c3963e7c76313adaf68`. Se reproducen AF-01 (JSON con miembros repetidos admitido), AF-02 (FIFO omitido del inventario) y AF-03 (permisos no fijados cambian el paquete). La lectura del núcleo y los contrastes de procedencia no refutan la capacidad representacional declarada; no acreditan Q0 ni funciones excluidas.

**Estado inicial: `CONTRATO_PREVIO_CORRECCION_PENDIENTE`.** Se exige lectura estricta en la entrada efectiva, inventario de todos los tipos de archivo y reproducción bajo máscaras distintas; causas y controles previos se conservarán en las regresiones. Sin cambio del núcleo, README, acta del español ni dominios. Fila 7 permanece abierta; no se entrega candidata a CYB. Los 17 auxiliares Python y usos de CI siguen declarados, sin confundirse con el paquete autónomo probado.

**Resultado:** contrato previo `f6986cf828fb9e4047f0f68d1276d22b4835d29f`; material `0b7fa120f3f09f98399f07bf87cda9410ca1b54e`, árbol `b66ac3cbc4287d594b3b97b214ef81c171b4ace2`. Los cinco flujos 34224986578, 34224986677, 34224986628, 34224986579 y 34224986696 son conformes; detalle, enlaces y huellas descargadas en el acta vinculada. Once ataques por la CLI real y ocho ataques de paquete detectados por causa; permisos 0000/0077 producen paquete idéntico. Se conservan 348 pruebas Rust aisladas, corpus 14+106, 43 mutantes, 28 ataques semánticos, 48 huellas y paridad de destinos. No hay cambio de sv_core; el ejecutable descargado es idéntico al de #83.

**Estado vigente: `ADVERSARIAL_CONCLUIDA_CORRECCIONES_VERIFICADAS_NO_PROMOVIDAS`.** Candidata técnicamente apta en su alcance representacional para integración gobernada y posterior entrega. Quedan integración y decisión registral de entrega; no se declara fila 7 cerrada ni se abre CYB. No quedan AF-01/02/03 sin resolver en la candidata. Se mantienen Q0/SP sin ejecución integrada, las obligaciones ejecutivas posteriores y los 17 auxiliares Python residuales. La autonomía del paquete no cierra la retirada global ni la revisión del español.


<a id="retp-104"></a>

### RETP-2026-104 — Identidad de la matriz revisada y protección de sus tratamientos

**Entrada exacta:** PR #84 en `e13dc8390e72848b4419ebe229d1b81666546eaf`, árbol `f439f6b405ab4534a6b0e670aff4b8176e739060`. Rigen la fila 7, PT01/PT03/PT04/PT14, GH-LIG/0.1 y RETP-103. La matriz comprometida `tests/row7_gh/resolucion.json` tiene SHA-256 `1927c3ac2605f01128d46f2aaed74516d9915463c5949625aabbd8bd324ac15f`. No se modifica su contenido.

**Contraste recibido y reproducido:** la variante conflictiva repetida en el informe y `row7_closed` repetido en la matriz ya se rechazan por `JSON_CLAVE_REPETIDA` en esta cabeza. Los puntos de lectura de informe, matriz, proyección y fuentes fijadas utilizan el lector estricto. Sin embargo, sustituir `treatments[0].available` por una afirmación de ejecución completa Q0 sigue obteniendo conformidad, tanto por la CLI con `--matriz` como por la función exportada `verify`. La ausencia de juicio semántico automático sobre la prosa estaba declarada; faltaba garantizar la identidad del documento revisado al que se refiere el resultado.

**AF-04: identidad de matriz no fijada.** La objeción afecta al observador y al gobierno documental; no refuta el recálculo de las 48 huellas ni la realización Rust. El dictamen de aptitud de RETP-103 queda condicionado a esta corrección adicional. Se mantienen AF-01/02/03 corregidos y sus pruebas, sin repetir trabajo de dominio.

**Contrato previo de la corrección:**

1. Toda matriz recibida por la CLI, incluida la ruta ordinaria y `--inventario`, se analizará estrictamente antes de verificar su huella literal contra el SHA-256 anterior. Un duplicado conservará su causa de lectura; un documento distinto y bien formado se rechazará por `MATRIZ_HUELLA`. La opción `--matriz` permite cambiar la ubicación del documento exacto, no sustituir la decisión revisada.
2. La matriz de referencia se cargará con ese mismo anclaje. Las funciones exportadas que reciben objetos cotejarán el documento completo con esa referencia, incluidas prosa, orden, tratamientos y cualquier campo no comprobado individualmente. La discrepancia de contenido bien formado tendrá causa `MATRIZ_CONTENIDO`. Las comprobaciones estructurales previas conservan sus causas actuales.
3. El resultado identificará la huella de la matriz revisada y distinguirá igualdad documental de suficiencia clínica. `decision_sufficiency_automatically_proven` seguirá siendo falso. Cambiar la matriz requerirá nuevo corte revisado y actualización expresa del ancla; no se regenerará la huella automáticamente desde la entrada que se juzga.
4. Se conservarán los 28 ataques semánticos y once ataques de entrada por la CLI real. Se añadirán alteración de prosa, reserialización de matriz, una propiedad adicional y la variante conflictiva del informe. El control positivo reserializará sólo el informe y conservará los bytes originales de la matriz. La reserialización de la matriz deja de ser control positivo porque su identidad literal pasa a formar parte del contrato.
5. Una batería recorrerá los trece tratamientos y sus ocho campos textuales distintos del identificador (operación, contrato, capacidad, exclusión, responsable, etapa, retorno y evidencia): 104 sustituciones independientes deben ser rechazadas por `MATRIZ_CONTENIDO` también en la API de objetos. No basta con proteger únicamente `available` ni sólo la CLI.

**Estado inicial:** `CONTRATO_PREVIO_CORRECCION_PENDIENTE`. Se exige comprobación local causal y los cinco flujos sobre cabeza exacta. El núcleo, LIG, Gramática, IR, corpus, matriz, README, acta del español, RETP-092 y dominios permanecen fuera del cambio. Se mantienen los 17 auxiliares Python y sus usos de CI declarados; la generación Rust de entradas de prueba no constituye interpretación productiva adicional de la DSL ni elimina por sí sola toda dependencia. No hay promoción, cierre de fila 7 ni apertura CYB.


**Corrección material:** contrato previo `722a4146e051ec1518ff402291da9606a3e4125b`; realización `eef05771aa2b5101571b3de3d58c41bcb4d64a4c`, árbol `837e3ce5986b1f6490b489e1eaad4b75e51fc334`, en la misma PR #84. La fusión virtual `9bc305cc61b69d31a417a14caa08bc8853567ed8` tiene los padres #83 y esta candidata y el mismo árbol. La matriz conserva literalmente su SHA-256 de entrada.

| Flujo de la cabeza material | Ejecución | Resultado |
| --- | --- | --- |
| R0 Rust y compatibilidad adicional | [34227864840](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34227864840) | Conforme |
| Conformidad SVP | [34227864842](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34227864842) | Conforme |
| R0-8 nativo | [34227864845](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34227864845) | Conforme |
| Paridad nativa, WASI y navegador | [34227864830](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34227864830) | Conforme |
| Fuentes y ejecución sin intérpretes | [34227864828](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34227864828) | Conforme |

**Resultado causal:** 28/28 ataques semánticos anteriores, 15/15 ataques de bytes por la CLI real y 104/104 sustituciones de los textos de los trece tratamientos por la API, sin supervivientes. Las duplicidades conservan `JSON_CLAVE_REPETIDA`; la sustitución del documento literal cae por `MATRIZ_HUELLA`; la alteración de contenido por objetos cae por `MATRIZ_CONTENIDO`. La comparación de datos propios, orden y valores evita que `toJSON` o un acceso implícito sustituya el documento comparado. Una sonda adicional confirma rechazo de la prosa falsa por ambas rutas CLI, incluida `--inventario`, y rechazo de un `toJSON` que intentaría ocultarla en la API.

El resultado contiene `reviewed_document_sha256` y `reviewed_document_content_matches=true`; mantiene `decision_sufficiency_automatically_proven=false`. La huella identifica el documento candidato revisado en este corte, no un estado futuro de integración. Una modificación legítima de la matriz requiere otro corte revisado y el ancla correspondiente. El control positivo conserva sus bytes exactos; sólo el informe puede reserializarse sin cambiar esa identidad.

Se conservan 48 huellas contractuales recalculadas, 16/16/16 y ocho pérdidas H; 43/43 mutaciones dirigidas detectadas; corpus 14/14 válidos y 106/106 inválidos; 348 pruebas Rust en el entorno identificado sin Python/Node, sin red y Cargo offline. El observador Node permanece fuera del aislamiento. AF-02/03 conservan los ocho ataques de paquete y reproducción bajo permisos distintos. No se cambia el generador Rust ni el carácter generado de las entradas de prueba.

**Custodia descargada y verificada localmente:** artefacto `10056512017`, 628043 bytes; ZIP SHA-256 `2ba554008e6ab28d0b405b9a2b7fb79e973977b8a464f0b73208820ca990df2e`. Paquete interior `c2d0a1217d5f642da3566cf5a4ba477d98f622478031506b7886ee30ce1988a1`. Ejecutable `cb0db4112cea29ed01972f88a549b0add8bb43a261034f0e8f37cb04974b8e7a`, idéntico al anterior. El informe `verificacion-externa.json` conserva los quince ataques de entrada y las 104 sustituciones, además de los 28 ataques previos; `ejecucion.log` conserva las pruebas aisladas.

**Estado vigente:** `MATRIZ_REVISADA_FIJADA_Y_VERIFICADA_NO_PROMOVIDA`. AF-04 queda corregido en la candidata y se levanta la reserva añadida al dictamen de RETP-103. La aptitud sigue limitada al alcance representacional examinado y a la integración gobernada con decisión de entrega; no acredita verdad clínica de los textos ni ausencia universal de defectos. No hay promoción, cierre registral de fila 7 ni apertura CYB. DFL-001 general, DFL-013, los 17 auxiliares Python y restantes límites conservan su condición. La cola posterior al material sólo registra estos resultados; cabeza final, nueva huella del paquete y sus cinco flujos quedan identificados en la PR.


<a id="retp-105"></a>

### RETP-2026-105 — Integración de fila 7 y entrega representacional a Ciberseguridad

**Decisión humana:** el 08/09/2026, Juan Antonio Lloret Egea autoriza expresamente fusionar la PR #85 y completar inmediatamente el registro de entrega. La instrucción de Ciberseguridad ya estaba aprobada; faltaba la entrega técnica. Su autorización de continuación permanece vigente y no se sustituye por una petición nueva para empezar el catálogo.

**Efectividad de este asiento:** la integración técnica descrita abajo ya está realizada. La entrega y el cierre de la fila 7 en su alcance representacional adquieren efecto al incorporarse este asiento CSV/Markdown a `main`. Mientras el asiento esté únicamente en una rama, sigue pendiente ese último acto registral. La confirmación que incorpora el asiento es el corte documental de entrega; no se inventa su identidad antes de existir. La PR que lo integra identifica su cabeza, árbol y comprobación.

**Lectura rectora y ámbito:** `AGENTS.md`, Pilares RETP-073, perfiles RETP-075, acta completa de transición con tabla de catorce filas y sucesiones, contratos de fila 7 y RETP-096…104. El corte técnico examinado es `ab61d9bb7a2002d3a4a389e292c2a9b0a850d264`; se coteja su integración real. Se aplica la salida de fila 7 y se entrega a fila 8, PT01/PT03/PT04/PT14. No se modifica la tabla ni se constituye un universo desde el Lenguaje.

#### Identidad de la integración realizada

| Objeto | Identidad comprobada |
|---|---|
| Repositorio | `juantoniolloretegea/SV-lenguaje-de-computacion` |
| Base de integración | `1706099aef4a0e3846706c3963e7c76313adaf68` |
| Cabeza aprobada y probada | `ab61d9bb7a2002d3a4a389e292c2a9b0a850d264` |
| Integración real de PR #85 | [`140d319995a5df685860b348c0fd086ae6130faf`](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/commit/140d319995a5df685860b348c0fd086ae6130faf) |
| Fecha de integración | 08/09/2026, 15:14:58 UTC; 17:14:58 Europe/Madrid |
| Árbol integrado, idéntico al probado | `46b2bbdbc65799c2753a2cd30fba343dde8140e2` |
| Padres de la integración | La base y la cabeza anteriores, en ese orden |
| Verificación GitHub | Firma verificada de la confirmación de integración |
| Historial conservado | Las 26 confirmaciones acumuladas de #79–#84; 70 archivos, 8387 inserciones y 5 eliminaciones frente a la base |
| Integración virtual previa | `b9f501073d99b39a72fca24441ffedba905e6c77`, con los mismos padres y árbol; distinta de la integración real |

La [PR #85](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/pull/85) reúne el conjunto previamente auditado. No añade una realización ni sustituye los objetos revisados. Las antiguas declaraciones de «no promovido» en RETP-097…104 describen sus cortes; esta sucesión establece la promoción actual sin retroeditar esos antecedentes. Las solicitudes apiladas quedan comprendidas en la integración y no constituyen seis trabajos aún por fusionar.

#### Comprobación de la cabeza exacta contra main

| Comprobación | Ejecución de PR #85 | Resultado |
|---|---|---|
| R0 Rust y compatibilidad adicional | [34242084924](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34242084924) | Conforme |
| Conformidad SVP | [34242084948](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34242084948) | Conforme |
| R0-8 nativo | [34242084923](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34242084923) | Conforme |
| Paridad nativa, WASI y navegador | [34242084881](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34242084881) | Conforme |
| Fuentes y ejecución sin intérpretes | [34242084883](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34242084883) | Conforme |

La identidad de árbol liga esas pruebas con la integración real; no se presentan como nuevas ejecuciones disparadas por el commit de fusión. Rust/Cargo 1.98.0 sobre Ubuntu 24.04 conserva el carácter de entorno de referencia del expediente; `stable` es compatibilidad adicional. Esta integración no identifica ni modifica por sí misma el despliegue de producción.

Se reciben los resultados de RETP-103/104 y de estos flujos: corpus 14 válidos y 106 inválidos; 43 mutaciones dirigidas detectadas; 48 transportes y 48 huellas contractuales recalculadas; 16 recuperaciones F0, 16 HS con información lateral declarada y 16 controles H, con ocho pérdidas H; 348 pruebas Rust del paquete aislado. Los 28 ataques semánticos, 15 ataques de bytes por CLI y 104 sustituciones de prosa por API permanecen como campañas distintas; AF-01…AF-04 quedan corregidos en su alcance. No son puntuación exhaustiva del repositorio ni demostración universal.

#### Paquete entregado y custodia

El objeto de fuentes entregado es `paquete/fila7-fuentes.tar.gz` del artefacto `fila7-candidata-sin-interpretes`, ID **10056736840**, [ejecución 34228422997 de la misma cabeza](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34228422997/artifacts/10056736840). Fue descargado y sus huellas se comprobaron antes de promover.

| Objeto | SHA-256 |
|---|---|
| ZIP descargado de custodia | `b4d310a8fd1fe55ecd114741eddc43c2639766fdf64264ce4cb09c3f7a615842` |
| Paquete interior de fuentes | `3ec9d06dfb184eb59249203b6758a2b433d9093e5db78593a51405a27013a398` |
| Informe G/H `ejecucion/gh.json` | `b38f85a2c07c12ea12930888a3659fe5decde55dac89c1c582ce00e77f7da074` |
| Matriz documental revisada `tests/row7_gh/resolucion.json` | `1927c3ac2605f01128d46f2aaed74516d9915463c5949625aabbd8bd324ac15f` |

La repetición de PR #85 publica además el artefacto **10062427504** en la [ejecución 34242084883](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34242084883/artifacts/10062427504), ZIP SHA-256 declarado por GitHub `87d3c84a225818ae5e76fa069f2d3e41109e9565a4df14e6ef6ae693e1b1d620`. Su ZIP se identifica por separado; no se intercambian ambas huellas.

El paquete contiene 227 archivos Git y dos objetos de inventario; `CORTE_GIT.txt` conserva la cabeza de fuentes `ab61d9bb…`. El corte de integración tiene el mismo árbol. Los archivos de este asiento son gobierno posterior, no una reconstrucción ficticia del paquete. La custodia de Actions tiene su régimen de conservación: el receptor verificará acceso y huellas al recibirla; una URL por sí sola no sustituye el artefacto. Los fuentes y herramientas de preparación permanecen localizables en la confirmación Git exacta. La preparación documentada en `docs/arquitectura/CANDIDATA_DE_FILA_7_Y_REPRODUCCION_SIN_INTERPRETES_2026_09_08.md` permite repetir el embalaje en ese corte.

#### Capacidades que recibe el segundo falsador

| Objeto o uso | Capacidad entregada y fuente | Límite que conserva |
|---|---|---|
| Compilación y contextos | ES/EN y ensamblaje; comprobaciones locales de TransitionData y coherencia estructural H06/H07, RETP-093/097 | No causalidad ejecutiva, continuidad persistente entre versiones ni CQ1–CQ6 completos |
| Ligaduras por operación | `sv_core::bindings`, LIG/0.1; identidad y versión exactas, instancias, destinos, usos ordenados, compartición explícita y referencias tipadas, RETP-098 | No autenticación material de autoridad, interpretación clínica ni ejecución productiva observación→Tri |
| Pérdidas recibidas G/H | GH-LIG/0.1, matriz 15 requisitos/44 formulaciones/81 relaciones y ocho pares documentales, RETP-099/100 | Recuperar con S no acredita H sola; transporte documental no ejecuta Q0 |
| Observadores y paquete | Contratos y controles de RETP-101…104, con entrada estricta, huellas recalculadas y matriz fijada | Igualdad de prosa no prueba su suficiencia semántica; paridad entre destinos usa una sola realización |

El juicio de salida acepta **ese alcance representacional** y su tratamiento explícito de las pérdidas para ser atacado por CYB. Se conserva el inventario por operación de `tests/row7_gh/resolucion.json`; ninguna operación que requiera capacidades excluidas se ofrece como ejecutable. La matriz y sus banderas `row7_closed=false` y `decision_sufficiency_automatically_proven=false` pertenecen al objeto documental candidato fijado. Este asiento gobierna el relevo posterior, sin alterar esos bytes ni hacer que el observador emita una certificación de cierre humano.

DFL-005 deja de ser ausencia de realización para LIG/0.1 y queda integrada **en ese subconjunto**; no se clausuran todos los campos de Domain/Agent ni la deuda general. DFL-001, DFL-003/004, DFL-006, DFL-009, DFL-011/012/013 y los demás pendientes conservan su sede y condición por operación. La [sucesión RETP-105 de deuda viva](REGISTRO_DEUDA_VIVA_DEL_FRENTE_FINAL_DEL_LENGUAJE_SV.md#relevo-retp-105) precisa los límites.

Permanecen 17 auxiliares Python y sus invocaciones de CI, además del observador Node. La ruta Rust aislada funciona sin esos intérpretes; no se declara terminada la retirada global ni la distribución final de la DSL. K1-T sigue sin producción habilitada; Q0 y SP-01…SP-12 no tienen ejecución integrada acreditada. La puerta algebraica, K2, el contrato operacional y R2/R3/R4 no se adelantan. El acta del español, RETP-092 y DFL-011 conservan el mandato íntegro de revisión de todos los repositorios antes del cierre nuclear.

#### Decisión y punto de comienzo del receptor

**Fila 7: completada y entregada en el alcance representacional declarado, al integrarse este asiento. Fila 8: receptor habilitado para comenzar su encargo; todavía no realizado ni certificado. Núcleo: no consolidado.**

El receptor es la unidad competente de Ciberseguridad Inteligente, en `SVperitus-dataset`, rama `dominio-ciberseguridad-inteligente`, bajo `dominios/ciberseguridad-inteligente/dominio-04-09-26/`. La instrucción aprobada está custodiada en [la confirmación 47dc27aec9e7b517c27cfcf39b7ad1b186d36a4c](https://github.com/juantoniolloretegea/SVperitus-dataset/commit/47dc27aec9e7b517c27cfcf39b7ad1b186d36a4c), ruta `dominios/ciberseguridad-inteligente/dominio-04-09-26/watson-biblioteca-ciber/Aprobada_INSTRUCCION_RELEVO_CIBERSEGURIDAD_INTELIGENTE_2026_09_08.md`. La referencia se debe leer en su repositorio y corte; no se presupone trasladada automáticamente a otra rama.

El **primer acto sustantivo** es fijar el perímetro y los criterios de admisión del catálogo profesional, en **Excel (.xlsx)** con tablas, filtros, fórmulas de control y trazabilidad por entrada, conforme al mandato humano. Se reciben programas universitarios y certificaciones pertinentes, estándares y normativa de ciberseguridad e IA con su naturaleza diferenciada. El catálogo precede a la elección de operación y a la constitución de universo.

La unidad CYB aplicará el método reconciliado de Inmunología; no heredará parámetros, agrupaciones ni salidas clínicas. Dominio, agente y cobertura conservan sus contratos distintos. Las fuentes externas entran capturadas, versionadas y con huella; sus cambios no se convierten en observaciones del sistema. Las magnitudes exactas, la adquisición separada y el juicio por operación conservan las condiciones de la instrucción. El Lenguaje entrega una candidata falsable, no un universo CYB predefinido.

Al comenzar, el receptor registrará su comprobación de estas identidades y la disponibilidad del paquete en su sede. **La entrega emitida no se confunde con una recepción ya ejecutada por CYB.** No se exige repetir la autorización ni ejecutar clínicamente Q0 o las doce SP para este comienzo. Una discrepancia de corte, una dependencia imprescindible no satisfecha o una pérdida vuelve al Lenguaje con su operación y evidencia. Si no aparece contraejemplo, se informa el alcance efectivamente contrastado sin fabricar una pérdida ni declarar universalidad.

El final de fila 8 será el contrato CYB y el dictamen con evidencia, contraejemplos si los hay y límites; el control volverá al Lenguaje, fila 9. La revisión de plataforma y DFL-009 conservan ese momento. Los README y los expedientes históricos de ambos dominios permanecen intactos por este asiento.

<a id="retp-106"></a>

### RETP-2026-106 — Recepción de OP-CYB-001 y contraste documental sobre LIG/0.1

**Mandato humano:** el 09/09/2026, Juan Antonio Lloret Egea confirma la aprobación del primer universo CYB y su acta de relevo; tras la lectura actualizada autoriza continuar en el Lenguaje. Se reciben el corte CYB `169af16d05ffc954454bb5528ec106e5752b7016`, constitución `b3aa3f01c825bf6440e3f04aadc87cc7c7ee6d89`, y Lenguaje `66967a80a40f4e2781ef983bd725690db54c25c5`. El registro rector, Pilares, perfiles, RETP-105, LIG/0.1 y expediente aprobado se han leído antes de actuar.

**Producto:** [recepción y dictamen único](RECEPCION_Y_CONTRASTE_OP_CYB_001_2026_09_09.md), correspondencia REQ-CYB-001…009 ↔ RS01…12, once originales JSON con manifiesto y sonda nativa sobre el portador sintético existente, con observador documental externo. Los 32 parámetros, 17 controles, 18 elementos iniciales y nueve relaciones del dominio se reciben sin constituir una arquitectura por cardinalidad. D y AG del banco no son el dominio ni el agente CYB.

**Expectativas previas:** `1a668710e410c63b57426c46617c273553dc5566`, árbol `554efbddaa338e7ee95a0cde6f7c6ec7f909475a`. **Cabeza material ejecutada:** `219d6a374c38d1a14a7e191592032f70f89ee402`, árbol `6997c987d51a9ef5d06b334a6f2dd04bd00e624f`, PR #87. La sucesión documental posterior conserva esa realización y sus testigos; no traslada ficticiamente la ejecución a otra cabeza.

**Resultados:** 78 casos completos, 18 pares y 186 transportes por entrada; EN/ES y dos órdenes de ensamblaje (744 comprobaciones de conservación), 24 rechazos causales con reparación, independencia de dos instancias documentales y once pruebas Rust receptoras/lector conformes. El observador reconstruye los 186 contratos y recalcula sus huellas; obtiene 78 respuestas completas y 36 recuperaciones F0 más 36 con S en los pares; las 36 H colisionan por pares. Detecta 22 mutantes de reglas externas y doce ataques al observador. Dos ataques adicionales a la CLI real se rechazan localmente con causa exacta y sin salida válida. No se confunden estas campañas con las 43 mutaciones anteriores del núcleo.

**Comprobaciones de la cabeza material:** retorno CYB [34342683917](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/actions/runs/34342683917), R0 Rust `34342683914`, Conformidad SVP `34342683846`, R0-8 `34342683918`, paridad del corpus anterior `34342683797` y paquete aislado `34342683882`: seis flujos conformes. El paquete aislado ejecuta 359 pruebas Rust sin Python/Node y sin red; conserva GNU Coreutils. La nueva campaña CYB es nativa y su observador requiere Node externo; el verde de WASI/navegador no acredita los nuevos casos CYB en esos destinos.

**Custodia verificada:** artefacto `10100396197`, 560171 bytes, ZIP SHA-256 `980a251d81fb033690822f6872211eb316137764ae2534358c50897654c76dd4`. Emisor `b02cdf1c87de1b54354fa5851a95f94cb641bbece8bf2f9c9439bffc4736198e`; transporte `0b9d0d69636490df56913e684ac17f8e306bb84775eafec4d032068eae9214c0`; informe `b84d04b007fd2212fb29db3004609b15787fdedd794c37ec29640675ff5cd357`. Dos ejecuciones remotas y una local del mismo binario concuerdan literalmente. La repetición local del observador Node 24.19.0 coincide con Node 22.23.2 remoto. Informe y huellas se conservan en `docs/calidad/evidencias/RETP-106/`; comandos y límites, en el expediente vinculado.

**Dictamen:** suficiencia acreditada de F0/HS para el transporte y el uso documental externo ensayados; pérdida de H demostrada en los 18 pares y consultas fijados. No se ha demostrado una pérdida impuesta por LIG ni un nuevo defecto del núcleo que justifique modificar la IR en este incremento. La transcripción externa no es una segunda semántica SV, no produce Tri desde observaciones reales ni acredita legitimidad institucional. Los 46 PR cubren P25…P32; los CT cubren continuidad; no se afirma ejecución de los 32 parámetros.

**Continuidad:** retorno recibido y primer contraste del Lenguaje completado en candidata; fila 9 abierta. El siguiente objeto es precisar los consumidores operacionales requeridos por RS01…12 y su sede, con prohibición de ofrecer lo no realizado. La asignación celular que una operación concrete necesitará se devuelve como pregunta constitutiva precisa; no se inventa ni bloquea el transporte documental ya probado. DFL-009 puede evaluarse ahora conforme a fila 9, sin desplazar los consumidores ni seleccionar plataforma. K1-T, DFL-003/004/006, CQ1…CQ6, Q0/SP y R2/R3/R4 conservan sus límites. DFL-011/012/013 y la retirada de los 17 auxiliares Python permanecen intactos; no se transfiere deuda ejecutiva como capacidad disponible.

**Estado registral:** `RECEPCION_Y_CONTRASTE_DOCUMENTAL_VERIFICADOS_EN_CANDIDATA`. Este asiento se incorpora al estado integrado cuando se fusione su candidata; la PR y sus resultados no son por sí solos esa integración. Ciberseguridad está en pausa controlada. No se constituye un segundo universo, no se reabre su aprobación y no se declara cerrado el núcleo.


<a id="retp-107"></a>

### RETP-2026-107 — Consumo documental CYB ligado a su regla exacta y evaluación DFL-009

**Mandato:** continuación autorizada el 09/09/2026 por Juan Antonio Lloret Egea, después de RETP-106. Base `60bfdf44b2391d2a8bf85a4b37791a6dabd300c8`, PR #87 sin integrar; el nuevo incremento está en la [PR #88](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/pull/88). La comparación con main incluye #87; el incremento propio empieza después de su cabeza. Los originales y la aprobación CYB de `169af16d05ffc954454bb5528ec106e5752b7016` permanecen intactos.

**Problema y decisión:** la definición OP del banco anterior era un literal sintético y no identificaba la regla que se consumía. El [contrato de consumo y soporte](CONTRATO_DE_CONSUMO_DOCUMENTAL_CYB_2026_09_09.md) fija 24 selectores, versión, módulo de reglas, módulo consumidor, fuentes y ámbito. La nueva definición y ambos módulos se transportan como artefactos exactos LIG; el observador comprueba la identidad antes de cargar los bytes conocidos y obtiene la carga desde las referencias del contrato. El núcleo conserva su función de validar LIG; no recibe una semántica profesional CYB.

**Precedencia:** contrato publicado en `c1b75e41f481b7a2c448452512db95530fd1eb25`, antes del código. Material inicial `e2140fa717018b4e5e08d93e60ba1b3f9cc9707d`. Se corrigió además la importación por ruta de la sensibilidad para que utilice los bytes ya comprobados. Cabeza material final **`f5a43131c8743867ee039bfe52f1048a52314058`**, árbol **`7f6b333b88ed2da685289cf1cc33494ba181a558`**. La prueba preliminar sintética no se cuenta como ejecución de Rust. La cola registral posterior no modifica realización ni esperados.

**Resultados:** 186 contratos y definiciones comprobados con recálculo externo; 150 respuestas documentales coincidentes; 36 rechazos explícitos de H por información insuficiente, sin convertirlos en U; 18 pares conservados. Doce pruebas Rust receptoras/lector; 24 rechazos LIG anteriores y tres nuevos ataques a integridad de artefactos, con reparación. Se detectan los 22 mutantes documentales y doce ataques anteriores, más ocho ataques al enlace y uno directo al selector. La sustitución coherente de regla/consumidor no ejecuta el código centinela. Los ataques externos no son diagnósticos del núcleo ni certificación exhaustiva.

**Ejecución:** seis flujos conformes sobre la cabeza material: retorno CYB `34350555281`; aislado `34350555323`; Rust `34350555291`; conformidad `34350555329`; nativo `34350555311`; paridad anterior `34350555414`. El aislado pasa 360 pruebas Rust con Python/Node ausentes, sin red y Cargo offline. Esta campaña de consumo es nativa y externa; no atribuye sus nuevos casos a WASI/navegador.

**Custodia:** artefacto descargado `10103518809`, ZIP 678732 bytes, SHA-256 `7e8f7dff2e5a34c6cf468a8f54b373a17586087cc98f31909aacc219b05e4293`. Binario `7037714f77e450c4496892d9ff2bf1b48a8eb2b2ecef207497c9f0611f7e9671`; transporte `0c3aff2bdde055505eb61b5c81a1051834f32c69320c58e5dfdcd4f5ad0b3c0f`; informe `f3da8ae7ce9521307596908e3b816ac14fba96695e2399e628fe4faf909c64c5`; ataques `4d353c694ebed0f3b508724afca8a1374d7f738ba37bc14074c7eda07e214f89`. Binario repetido localmente y observador Node 24.19.0: transporte, informe y ataques idénticos a Node 22.23.2 remoto. Evidencia y metadatos en `evidencias/RETP-107/`; órdenes y límites en el contrato vinculado.

**Dependencias visibles:** el paquete aislado añade dos módulos `.mjs` como bytes de prueba de `include_bytes!`, en rutas explícitas. No interpreta JavaScript ni añade Node a su construcción; el observador externo sí lo requiere. No se incluyen esos módulos en `sv_core/src` o `sv-native`, no se añade Python ni se oculta código bajo otra extensión. Los 17 auxiliares anteriores siguen pendientes de retirada global.

**DFL-009:** evaluación documental realizada con los registros 018/020 fijados en `e97fed715ff5e3ae19bbaccaf2852e9cd3288377`. Se conservan sus resultados como evidencia recibida, sin nueva ejecución de laboratorio. FFI y WASM no acreditan protección contra el anfitrión ensayado; proceso separado y servicio remoto requieren ensayos y contratos propios. Cloudflare/Workers u otra opción no se seleccionan ni se atribuyen a una realización no ejecutada. La deuda permanece abierta por sus obligaciones materiales; ya no está sólo diferida.

**Dictamen y continuidad:** `ENLACE_DE_CONSUMO_DOCUMENTAL_VERIFICADO_EN_CANDIDATA`. Se ha resuelto la identidad de la regla consumida en este banco; no se han constituido autoridad, agente, captura/admisión ni consumidores profesionales CYB. Las correspondencias de §4 conservan RS01–12 y cotejan IMM/CYB bajo PT03/PT04/PT12/PT14, sin sumar permisos. La siguiente necesidad es el enlace operacional efectivo de identidad, competencia y alcance con los contratos recibidos por las API; cualquier decisión ausente vuelve como pregunta constitutiva precisa. K1-T, productores, Q0/SP, DFL-003/004/005 general/006 y R2/R3/R4 continúan según su capacidad. DFL-011/012/013 intactas. #87/#88 sin integrar; fila 9 y núcleo abiertos; CYB en pausa. No se modifica ningún README, acta histórica ni repositorio de dominio.


<a id="retp-108"></a>
## RETP-2026-108 — Frontera pública entre declaración documental y autoridad

**Fecha:** 09/09/2026. **Mandato:** continuación autorizada por Juan Antonio Lloret Egea. Base e18a794926db07a6ec86d0ae38e6619f41db74eb, árbol b3327d968fe3822dc37e5b67d68ccec18120a66a; PR #88 sin integrar.

**Contrato previo:** [consumo documental CYB, §8](CONTRATO_DE_CONSUMO_DOCUMENTAL_CYB_2026_09_09.md#8-retp-108-frontera-entre-declaración-documental-y-autoridad). Se precisa la correspondencia de P25–P32/C11 con LIG y R1: autoridad declarada e integridad no son facultades institucionales; falta el contrato gobernado que produzca referentes protegidos y premisa externa. Dos controles externos deben compilar y ejecutarse; siete intentos de autoatribución deben rechazarse por E0624/E0451/E0308/E0277, también mediante macros. No basta un rechazo por cualquier causa.

**Estado inicial:** CONTRATO_PREVIO_SONDAS_PENDIENTES. No se modifican semántica, gramática, IR, tipos, dependencias ni dominios. No se añaden facultades ni se considera resuelto el enlace profesional. Fila 9 abierta; la pregunta exacta y las competencias para resolverla figuran en §8.3. La anotación G/H ya incorporada en e18a7949 se conserva en DFL-001.

**Resultado material:** FRONTERA_PUBLICA_DE_AUTORIDAD_VERIFICADA_EN_CANDIDATA. Contrato previo a0f04807c10cfa7ac56886039ba8a38f9943c88f; material 6899f58be5d37f5cb130b71ab65d33b5c06f5229, árbol 541d0871affb964e63e3715ea0f437f884b8e6d1. Dos clientes externos compilan y se ejecutan; siete intentos de autoatribución fallan por los códigos y sujetos comprometidos, también cuando los generan macros. La suite aislada suma 369 pruebas Rust correctas, sin Python/Node, sin red y offline. No se modifica la realización productiva del núcleo.

**Ejecuciones y custodia:** seis flujos conformes 34382276159 / 34382276114 / 34382276118 / 34382276131 / 34382276172 / 34382276135. En el último, la fusión de prueba cb1d947b9eaa5db8060856276eda4616ba268c17 tiene el mismo árbol material. Su primer trabajo recogió PENDIENTE en LIG/navegador y falló; la repetición 102570777159 pasó sobre el mismo commit sin alterar aserciones. Las sondas nuevas sólo se acreditan como clientes Rust nativos. El contrato §8.4 conserva también los dos ajustes previos del banco: biblioteca no localizada y productos ejecutables situados inicialmente en /tmp.

Artefacto CYB descargado 10116340925, 681213 bytes, ZIP SHA-256 e92a54a45fa623414a3928b4252e9a1315a51ffc5d88b95723f48f0b4c935e70. Registro de sondas b1be8bddf382f0b387538f980afb597debce96dffc34ec2f12360657b83a4c17. El binario, transporte e informe CYB mantienen las huellas de RETP-107. Evidencia en [RETP-108](evidencias/RETP-108/custodia.json); alcance, reproducción y siguiente contrato en §8. Sin compilación Rust local independiente ni seguridad universal acreditada.

**Continuidad:** se ha precisado y probado la barrera pública, no la incorporación profesional. DFL-005 general conserva la recepción de referentes y premisa externa; la autoridad del expediente no se convierte en permiso institucional. DFL-009 y los demás pendientes no se dispensan. Se mantiene PR #88 en borrador sin fusionar; fila 9 abierta. No se cambian README, actas históricas, español, dominios, gramática, IR ni dependencias.


<a id="retp-109"></a>
## RETP-2026-109 — Contrato diagnóstico estructurado y presentación ES/EN

**Fecha:** 09/09/2026. **Mandato:** continuación autorizada por Juan Antonio Lloret Egea después de revisar el idioma del diagnóstico y su posible confusión con decisiones de seguridad. Corte examinado 26ebc9f139397b086ce630df358d6b0fb11d997b, árbol b40b886aa35c4410dfcd8733f39df5cadeea3bdd, PR #88 en borrador; base main@66967a80a40f4e2781ef983bd725690db54c25c5.

**Contrato previo:** [diagnóstico estructurado, procedencia y presentación ES/EN](CONTRATO_DIAGNOSTICO_ESTRUCTURADO_Y_LOCALIZACION_ES_EN_2026_09_09.md). Se conservan código, tipo canónico, causa y decisión técnica; se añaden explicaciones deterministas por perfil y ambas en ensamblaje mixto, con contextos atribuidos a unidades y bytes originales. La ausencia de código catalogado queda explícita. No se reconstruye identidad desde Debug ni se deduce idioma por nombres. Plantillas, fragmentos o errores de presentación no crean admisión, permiso ni Tri.U. La identidad de las fuentes no acredita por sí sola autoridad.

**Carencia reproducida:** 13 casos y 26 ejecuciones: tres controles conformes, nueve rechazos de compilación y un fallo UTF-8, cada uno en nativo y WebAssembly mediante Node. ES/EN reciben hoy la misma prosa o variante interna; las colisiones y fallos de ensamblaje carecen del contexto estructurado; puede aflorar el centinela de superficie extranjera. El fallo de lectura nativo conserva retorno 2, separado del rechazo de compilación con retorno 1. Los esperados caracterizan las salidas ya observadas; no son la verificación de la localización futura.

**Custodia:** artefacto 10116699662 del flujo 34383121897, ZIP 3419689 bytes, SHA-256 recalculado 91a535e098f59b91f03f220438b712952fd1d120a5ad02200e7f4370b256e408, coincidente con metadatos. Se comprueban las huellas de sv-native, assembly_probe y sv_wasm.wasm antes de ejecutar. Node local 24.19.0. Casos, script, salidas íntegras, entorno y huellas en [RETP-109](evidencias/RETP-109/custodia.json); resultados SHA-256 a1de1804090717bb2f5074c61daa8b3e4cc26f596be40afee4ad54a03f49c743. No se recompila Rust localmente, no se ejecutan estos casos en WASI ni navegador real y no se acredita explotación material.

**Aceptación pendiente:** DG01–DG14 contienen controles positivos y discriminantes sobre identidad, causas, fuente exacta, ES/EN, ensamblaje, UTF-8, plantillas, presentación de datos, divulgación, autoridad y paridad por destino. El inventario de emisores precederá al cambio funcional; 51 códigos no equivalen a cobertura de emisores. El oráculo vigente coteja envoltura y subcadenas además del retorno/salida; no siempre el mensaje completo. Su migración separará resultado, procedencia y presentación sin renumerar códigos ni eliminar obligaciones de las 106 fuentes inválidas. No se reescriben los resultados históricos.

**Dictamen:** CONTRATO_PREVIO_CONSTITUIDO_EN_CANDIDATA; REALIZACION_PENDIENTE. Este incremento materializa contrato, caracterización y registros; todavía no localiza diagnósticos. DFL-001 recibe la sucesión; DFL-011, acta del español y anotación G/H se conservan. El contrato de consumo §9 incorpora la precedencia solicitada antes del enlace profesional R1 y de la aprobación de PR #88. La realización y sus pruebas constituyen el siguiente incremento. Fila 9 abierta; dominios en pausa; no se cambian README, gramática, IR, núcleo productivo ni dependencias.


<a id="retp-110"></a>
## RETP-2026-110 — Entrega diagnóstica visible y trazabilidad de dominio

**Fecha:** 09/09/2026. **Mandato:** Juan Antonio Lloret Egea requiere observar la localización en el playground de producción y precisa su relación con Inmunología y Ciberseguridad Inteligente. Corte leído 4276c79be20a7bbf46ddd9440b5a83361bd03dd0, árbol 91728c4f605604f01a6ee6fc1cca957c0935463d; PR #88 en borrador, base main@66967a80a40f4e2781ef983bd725690db54c25c5. Se conserva la lectura de Pilares y transición, y se recotejan el acta de perfiles completa, RETP-109 y su contrato.

**Decisión:** [contrato diagnóstico, §9](CONTRATO_DIAGNOSTICO_ESTRUCTURADO_Y_LOCALIZACION_ES_EN_2026_09_09.md#9-retp-110--entrega-visible-y-aplicación-a-los-dominios). Se distingue aceptación de candidata antes de integración y comprobación de la entrega después de desplegarla en lenguaje-sv.itvia.online. Se deberán cotejar los artefactos realmente cargados y observar ES, EN y ensamblaje mixto con contexto correcto. Una interfaz traducida con un módulo anterior no acredita localización; la fusión no prueba despliegue. Esta secuencia evita exigir publicación productiva como condición previa de aprobar esa misma publicación.

**Aplicación a perfiles:** el idioma de explicación es independiente del dominio recibido y del contrato del agente. Se preservan contenido profesional, referencias, versiones y decisiones. La atribución del diagnóstico al dominio exige ligaduras efectivas; no se infiere por idioma o nombre. Los controles IMM/CYB × ES/EN y de sustitución/confusión de referencias se comprometerán en el alcance que pueda comprobarse. Una ausencia representacional se declara, no se convierte en resultado médico, CYB ni permiso. Se desarrollan DG01/DG07/DG13/DG14 sin constituir una composición multidominio.

**Evidencia y límite:** revisión documental sobre el corte indicado; no se ejecutan pruebas funcionales nuevas ni se afirma observación de una localización ya desplegada. La identificación del entorno público se coteja con README y docs/index.html; la lectura directa de la URL no pudo completarse mediante la herramienta web en esta revisión. No se deriva de ello indisponibilidad del sitio. Las 13 caracterizaciones/26 ejecuciones de RETP-109 conservan su corte y no cierran estas obligaciones.

**Estado:** PRECISION_CONTRACTUAL_EN_CANDIDATA; REALIZACION_Y_ENTREGA_VISIBLE_PENDIENTES. Se añaden contrato y registros por sucesión; DFL-001/011 permanecen vigentes. No se cambian código, README, actas históricas, dominios ni despliegue. PR #88 sin fusionar; fila 9 abierta.


<a id="retp-115"></a>
## RETP-2026-115 — Recepción de tuberías de IA y preparación del ensayo determinista en español

**Fecha:** 10/09/2026. **Orden:** Juan Antonio Lloret Egea requiere que los resultados permanezcan en laboratorio y sean visibles en docs/calidad/tuberias-ia. Solicita continuar con conocimiento determinista, trazable y repetible y precisa una forma y algoritmo NLP inicialmente en español.

**Corte leído:** main aeb5808242697f4d6f18b49da99f1a73eb4cf49d, árbol 25f3d66daf3fa5ce965b0eccf3cc0fd54b1a703b. Leídos completos AGENTS, Pilares, perfiles, transición desde OP-IMM-001, arquitectura y procedimiento de auditoría. Consultados RETP-105–110 y el retorno IMM en 54fe0d89 en sus contratos y límites pertinentes. PR #89 conserva separadamente sus reservas 111–114; este asiento no las incorpora ni aprueba.

**Recepción:** [acta de seguimiento](tuberias-ia/ACTA_RECEPCION_Y_SEGUIMIENTO_TUBERIAS_IA_2026_09_10.md). Entrega c3b9a471e725e0a230dadc77bbe04ad42047669f; resultado de laboratorio en 67eeceea6cb352d7d9b1b4ef248f2356c0230002. Se conserva el espejo literal de RESULTADO.json: 8 propuestas correctas, 3 de tramitación y 5 de retención; 8 pares nativo/WASI con código 0 y salida idéntica; 0 efectos. La captura mide 2406 bytes, SHA-256 56840d45ede24480d5e53fc0e23ef79df891d6444e3b761386d05ba47cbba07f. No se repite ni se atribuye otra ejecución a este espejo. Las medidas completas por destino conservan su alcance y no deciden rendimiento ni refactorización.

**Continuidad candidata:** [Fase 003](tuberias-ia/FASE_003_NLP_ES_CONOCIMIENTO_DETERMINISTA.md) especifica gramática española, resolución unívoca, consulta autorizada y emisión de contenido fijo. La relación parámetro→registro se delimita por identidad y versión; el hash no acredita significado, permiso ni seguridad. D01–D13 e I01–I05 están sólo especificados, sin ejecución nueva ni ampliación de la DSL/IR. El conjunto clínico real no se sustituye por el inventario ficticio del ensayo.

**Objeción adversarial y respuesta:** una salida exacta puede seguir siendo equivocada o variar si el LLM cambia la consulta efectiva. Se exige conservar pregunta original, equivalencias gramaticales explícitas y base/permiso/emisor versionados; las propuestas de la IA no deciden el cuerpo aceptado. Las frases fuera del perímetro quedan sin resolución, separadas de Tri.U. Las revocaciones cambian el contexto y no pueden eludirse mediante repetición de una respuesta antigua.

**Verificación y alcance:** cotejo de identidades, cuerpos copiados, enlaces y sucesión registral; sin nueva prueba funcional atribuida. La recepción y el protocolo se conservan también en laboratorio. No cambian código, gramática, IR, dominios, catálogo/localización ni workflows. Aislamiento material, control productivo, realización del nuevo algoritmo, Qwen y revisión pública integral de Claude permanecen pendientes.

**Estado:** RESULTADOS_ESPEJADOS_PROTOCOLO_ESPECIFICADO_SIN_CIERRE_MATERIAL. No se pasa a verde la tubería. El siguiente acto material deberá producir las pruebas del algoritmo y de los permisos. Se mantiene la prioridad de IA externa, seguida de catálogo/localización y fila 9.


<a id="retp-116"></a>
## RETP-2026-116 — Puesto NLP español ejecutado y entrega a Grok

**Fecha:** 10/09/2026. **Orden:** comprobar funcionamiento observable antes de optimizar; preparar el puesto para Grok. Lectura de Lenguaje 094a6ab671395578d1613c8e4137bdbfe83d4718 y laboratorio f373e8f41ae9873ee7682e0c5f0516e32e95188f; AGENTS, Pilares, perfiles y transición completos, Fase 003 y RETP-115.

**Resultado:** [recepción ES27](tuberias-ia/ACTA_RESULTADO_ES27_2026_09_10.md). Misma fuente Rust 9ca6036afe7387431b7591791ddbce74498ff9c9, lanzador b6209141600e2386480d84715623142169112a81, ejecución 34475250778/1. Madrid en nativo/WASI; 56 controles funcionales (15 positivos, 41 negativos); 100 repeticiones de cada positivo por destino; 6 rechazos de transporte y sensibilidad del observador. 28 muestras conservadas; fuentes y artefacto recuperado cotejados. Los dobles sintéticos no se atribuyen a Grok.

**Cambio:** G-ES27/1 y base artificial LAB-ES27/1 hacen ejecutable un subconjunto de Fase 003, con permiso fijo de registros 1/7, pregunta original y salida exacta independiente de la propuesta de IA. Se añade encargo y puesto automático en laboratorio. Calidad recibe evidencia y esta sucesión; no cambia código productivo, semántica, IR ni dominio real.

**Objeción:** un corpus conforme no acredita todo el español ni aislamiento frente a un host/repositorio comprometido. Revocación entre decisión y uso, integridad adversarial de base e I01–I05 permanecen pendientes. La entrega real de Grok deberá cotejarse con el workflow y fuente fijados. El artefacto temporal de Actions no se presenta como custodia perpetua de binarios; fuentes, oráculos y resultados quedan en Git.

**Estado:** PUESTO_COMPROBADO_CAPTURA_GROK_PENDIENTE; AISLAMIENTO_NO_VERDE. Se ofrece la prueba de funcionamiento al participante. Optimización posterior a valoración del resultado. Se conservan RETP-111–114 en PR #89, catálogo/localización y fila 9.


<a id="retp-117"></a>
## RETP-2026-117 — Fallo funcional de ES27 y corrección comprobada sobre la entrega de Grok

**Fecha:** 10/09/2026. **Mandato vigente:** comprobar funcionamiento y entregar puesto operativo antes de optimizar; conservar resultados en laboratorio y Calidad. Entrada Lenguaje 66801a7146a0a9151f0b2d7fc9f618ce76c37986, laboratorio 07c8fec711635fcfe0dadf5418b18fe8be473923. Lectura íntegra previa de AGENTS/Pilares/perfiles/transición conservada y rectores sin cambios; recepción Fase 003 y RETP-115/116.

**Hallazgo recibido:** [acta y resultados](tuberias-ia/ACTA_RECEPCION_GROK_ES27_Y_CORRECCION_2026_09_10.md). Grok entregó doce entradas en 2f8d3dd5b92e88b62940ed41262282179be59e7c e informe en 07c8fec711635fcfe0dadf5418b18fe8be473923. El run 34476110251/1 confirmó cinco consultas pertinentes indebidamente rechazadas: G02/G07/G08/G09/G10. Cuatro de nueve obtuvieron dato; G06/G11/G12 conservan rechazo. Success/paridad no equivalen a éxito funcional. El fallo se atribuye al analizador de Watson y queda conservado.

**Reparación:** G-ES27/2 separa petición/objeto y constituye equivalencias explícitas de capital española/de España y registro/parámetro sólo para el banco. Fuente e18ed7313bf184bf585f351d0f7e29fdf149db9d; lanzador cef4335ea92eceabb62e7abd54a166e0048e3fe4; run 34477108267/1. Reejecución de los mismos 1173 bytes, SHA-256 d0b46324e0a3f5039d028a39a739d7ec3311d67a9696d338802a30b2da84896e: nueve respuestas correctas y tres rechazos, con paridad y tres repeticiones por destino. No son nuevas sesiones de Grok ni se alteran su entrega/informe.

**Regresión y custodia:** 76 controles, 26 positivos repetidos 100 veces por destino, 50 negativos, seis transportes inválidos y sensibilidad del observador. Se preservan los 56 anteriores. Ambos ZIP recuperados y cotejados; medidas originales 34 y nuevas 36, sin declaración de regresión de rendimiento. Fuentes, oráculos y resultados quedan en Git; artefactos temporales con caducidad explícita. Encargo 002 disponible para nueva falsación del participante.

**Objeción y límite:** resolver lo ya observado no acredita todo el español; seis combinaciones positivas nuevas y nueve negativos amplían la regresión, y el siguiente encargo requiere formulaciones propias. Se conserva pregunta original y no se permite que la propuesta IA escoja la respuesta. Integridad adversarial de base, revocación entre decisión/uso y aislamiento material permanecen pendientes.

**Estado:** FALLO_ORIGINAL_CONSERVADO_CORRECCION_COMPROBADA_NUEVA_CAPTURA_PENDIENTE; AISLAMIENTO_NO_VERDE. Sin cambio productivo, de dominio, semántica, IR ni optimización. PR #89/RETP-111–114, catálogo/localización y fila 9 conservan su alcance.

<a id="retp-118"></a>
## RETP-2026-118 — Segunda captura Grok, corrección ES27/3 y señal de rendimiento WASI

**Fecha:** 10/09/2026. **Mandato:** seguir la iniciativa en laboratorio, comprobar funcionamiento y espejar resultados en Calidad. Corte Lenguaje f497da7116b4b85fc23a67cf8488b5612881391a y laboratorio 921d7197818e94360ee2d6bcafa33574ae6a25db. AGENTS/Pilares/perfiles/transición conservan sus identidades leídas; sucesión Fase 003 y RETP-115–117.

**Recepción:** [acta y expediente](tuberias-ia/ACTA_RECEPCION_GROK_ES27_002_Y_CORRECCION_2026_09_10.md). Entrega de47ea16 e informe 921d7197; run 34489800105/1. Cuatro consultas nuevas pertinentes fallaron: G06–G09. Se mantienen originales completos; 1322 bytes de entrada, SHA-256 2345442c8f4eee3fcfcdc7f49f0712722ef65d7ff6d1613e46877ca59856b37b.

**Corrección:** fuente 387e9d5a76a60b620dc3d4124a1a155adc07767e, lanzador 762ed044655fad31f51db389393930d71a207680, run 34491895499/1. G-ES27/3 amplía formas de petición/objeto y referencias secuenciales, con orden y permiso completos. La misma captura pasa de cinco a nueve datos; tres rechazos conservados. La primera captura también mantiene nueve datos y tres rechazos. Reejecución de Watson; no nueva sesión de Grok.

**Prueba y custodia:** 110 controles, 44 positivos repetidos cien veces por destino, 66 negativos, seis transportes inválidos y paridad literal nativo/WASI. Ambos ZIP recuperados y cotejados. Resultados originales/corregidos, oráculos y hashes espejados en laboratorio y Calidad. Encargo 003 preparado para nueva captura propia del participante y lecturas de registros realmente excluidos.

**Rendimiento:** se conserva el lote de 26 consultas y las 42/44 medidas de ambos runs. WASI muestra mayor mediana en Actions. Comparación local adicional de ambos binarios en un mismo host: 160 medidas, veinte pares AB/BA por carga/destino; WASI +4,77 % en 26 consultas y +13,24 % en 1300 por cociente de medianas, con variabilidad amplia. Señal de penalización pendiente de caracterizar; no se declara rendimiento conservado ni se decide refactorización. Script y medidas en el expediente.

**Estado:** CORRECCION_FUNCIONAL_ACOTADA_COMPROBADA; NUEVA_CAPTURA_PENDIENTE; RENDIMIENTO_WASI_PENDIENTE; AISLAMIENTO_NO_VERDE. No cierra NLP general, integridad adversarial, revocación o producción. PR #89/RETP-111–114, catálogo/localización y fila 9 conservan alcance y pausa. Claude aún no recibe auditoría; Qwen sigue candidato.

<a id="retp-119"></a>
## RETP-2026-119 — Campaña acotada IE-004 y brecha de ligadura semántica

**Fecha:** 10/09/2026. **Mandato:** luz verde de Juan Antonio para probar identificación de peticiones equivalentes y subordinación con Grok, evitando rondas infinitas. Cortes de entrada: laboratorio 7410bbfc7abce96efc66af5a8ed8f60e50b3dbef; Lenguaje 60e9c1f9c8e3b5c3e0aea46b0d009251371a5682. Pilares, perfiles, transición completa, arquitectura y AGENTS conservan las identidades leídas; Fase003 y RETP115–118 revisados.

**Sucesión:** [fase004 y acta](tuberias-ia/ACTA_APERTURA_IE004_Y_PUESTO_2026_09_10.md). ES27/003 deja de ser el encargo activo sin borrar evidencias ni modificar gramática. La nueva propuesta IA sólo afecta a un receptor experimental, fuera de la cadena soberana. Paquete previo de24 preguntas y oráculo salado comprometido; primera captura y una confirmación independiente acotadas.

**Material:** fuente f8f0fa26da55663bbf24f944d121c05eef8070c9; ejecutor 3c4d4d54813c8335be9d4a504a2cc529de4e043d; run 34501044665/1. Veinte controles, diez ejecuciones por destino, seis tramas negativas por destino y34 procesos medidos; paridad por bytes. Dos ZIP recuperados; fuentes/workflows/binarios cotejados; resultados y muestras espejados. Portabilidad de instrumentación corregida tras ausencia local de GNU time; CPU/RSS no observables se declaran.

**Hallazgo:** tipo, permiso y cita literal válidos permiten seleccionar IGG cuando la pregunta dice IgA. El receptor lo admite y el observador lo discrimina. Esta brecha bloquea promoción al SV incluso con acierto completo de Grok. Detección externa no se confunde con prevención interna.

**Estado:** PUESTO_DISPONIBLE; CAPTURA_GROK_PENDIENTE; BRECHA_SEMANTICA_CONFIRMADA; AISLAMIENTO_NO_VERDE. No se fabrica Frame ni se ejecuta Q0/R1; I01–I05 y permisos efectivos del participante pendientes. Claude participa ya en la revisión metodológica, sin reproducción técnica atribuida. Qwen sigue candidato; catálogo/localización y fila9 conservan pausa; PR89/RETP111–114 sin alterar.

<a id="retp-120"></a>
## RETP-2026-120 — Recepción IE-004/001 y confirmación final acotada

**Fecha:** 10/09/2026. Cortes: Lenguaje d3d80d33b9b3f58d6bfc362e6c92bc5ff57f1ab2; laboratorio y depósito Grok 2c41d40c5bb6eb5a97049884637a9aa621a86b28. Rectoras cotejadas contra lectura íntegra previa; AGENTS y Fase004 revisados.

[Acta y evidencia espejada](tuberias-ia/ACTA_RECEPCION_IE004_001_Y_CONFIRMACION_2026_09_10.md). Se conserva el depósito exacto y se abre el oráculo001 comprometido. Grok declara sesión reutilizada; no se acredita independencia contextual. Recepción local con fuente y binarios inmutables del puesto 34501044665/1: 23/24 identificaciones,22/24 respuestas correctas,14/16 consultas legítimas con dato. L01 rechaza contexto suficiente según contrato; L11 cambia mayúscula de cita y obtiene APOYO_INVALIDO pese a ruta correcta.

Paridad por bytes y tres reproducciones por destino;40 procesos con controles. Un contraste bruto entre dato y error no cuenta como acierto:4/5 contrastes funcionales. Medianas del lote de24 con arranque: nativo2.100948ms,WASI52.347944ms;CPU/RSS e inferencia Grok no observables. No comparación con ES27.

**Continuación:** última confirmación de24 casos(8 repetidos,16 nuevos), fijada antes de cualquier corrección, en conversación nueva. Receptor sin cambios; reserva002 fuera del acceso del participante, compromiso público. No tercera ronda automática.

**Estado:** FALLOS_EN_LOTE; BRECHA_SEMANTICA_CONFIRMADA; AISLAMIENTO_NO_VERDE. Dominio/universo/agente diferenciados; recorrido completo DSL/núcleo/aislamiento material sigue pendiente. Sin promoción al SV, reapertura de fila9 o catálogo/localización ni selección de Qwen. Clausura humana no declarada.

<a id="retp-121"></a>
## RETP-2026-121 — Perfiles lingüísticos y separación entre investigación y aplicación

**Fecha:** 10/09/2026. Cortes: Lenguaje 97a8546bd184161fc1c7c3aea55d5c1d0c19149e; laboratorio a4db8d622d02766689def38816e18d85c94a7bb3. Mandato de Juan Antonio; lectura íntegra de perfiles fuente ES/EN y acta de perfiles y ensamblaje; rectoras sin cambios respecto de sus lecturas íntegras previas.

[Acta espejada en Calidad y laboratorio](tuberias-ia/ACTA_ENCAJE_DE_PERFILES_LINGUISTICOS_Y_SEPARACION_INVESTIGACION_APLICACION_2026_09_10.md). Español conserva el alcance actual. Se distingue el perfil del código, el idioma de interfaz y la futura interacción lingüística del agente. Dominio, universo, agente y soporte conservan responsabilidades e identidades propias. Investigar y modificar conocimiento queda bajo soberanía humana; aplicarlo requiere su versión autorizada, sin incorporar conocimiento o equivalencias por aprendizaje durante el uso. Registrar observaciones admitidas y contexto no equivale a modificar el saber constituido.

**Excepción acotada:** anticipar una intervención imperativa para evitar una refactorización costosa exige demostrar la pérdida de representación, un caso positivo y un contraejemplo, localizar el nivel competente y acotar el cambio, versionado, checkpoint y verificaciones afectadas según §7 del acta de perfiles. Más idiomas por sí solos no justifican refactorizar el núcleo.

**Estado:** DIRECTRIZ_DOCUMENTADA; REALIZACION_PENDIENTE; AISLAMIENTO_NO_VERDE. Publicación documental y registro, sin nueva prueba ni cambio del encargo IE-004/002, del receptor o de sus criterios. Catálogo/localización y fila 9 conservan su orden posterior. No se acredita comprensión universal, despliegue multilingüe ni aislamiento material.

<a id="retp-122"></a>
## RETP-2026-122 — Recepción IE-004/002 y fin de la secuencia prevista

**Fecha:** 10/09/2026. Cortes: Lenguaje 3bb3c0d6da81b55e07eeffee69246eff901a7423; laboratorio 789b3030917da77654efcf652f47eb9e6153e04f. AGENTS releído y rectoras cotejadas sin cambios respecto de sus lecturas íntegras; Fase004, encargo002, custodia y compromiso revisados completos.

[Acta y evidencia espejada](tuberias-ia/ACTA_RECEPCION_IE004_002_Y_FIN_DE_SECUENCIA_PREVISTA_2026_09_10.md). Depósito Grok927f24d57701dda579ff822da7a7fdaf1eeed69e íntegro; reserva002 verificada y abierta después de recibirlo. Misma fuente y ejecutor, mismos binarios:40 procesos locales. Resultado23/24 identificaciones y respuestas;17/18 consultas con dato;6/6 diagnósticos/denegación. R01 persiste frente al contexto completo del contrato; se conserva la objeción de Grok al esperado. R05, repetido de L11, produce una cita válida y sirve unidad. Paráfrasis1/2, contrastes5/5 y nota externa1/1. Paridad por bytes y tres reproducciones del receptor por destino.

Nueva conversación declarada; memoria de proyecto visible y relato del usuario sin traza íntegra de la sesión: independencia contextual no acreditada. Ocho entradas repetidas idénticas:8/8 rutas/diagnósticos iguales,7/8 cuerpos,6/8 correctas en ambas. El mismo error no acredita utilidad. Las tres muestras de proceso por destino presentan dispersión; medianas nativo3.850901ms y WASI202.626295ms. CPU/RSS e inferencia no observables; no atribución de regresión ni optimización.

**Estado:** CANDIDATA_INSUFICIENTE_EN_CONFIRMACION; SECUENCIA_PREVISTA_FINALIZADA; AISLAMIENTO_NO_VERDE. No tercera tanda automática ni retoque retrospectivo. Brecha semántica e imposición material pendientes; no clausura humana ni promoción al SV. Próxima decisión sobre mecanismo con estos hallazgos; se conserva RETP121 y el orden posterior de catálogo/localización y fila9.

<a id="retp-123"></a>
## RETP-2026-123 — Workflow acotado y repetición de contexto autorizada

**Fecha:** 10/09/2026. Cortes: Lenguaje52665a0181dcf09ebfcf4ceb5d941887e123862e; laboratorio748bf3fff14bb765d42f4d839f31e9a7047e2bbf. Identidades de AGENTS y rectoras cotejadas sin cambios respecto de sus lecturas íntegras; encargo002, custodia y recepción122 contrastados.

[Workflow y límites](tuberias-ia/WORKFLOW_ACOTADO_SUBORDINACION_IA_ES_2026_09_10.md). Juan Antonio autoriza expresamente una repetición fuera del proyecto tras finalizar la secuencia anterior. Se individualiza como contexto001; conserva las24 solicitudes, formato, oráculo abierto, receptor y ejecutor; se identifica por commit. Durante la preparación llegaron nuevas versiones de entrega002 e informe002, commits40c70301 ycd67d285, pendientes de recepción funcional. Se conserva esa única captura y la anterior; no se pide otra generación para renombrar ni se abre un encargo adicional. No se atribuye una autorización automática ni se altera el dictamen previo.

Se fijan objetivos, responsables, evidencia y paradas para recepción, diagnóstico causal, mecanismo candidato, cualificación, imposición material, viabilidad y auditoría/decisión. Indicadores separados de identificación, utilidad, rechazo debido, respuesta indebida, relaciones, conservación, trazabilidad y recursos. Una propuesta de mecanismo y un ciclo de cualificación; validación inédita acotada y reservada antes de corregir, sólo cuando corresponda. Medición propuesta:30 bloques pareados por destino y presupuestos previamente fijados; no se ejecuta ahora.

**Estado:** WORKFLOW_DOCUMENTADO; REPETICION_CONTEXTO_AUTORIZADA_PENDIENTE; AISLAMIENTO_NO_VERDE. La salida del proyecto no prueba por sí sola toda independencia; un corpus cuyo oráculo es público no se presenta como inédito. Próximo objeto P0: recibir la repetición; después P1. No se modifican código, criterios históricos, conocimiento, permisos ni las prioridades posteriores.

<a id="retp-124"></a>
## RETP-2026-124 — Recepción fuera del proyecto y diagnóstico causal acotado

**Fecha:** 10/09/2026. Cortes: Lenguaje 48ae6c11b88afdaa54691ac1c3c146c095cca208; laboratorio 13b4177f7f4e3cd03fa955d41ecf1641e859d4a7. AGENTS y rectoras cotejadas sin cambios respecto de lecturas íntegras; Fase 004, encargo 002 y workflow RETP-123 contrastados.

[Acta y evidencia](tuberias-ia/ACTA_RECEPCION_CONTEXTO_IE004_Y_DIAGNOSTICO_CAUSAL_2026_09_10.md). Recibida la única repetición fuera del proyecto, según confirmación de Juan Antonio: entrega 40c70301c520cc79f2a400424dfc184be31b2d78 e informe cd67d2854c756cb073d02cd1440a57815b109ed9. Se individualiza como CONTEXTO-001 sin borrar la captura 927f24d5. Mismas 24 entradas, formato, compromiso, oráculo abierto, fuente, observador y binarios. Una recepción técnica, 40 procesos y tres reproducciones por destino.

Resultado: 23/24 identificaciones y respuestas; 17/18 consultas con dato; 6/6 diagnósticos y denegaciones debidos. Paráfrasis 1/2, contrastes 5/5, nota externa 1/1, exigiendo corrección de todos los miembros. Las 24 rutas/diagnósticos y cuerpos coinciden con 002 anterior; nueve apoyos cambian. Persiste R01. Nativo/WASI: 5 418 bytes y SHA256 a15e3db240bc606aae3a3efa15c86ab750a4398e30a181549ef70ee74774042d. Medianas locales de proceso 2,050076/46,153713 ms; CPU/RSS e inferencia no observables; no caracterización P5 ni conclusión de rendimiento.

P1 distingue la interpretación insuficiente de R01 con contexto completo, la antigua cita no literal L11 corregida en R05 y la sustitución aceptada por el receptor ante una negación explícita. Se mantiene el esperado congelado de R01 por el objetivo humano y contexto del banco; no se afirma una regla universal del español. I01–I05 y conexión al SV siguen pendientes. La causa interna del modelo no es observable y el corpus revelado no es validación inédita.

**Estado:** P0_RECIBIDO; P1_DOCUMENTADO; P2_PENDIENTE; AISLAMIENTO_NO_VERDE. Termina esta repetición autorizada. Próximo objeto: mecanismo verificable antes de corregir y cualificar. No nueva ronda del modelo, reparación retrospectiva de oráculos, refactorización ni integración. Acta y evidencias espejadas; aceptación humana del frente abierta.

<a id="retp-125"></a>
## RETP-2026-125 — Diseño candidato P2 del vínculo petición/contexto/referencia

**Fecha:** 10/09/2026. Cortes: Lenguaje 19e1e18bb201f8f604178270970160ce7140b522; laboratorio a1614b33eb29726a7b450dd5b6c489a17e0737c1. Luz verde de Juan Antonio para el siguiente objeto de RETP-124. AGENTS y rectoras cotejadas sin cambios; workflow RETP-123 y expediente causal contrastados.

[Acta y matriz](tuberias-ia/ACTA_DISENO_P2_VINCULO_PETICION_CONTEXTO_REFERENCIA_2026_09_10.md). Se especifica una sola candidata: derivación lingüística comprobable contra un perfil español gobernado, cobertura íntegra de la pregunta, análisis de todas las alternativas y unicidad antes de permisos. Una cita literal no constituye prueba de referencia; un diagnóstico del agente tampoco puede vetar una consulta legítima. La recuperación determinista queda como obligación para mantener servicio ante propuesta falsa o ausente. La tabla de análisis, su completitud y los presupuestos se describen como obligaciones explícitas, no como un predicado opaco de validación.

El positivo IGA y la sustitución IGG sobre la misma pregunta discriminan integridad y utilidad; se mantienen R01/R09 y los rechazos debidos R06/R21/R22, sin reparación de oráculos. La matriz contiene 18 obligaciones de diseño, no 18 casos ejecutados ni una reserva inédita. Cero nuevas consultas al modelo y cero nuevas ejecuciones de receptor. Se comprueban consistencia documental, intervalos y correspondencia con antecedentes; no se declaran pruebas del mecanismo ni nueva paridad.

**Estado:** DISENO_P2_CANDIDATO_DOCUMENTADO; SUFICIENCIA_NO_ACREDITADA; P2_ABIERTO; P3_NO_ABIERTO; AISLAMIENTO_NO_VERDE. Faltan perfil completo y justificación de su verificador; beneficio del modelo, recursos e imposición material pendientes. El siguiente objeto es completar/revisar esa especificación y disponer la reserva independiente antes de corregir, conforme al workflow. No otra ronda, refactorización ni integración implícita. Acta, matriz, manifiesto e índice espejados; custodia e índices de trabajo actualizados.

<a id="retp-126"></a>
## RETP-2026-126 — Perfil español P2, propiedad del texto y preparación de reserva

**Fecha:** 10/09/2026. Cortes: Lenguaje 55e354227518c77753578cfcf2d6da5617a76956; laboratorio fa21b92a39565a7f5a4582a9ca51c331c73eb10a. Luz verde de Juan Antonio y matiz de ownership/uso/lifetime. Rectoras cotejadas sin cambios respecto de sus lecturas íntegras; Fase 004 y RETP-121/123–125 aplicables.

[Acta y paquete](tuberias-ia/ACTA_PERFIL_P2_CUSTODIA_TEXTO_Y_RESERVA_2026_09_10.md). Especificación candidata IE004-ES-P2/1 con 23 producciones, léxico declarado, composición tipada, contexto, negación como patrón parcial de tupla y diagnóstico causal. La propuesta externa no sustituye el original, selecciona versiones ni gobierna presupuesto/orden del análisis. Propietario, préstamos de lectura, intervalos, conservación y vida de datos definidos; ownership no acredita semántica, permisos o revocación de copias externas. Documentación oficial Rust consultada y enlazada.

Inventario de los 48 casos de campañas originales con expectativas históricas conservadas y reglas propuestas; máximo de 80 bytes y 80 caracteres por pregunta. Es una revisión documental y medida de longitud; no reconocimiento ejecutado. Límites de memoria/trabajo de la candidata por cualificar, sin nueva paridad o rendimiento. Cero ejecuciones nuevas de receptor/corrector y cero nuevas consultas al modelo.

Encargo independiente preparado para revisar suficiencia y, si procede, custodiar una sola reserva inédita de hasta 24 casos antes de corregir. La reserva no ha sido creada ni su separación acreditada; Watson recibe sólo dictamen/compromiso antes del corrector. Se preserva independencia de autoría respecto de implementador/participante, sin confundirla con auditoría del mismo autor. No se envía automáticamente un mensaje a Claude ni se abre otra tarea de Grok.

**Estado:** PERFIL_P2_CANDIDATO_ESPECIFICADO; REVISION_Y_RESERVA_PENDIENTES; P3_NO_INICIADO; AISLAMIENTO_NO_VERDE. Paquete espejado, índices/custodia y RETP CSV/Markdown actualizados. Núcleo, universo, oráculos y código histórico conservados; catálogo/localización y fila 9 mantienen su orden posterior.

<a id="retp-127"></a>
## RETP-2026-127 — Recepción de Claude, corrección P2 y presupuesto candidato

**Fecha:** 10/09/2026. Cortes: Lenguaje 584d5cc58ba12404548592ffc350d6829b12daac; laboratorio 6f02e5ca38a67082bdc55b6ed5647f3bbaf4e883. AGENTS y rectoras leídas/cotejadas, incluidas adendas de transición; Fase 004 y RETP-121/123–126 aplicables.

[Acta de recepción](tuberias-ia/ACTA_RECEPCION_CLAUDE_Y_CORRECCION_P2_2026_09_10.md). Se conservan los cuatro originales de Claude sin modificación. D1: negación de escriba omitida; D2: disyunción semántica y unicidad insuficientemente precisadas; D3: presupuesto del certificado sin reparto respecto del análisis confiable. Se aceptan documentalmente. R1 se eleva a bloqueante por invertir «no sólo»; los demás reparos se corrigen o delimitan en la sucesora IE004-ES-P2/2, de 25 producciones. La identidad de regla incorpora versión; /1 queda conservada.

Los 48/48, 32 871 y máximos comunicados por Claude son resultados declarados de su traducción sintáctica, no reejecutados aquí y sin equivalencia con validación Rust. El inventario estático encuentra 60 entradas en p2_probes.py frente a 61 anunciadas. Sus scripts y cachés no proporcionan medidas de memoria, overflow, aislamiento o latencia del núcleo. Los 16 contrastes nuevos son públicos y documentales; quedan expuestos, sin reserva ni ejecución.

Cuenta A para resolución completa, V para propuesta opcional, con trabajo y almacenamiento separados; el certificado no espera ni veta el servicio. Guía candidata: CI 20 minutos por trabajo/destino y envolvente interactiva media ≤2 s/p95 ≤5 s/plazo 10 s, con receptor/proveedor desglosados. No son mediciones ni una selección de plataforma; imposición material P4 y caracterización P5 pendientes. La utilidad del agente no está acreditada por ejecutar A sin él.

**Estado:** /1 con defecto; /2 corregida documentalmente y pendiente de suficiencia; RESERVA_DETENIDA; P3_NO_INICIADO; AISLAMIENTO_NO_VERDE. Una revisión focal, reserva sólo si apta y con custodia separada antes de corregir. No ciclo /3 ni ronda Grok automáticos; cero ejecuciones nuevas de scripts Python, parser, receptor o corrector. Núcleo, DSL/IR, binarios, datos, oráculos y capturas anteriores conservados. Paquete espejado e índices/custodia/RETP CSV y Markdown actualizados; orden de frentes sin cambios.

<a id="retp-128"></a>
## RETP-2026-128 — Aptitud documental P2 y preparación de reserva P3

**Fecha:** 10/09/2026. Cortes de entrada: Lenguaje b9dea6b6469b4b79b0323385cf610438d912f0bf; laboratorio d4c5366ed50c17e70342068971287cfb94f277a6. AGENTS y rectoras recotejadas sin cambios respecto de las lecturas de RETP-127; Fase 004 y RETP-121/123–127 aplicables.

[Recepción](tuberias-ia/ACTA_RECEPCION_APTO_P2_Y_PREPARACION_RESERVA_P3_2026_09_10.md). Claude declara APTO_PARA_RESERVAR, corrección documental D1–D3 y atención R1–R7; se conserva su participación en el diseño. Su Python comunica 48/48 derivaciones únicas y presencia/ausencia correcta para 16 contrastes; no implementa la semántica §5. No se equipara a 64 respuestas ni pruebas Rust. Los dos originales se conservan byte a byte. Rectifica a 60 sondas y añade 18 cadenas expuestas, sin reclamar novedad de esas entradas.

Se mantiene a Claude como autora de la reserva; no podrá contabilizar su revisión del mismo oráculo como independiente de su autoría. Juan Antonio será custodio: preparación candidata, descarga/recuperación separada y recibo humano real antes del corrector. El compromiso identifica los archivos sin exponer casos/respuestas; el recibo se registra aparte, sin reescribir su declaración histórica. No se exige al contenedor efímero garantizar la conservación humana ni se da por realizada.

R8 y R9 se concretan en C17/C18 públicos, con semántica /2 intacta. R10 es riesgo documental de coste: la reserva natural no acredita capacidad en 128 tokens; controles públicos próximos a topes preceden a la captura Rust. No aceptar DATO o fallo técnico como éxitos intercambiables. R11 motiva el contrato de captura con A original y V en entradas separadas, sin decodificar V para servir A; esquema interno de certificado pendiente de congelación antes de captura. Dos contadores o archivos no acreditan aislamiento material.

**Estado:** APTO_DOCUMENTAL_PARA_PREPARAR_RESERVA; RESERVA_NO_ACREDITADA; P3_NO_INICIADO; AISLAMIENTO_NO_VERDE. Una preparación de 24 solicitudes por el autor independiente del implementador/participante en el alcance declarado; compromiso/recepción antes del corrector, controles y congelación antes de una captura. Cero ejecuciones Python/Rust nuevas, cero consultas de modelo nuevas y ninguna reserva producida por Watson. No modifica perfil /2, núcleo/IR, capturas u oráculos históricos; no abre otra versión ni frente tecnológico. Originales, decisiones, encargo e identidades espejados, con índices/custodia y RETP CSV/MD actualizados.

<a id="retp-129"></a>
## RETP-2026-129 — Estado del arte y expediente científico de IE-004

**Fecha:** 11/09/2026. Cortes de entrada: Lenguaje 7da60a9d83362d2a21fd1e27801cbece8b49ccd6; laboratorio f66562bfd108e5c0e06516f0be17737b8e40517d. AGENTS releído; Pilares, perfiles, transición y arquitectura recotejados sin cambios respecto de sus lecturas documentadas en RETP-127/128. Fase 004 y workflow RETP-123 aplicables.

[Acta](tuberias-ia/ACTA_EXPEDIENTE_CIENTIFICO_Y_ESTADO_DEL_ARTE_2026_09_11.md), [revisión bibliográfica](tuberias-ia/ie004/expediente-cientifico/ESTADO_DEL_ARTE_2026_09_11.md) y [expediente preparatorio](tuberias-ia/ie004/expediente-cientifico/EXPEDIENTE_PARA_REVISION_POR_PARES.md). Se cumplen los dos objetos solicitados: estado del arte focal con 18 fuentes primarias consultadas y documentación del proceso para futura crítica por pares. BibTeX, versiones, fechas, alcance de lectura, consultas y lagunas quedan registrados; la huella identifica nuestras fichas, no los PDF originales no custodiados. Se separan publicación revisada, preprint y nota W3C; no se anuncia revisión exhaustiva o réplica de experimentos ajenos.

CaMeL y FIDES impiden reclamar como novedad genérica la imposición externa de políticas deterministas. La aportación candidata se delimita a significado/referencia, autoridad, recursos y reproducción en el contrato concreto, aún por cualificar. La matriz contiene siete hipótesis y once piezas de evidencia histórica identificadas por corte/blob; conserva errores, rectificaciones, exposición e independencia limitada. En /2 A entrega antes de V: la utilidad de la IA no se demuestra atribuyéndole ese cuerpo y continúa pendiente de una tarea/métrica útiles antes de su medición.

No se modifica perfil /2, núcleo/IR, semántica, dominio, capturas ni oráculos. No se crea ni se lee la reserva, se reejecuta Python/Rust/WASI o se llama de nuevo al participante. La investigación bibliográfica no se incorpora al saber aplicado. No se inicia envío editorial ni se da por recibida revisión por pares. Acta y expediente espejados; índices y RETP actualizados sin reescribir evidencia anterior.

**Estado conservado:** APTO_DOCUMENTAL_PARA_PREPARAR_RESERVA; CUSTODIA_NO_ACREDITADA; P3_NO_INICIADO; AISLAMIENTO_NO_VERDE. Próximo hito: compromiso y confirmación humana de custodia recuperable; después corrector y controles públicos antes de una captura. Esta publicación documenta el proceso y su falsación, sin abrir una nueva ronda o frente tecnológico.

<a id="retp-130"></a>
## RETP-2026-130 — Recepción humana del compromiso P3 y control Rust R10

11/09/2026. [Acta](tuberias-ia/ACTA_RECEPCION_COMPROMISO_P3_Y_CONTROL_PREVIO_RUST_2026_09_11.md). Cortes: Lenguaje d9e5f39e41876a4668cc114b36e1435d670e3c42; laboratorio 875128eb0826bd2566affda665f8bd65c50cc7d0. Compromiso original intacto: 3193 bytes, SHA-256 d37246a019332327f54dd45c641944d90e3ae440163d76d0607c5235df63f9f5. Perfil /2 cotejado sin cambios. Recibo humano posterior separado: recuperación/separación confirmadas, sin inspección directa del almacén ni lectura de los cuatro archivos reservados. Se cumple la condición previa de custodia, no la cualificación de P3.

Se prepara sonda Rust del recorrido por barridos, 72 controles públicos y primitivas de overflow/rangos/slices, con cupos y límites congelados antes de ejecutar. Sólo reconocimiento sintáctico: no resolución §5, verificación V ni prueba general de capacidad del perfil. No se ejecuta Python ni se envía nueva tarea a Grok. Resultados por destino/configuración se añadirán con su evidencia; cualquier fallo detiene el avance a la captura. Aislamiento NO VERDE.

<a id="retp-131"></a>
## RETP-2026-131 — Resultado del control público R10 en Rust

11/09/2026. [Adenda](tuberias-ia/ACTA_RESULTADO_CONTROL_PUBLICO_R10_RUST_2026_09_11.md). Fuentes y corpus fijados en RETP-130 antes de ejecutar. Rust 1.98.0 nativo/WASI, debug/release: 69/72 coincidencias en cada configuración; tres agotamientos idénticos en C02 (17 tokens), CP-T-127 y CP-T-128. Las 21 aserciones locales de primitivas finalizan en cada configuración. No se ejecuta Python ni se lee la reserva. Se conservan logs, flags, entorno, tiempos, huellas de binarios y reproducción.

El fallo refuta la suficiencia de este recorrido instrumentado y su contabilidad. No acredita semántica §5 ni imposibilidad del perfil o de un recorrido equivalente más eficiente. No se elevan cupos ni se cambian esperados. Compilación 0,852 s y ejecución acumulada 4,846 s para los cuatro procesos, una muestra por configuración; no son tiempos del modelo ni cualificación de rendimiento. Preparación documental/instalación fuera de esa medición. Corrector completo pendiente; captura no habilitada; reserva y compromiso intactos; aislamiento NO VERDE.

<a id="retp-132"></a>
## RETP-2026-132 — Coste y calendario alternativo R10

11/09/2026. [Acta](tuberias-ia/ACTA_COSTE_R10_Y_SUCESION_DEL_CALENDARIO_2026_09_11.md). Autorizada la continuación tras RETP-131. Se prepara IE004-R10-MEMO/1: evaluación por dependencias acíclicas, memo y bosque compacto con todas las familias. Se conserva léxico/G01–G25/corpus. El calendario y la contabilidad son experimentales distintos de /2, que permanece intacto con su reserva. Fuentes y criterios fijados antes de ejecutar. Resultados pendientes. La cota de dos barridos de la sonda anterior supera 1m visitas con 127/128 tokens; es una cota de esa instrumentación, no una imposibilidad universal del perfil. Se ejecutarán cuatro configuraciones Rust sin repetir ni alterar esperados.

<a id="retp-133"></a>
## RETP-2026-133 — Resultado de coste y evaluación semántica pendiente

11/09/2026. [Acta y evidencia](tuberias-ia/ACTA_RESULTADO_COSTE_R10_2026_09_11.md). Fuentes de IE004-R10-MEMO/1 prepublicadas en RETP-132. 72/72 controles públicos en nativo/WASI y debug/release; 21/21 primitivas por configuración. Máximo 62.906 unidades propias, no comparables directamente con los intentos de la sonda anterior. Los bosques completos y los cargos coinciden entre las cuatro configuraciones. Cuatro controles estructurales posteriores, fijados antes de ejecutarse, conservan multiplicidad y rechazo del cierre incompleto; 4/4 por configuración. No hay nuevas consultas de modelo ni acceso reservado.

En CP-T-128, tabla densa de 14.120.340 B: 87,46 % de capacidad nativa y 91,14 % WASI; 0,3741 % de posiciones ocupadas. Realojos/copia física no medidos. Se incorpora criterio de memoria y vida de buffers al siguiente objeto de evaluación semántica de A. La arena sintáctica no es el consumo agregado de A. Los tiempos de una sola ejecución incluyen exportación del bosque y no acreditan servicio/P5. Se cierra esta ronda de coste, se prepara sucesión expresa de calendario/contabilidad y evaluador tipado. /2 y su reserva intactos; compatibilidad futura pendiente; captura no habilitada; aislamiento NO VERDE.

<a id="retp-134"></a>
## RETP-2026-134 — Significados antes de permisos y límites de texto

11/09/2026. [Preparación](tuberias-ia/ACTA_PREPARACION_SEMANTICA_A_Y_LIMITES_TEXTO_2026_09_11.md). Se implementa IE004-ES-P2/3-COSTE/1 con calendario y contabilidad sucesores expresos; /2 intacto. Evaluación completa tipada antes de permisos, entrada UTF-8 y capacidad agregada de A limitada antes de inserciones. Se fijan 61 controles semánticos y 72 sintácticos antes de ejecutar. No hay evidencia funcional todavía. Una matriz nativo/WASI debug/release; conservar fallos antes de una corrección causal máxima. No se habilitan reserva ni recepción A/V; P4/P5 pendientes. La representación dispersa sustituye la tabla sintáctica densa por una causa explícita de memoria conjunta. No se mide aún RSS ni latencia de servicio.

<a id="retp-135"></a>
## RETP-2026-135 — Resultado semántico público y memoria conjunta

11/09/2026. [Acta y evidencia](tuberias-ia/ACTA_RESULTADO_SEMANTICA_A_2026_09_11.md). Una matriz de cuatro ejecuciones Rust 1.98.0 nativo/WASI debug/release sobre fuentes y esperados prepublicados en 5d0f0e5d/4e556e5d: 61/61 semánticos, 72/72 sintácticos y 26 primitivas por configuración. Sin modificación posterior, corrección, reintento ni Python. Trazas y trabajo iguales; C03/S01 mantienen ambigüedad y cero llamadas a política aunque cambie vigencia. Paráfrasis públicas mantienen significado y cuerpo.

Máximo observado 621.146 unidades nuevas; 1.675.752 B capacidad de buffers A, 1.777.770 B pico calculado de reserva y 1.554 estados. No acredita peor caso universal, RSS, pila ni latencia de servicio. Se registran grafía combinante y espacio no separable como cobertura no admitida del normalizador vigente. La reserva /2 sigue cerrada. Próximo objeto concreto: correspondencia semántica y fijación de recepción/captura A/V antes de P3; P4/P5 pendientes.

Recuperación documental del depósito interrumpido: [acta y comprobación de las capturas originales](tuberias-ia/ACTA_RECUPERACION_DOCUMENTAL_RETP135_2026_09_11.md). Se verificaron fuentes, huellas y resultados conservados; no se repitió la ejecución del banco.

<a id="retp-136"></a>
## RETP-2026-136 — Correspondencia y recepción separada A/V

11/09/2026. [Acta de preparación](tuberias-ia/ACTA_PREPARACION_CORRESPONDENCIA_Y_RECEPCION_AV_2026_09_11.md). Alcance autorizado: siguiente objeto de RETP-135. Se conservan los cinco archivos semánticos heredados y se fija admisión estricta, marco A completo, certificado V y anexo separado; fuentes y esperados antes de ejecutar. 23 controles A, 25 V, tres relaciones, 22 primitivas y nueve escenarios de transporte. Tres reproducciones Rust por configuración, matriz nativo/WASI debug/release. La preparación compila y conserva sus incidencias; no ejecuta consultas. La reserva permanece cerrada y la compatibilidad P3 integral no está acreditada. P4/P5 pendientes.

<a id="retp-137"></a>
## RETP-2026-137 — Resultado público de recepción A/V

11/09/2026. [Acta y evidencia](tuberias-ia/ACTA_RESULTADO_CORRESPONDENCIA_Y_RECEPCION_AV_2026_09_11.md). Una matriz sobre la prepublicación c6ad0c2b/141a40d0, sin corrección posterior ni reintento. En cada configuración nativo/WASI debug/release: 23 controles A, 25 V y tres relaciones repetidos tres veces; 22 primitivas y nueve escenarios de procesos/pipes. Paridad de cuerpos y desenlaces/trabajo V. A entregada antes de V; cuerpo conservado ante ausencia, invalidez, exceso, agotamiento, correlación errónea, demora y ausencia de EOF. V al máximo de 262144 bytes usó 845002 unidades. Capturas originales recuperables; RSS, aislamiento P4, aportación P5 y P3 reservado pendientes. Siguiente objeto: lote y compatibilidad P3, sin consultar reserva.

<a id="retp-138"></a>
## RETP-2026-138 — Preparación de lote y compatibilidad P3

11/09/2026. [Acta](tuberias-ia/ACTA_PREPARACION_ADAPTADOR_LOTE_Y_COMPATIBILIDAD_P3_2026_09_11.md). Adaptador de esquema cerrado, lote máximo 2 MiB, 24 objetos y extracción sin normalización; fuentes A intactas. 36 controles públicos y tres reproducciones por destino/perfil; recorrido de 24 solicitudes públicas con cuerpos esperados heredados. Preparación tipada sin consultas ejecutadas. Diferencia expresa de calendario/unidades /2 y /3; decisión humana de asociación pendiente, reserva cerrada.

<a id="retp-139"></a>
## RETP-2026-139 — Fallo de montaje y corrección causal

11/09/2026. [Acta](tuberias-ia/ACTA_FALLO_DE_MONTAJE_Y_CORRECCION_ACOTADA_LOTE_P3_2026_09_11.md). Adaptador: 432/432 controles. Recorrido: 252/288; tres posiciones heredadas de A04 se invocaron con vigencia activa en lugar de revocada. Los 36 fallos se conservan. Corrección sólo del conductor, con mismos Rust, binarios, entradas y esperados; contraste acotado de esas 36 observaciones pendiente. Fallo de manifiesto EISDIR por directorio temporal identificado, sin pérdida de capturas. Reserva cerrada.

<a id="retp-140"></a>
## RETP-2026-140 — Resultado de lote y compatibilidad preparada

11/09/2026. [Acta](tuberias-ia/ACTA_RESULTADO_ADAPTADOR_LOTE_Y_COMPATIBILIDAD_PREPARADA_P3_2026_09_11.md). 36 controles del adaptador × 3 por configuración nativo/WASI debug/release. Recorrido de 24 posiciones × 3: 63 conformes iniciales y nueve correcciones conformes por configuración, restituyendo revocación de A04 sin cambiar Rust, binarios o esperados. Primera matriz FALLO conservada. 2879 archivos recuperables, extracción cotejada y 765 metadatos de procesos verificados. Matriz /2–/3 y decisión humana preparadas; compatibilidad integral no acreditada, reserva cerrada, P4/P5 pendientes.

<a id="retp-141"></a>
## RETP-2026-141 — Workflow V2 subordinado a las actas y retorno acotado

11/09/2026. [Workflow V2](tuberias-ia/WORKFLOW_ACOTADO_SUBORDINACION_IA_ES_V2_2026_09_11.md). Mandato de Juan Antonio: revisar las actas privadas y ajustar el recorrido para evitar deriva de alcance, conservando la sede de núcleo, dominio, agentes, interfaces, bibliotecas y soporte.

Se contrastaron continuidad y plan privados, cierres SEC y pre-R0, anexo temporal/forense y actas actualizadas de R0/R1 con las rectoras públicas leídas íntegramente: AGENTS, Pilares, perfiles, transición y adendas, arquitectura y previsión de IA trazable. Cortes: Lenguaje `d7ae473ed44f053a7db1adbf80ea27d047a955ae`, laboratorio `0265480fb90c1095ee915132e65aae8c22984bca`; R0/R1 privados en `20da3c781286bee1966c22cf1fc7a4755be35b9b`. Se preservan originales privados y workflow RETP-123.

La V2 fija un solo expediente: correspondencia de resolución, evidencia recuperable e inscripción exigible por contratos. Distingue cierre del análisis y cierre de la capacidad trazable; no fabrica célula, SUCESO o Frame por cada consulta. Los hallazgos ajenos al recorrido se devuelven a su sede y fase con impacto y condición de tratamiento. Se conservan P0–P6, sus presupuestos consumidos y el retorno de RETP-121 a catálogo/localización y continuación de fila 9, ya abierta.

La revisión adversarial documental exige no confundir log con inscripción, huella con recuperación, explicación del modelo con observación, ni contrato con garantía material. Un vacío que impida el recorrido bloquea su cierre; no se oculta como deuda ni abre automáticamente una nueva arquitectura.

Los hallazgos de Claude comunicados por Juan Antonio se identifican como recibidos y pendientes de tratamiento, sin darlos por corregidos. Asociación /2–/3 sin aceptación por este cambio; reserva cerrada. No se modifica código, corpus, compromiso, oráculos, IR o Frame, ni se inicia examen de agentes o captura del modelo. P4/P5 y aprobación final de campaña pendientes; estado global NO VERDE.

**Comprobación de esta modificación:** coherencia de secuencia y compuertas, enlaces documentales y concordancia RETP CSV/Markdown; preservación del workflow original y copia idéntica de V2/navegación en laboratorio. No se atribuyen nuevas ejecuciones funcionales a un cambio documental.

**Estado:** WORKFLOW_V2_DOCUMENTADO_TRAZABILIDAD_PENDIENTE_RESERVA_CERRADA.

<a id="retp-142"></a>

## RETP-2026-142 · Correspondencia y contraste acotado de trazabilidad

**Fecha:** 11/09/2026. **Responsable:** Watson. **Mandato:** continuación autorizada por Juan Antonio Lloret Egea del objeto único de RETP-141.

[Expediente de correspondencia](tuberias-ia/EXPEDIENTE_CORRESPONDENCIA_TRAZABILIDAD_IE004_2026_09_11.md) sobre el corte `8880a099b0b9549aaa66c2c5d93e0b9c247834ff`, con inventario de 50 blobs y evidencia recuperable. Se localizaron recepción y resolución A/V, la cadena protegida R1 y las guardas de Frame. El ejecutable IE-004 no une esos recorridos; la existencia separada de esas piezas no acredita transición, inscripción ni recuperación durable.

Se recuperaron 409 archivos públicos y cotejaron 36 recorridos históricos sin reejecutarlos. Se reprodujeron un caso A y dos propuestas V, se comprobó aceptación del marco íntegro y rechazo de truncación/alteración, y pasaron 16 pruebas existentes de Frame mediante arnés aislado. No se reejecutó el núcleo completo. Dos errores del observador —lectura de stderr WASI y esperado C08— se conservan con sus rectificaciones; no se modificaron Rust ni esperados históricos.

**Carencias:** G1 recibo custodiado por invocación; G2 correspondencia con operación gobernada; G3 inscripción y Frame cuando la operación lo exija; G4 recuperación material. Cada una mantiene su sede y fase, con referencia a deudas existentes cuando corresponde. Un bloqueo no se da por cerrado al registrarlo.

**Siguiente objeto único:** contrato de G1 y testigos de evidencia ausente, truncada, duplicada o intercambiada, preservando entrega A y anexado posterior V. Realización nativa prevista en Rust; ningún cambio en Tri, gramática, IR o Frame por este expediente. No se constituye célula ni se decide por dominio o agente.

Se cierra el análisis acotado, no la tubería integral. P4/P5, asociación /2–/3, reserva y sucesiones pendientes conservan su estado. Workflow V2 y secuencia de RETP-121 vigentes. Espejo documental idéntico en laboratorio.

**Estado:** CORRESPONDENCIA_CONCLUIDA_TRAZABILIDAD_INTEGRAL_NO_ACREDITADA.

<a id="retp-143"></a>

## RETP-2026-143 · Contrato G1 de recibo custodiado

11/09/2026. Responsable: Watson. Mandato: luz verde de Juan Antonio Lloret Egea al siguiente objeto de RETP-142. [Contrato G1/1 y testigos](tuberias-ia/ie004/recibo-g1/CONTRATO_RECIBO_CUSTODIADO_IE004_G1_1.md). Cortes: Lenguaje `282e020f8bff2b68abd9a2e9138fa6b467debaf8`; laboratorio `c074b1b0796081501ea0c0c1ac2be206dcf49999`. Las rectoras ya leídas conservan sus blobs, cotejados de nuevo.

Se fija identidad de invocación emitida por el custodio, pertenencia de canales, entrada y montaje efectivos, cuerpo/traza completos y recuperables, cierre A único y anexado V posterior sin modificación de A. Recibo completo no significa resolución exitosa; rechazo de propuesta completa no significa pérdida de captura. Huella de contenido no demuestra origen, unicidad entre invocaciones, autenticidad frente al host ni conservación perpetua.

El constructor documental cotejó los 43 archivos de la cápsula RETP-142 y preparó 14 artefactos originales/mutados y 18 testigos. No implementa el receptor ni decide conformidad G1. Su hash y resultado están conservados; estados, pertenencia, pérdida y plazo requieren el futuro arnés nativo. Variantes positivas de rechazo/fallo A y fronteras del perfil de recursos deben fijarse antes de ejecutar esa campaña; aún no se cuentan como testigos materiales preparados.

**Siguiente objeto único:** realización candidata Rust del receptor G1 y perfil de recursos, con contraste previo fijado. G2, G3, G4, reserva, asociación /2–/3 y P4/P5 conservan su estado. No se altera código A/V, cuerpo, gramática, Tri, IR, Frame ni constitución de dominio/agente. Espejo de contrato y testigos idéntico en laboratorio.

**Estado:** CONTRATO_G1_FIJADO_TESTIGOS_PREPARADOS_REALIZACION_PENDIENTE.


<a id="retp-144"></a>

## RETP-2026-144 · Candidata G1 nativa y corrección causal

11/09/2026. Responsable: Watson. Luz verde de Juan Antonio Lloret Egea al objeto de RETP-143. [Acta, fuentes y evidencia](tuberias-ia/ie004/recibo-g1/ACTA_RESULTADO_G1_NATIVO_2026_09_11.md). Cortes: Lenguaje `aab69e561a06137a78cbe4c9700cb99c8ea376f7`; laboratorio `4a81191fba7e32ff297efbcebaa448fbde04d85e`. Rectoras cotejadas sin cambio.

Se implementa en Rust la recepción y recuperación en memoria por invocación, con manejador opaco, marco/traza A ligados al original y montaje, cierre único y anexado V posterior. El perfil de recursos y los 18 testigos más dos positivos de rechazo/fallo técnico A se fijaron antes de ejecutar. A/V originales se reutilizan sin modificar.

La primera tanda pasó 27/27 por compilación. Una ampliación adversarial fijada antes de corregir reprodujo dos fallos en debug y release: pérdida del prefijo V tras error de lectura y aceptación de un contador nulo en la traza. Una corrección causal conserva el prefijo y exige tipos de campos obligatorios. Resultado final: 29/29 en cada compilación, incluidos 20 testigos G1; 19 archivos capturados idénticos entre configuraciones. Uso externo válido compila; construcción externa del manejador se rechaza. Tres cápsulas y fuentes antecedentes conservan las etapas y sus huellas.

La conservación dura la vida del custodio; no acredita persistencia tras caída, RSS, aislamiento material ni WASI. La interrupción del supervisor es inyectada, no prueba un plazo real contra lectura bloqueada. Los hashes de realización son declaraciones del conductor confiable. No hay reanálisis semántico independiente ni conversión a SUCESO/Frame.

**Siguiente objeto único:** enlace del adaptador público del lote con G1 y cotejo de pertenencia de petición/montaje hasta el recibo. G2–G4, P3 reservado, asociación /2–/3, P4 y P5 conservan sus condiciones. Sin modelo, reserva, cambios doctrinales o constitución de dominio/agente. Espejo idéntico de artefactos en laboratorio.

**Estado:** CANDIDATA_G1_CONFORME_INTRAPROCESO_TRAS_CORRECCION.

<a id="retp-145"></a>

## RETP-2026-145 · Enlace público del adaptador con G1

11/09/2026. Responsable: Watson. Continuación autorizada por Juan Antonio Lloret Egea dentro de la segunda necesidad, trazabilidad. [Acta, fuentes y evidencia](tuberias-ia/ie004/lote-g1/ACTA_RESULTADO_ENLACE_LOTE_G1_2026_09_11.md). Cortes: Lenguaje `a31ec0f008b83eb9d3589228d0ff8cd18ff3591a`; laboratorio `3a6ab3ec9472fd3a3b7feb45f318767de711d922`. Rectoras cotejadas sin cambio.

Se conecta nativamente el adaptador existente con G1. La admisión del lote y montaje públicos, sus huellas, las solicitudes y los rangos de procedencia se verifican antes de abrir A. La identidad completa del enlace se liga al ámbito y ordinal del custodio; no se utiliza el id aislado para seleccionar montaje. Seis custodios de cuatro slots conservan simultáneamente 24 recibos. V queda explícitamente no solicitada en esta ruta.

Con el plan y 23 archivos fijados antes de ejecutar: 24/24 cuerpos coinciden con los esperados históricos, 12/12 testigos pasan en debug y release, 101 capturas son idénticas. Se conservan las tres vigencias revocadas y los originales. Se ejercen identidad, integridad, correspondencia, orden, duplicado, intercambio de manejador, lote incompleto y guarda de recursos. No fue necesaria corrección. Las 24 posiciones contienen diez preguntas distintas.

Cuentas observadas: preparación 3.832.774 B, enlace 1.743.690 B y reservas G1 agregadas 53.518.379 B. Son cuentas de reservas, no RSS. Retención intraproceso; no recuperación tras caída, bloqueo de canal, nueva paridad WASI, inscripción o Frame. Fuentes del adaptador, A/V, G1 y núcleo intactas. La cápsula conserva evidencia verificable y los originales se espejan en laboratorio.

**Siguiente objeto único:** G2 ya localizado en RETP-142, correspondencia del recibo con operación gobernada existente y procedencia de los referentes requeridos por R1. No rellenar referentes ausentes ni convertir una consulta de lectura en actualización celular. G3/G4 y P3/P4/P5 conservan sus puertas; reserva y asociación /2–/3 pendientes. Continúa la segunda necesidad; no se declara trazabilidad integral cerrada.

**Estado:** CONFORME_ENLACE_PUBLICO_INTRAPROCESO.

<a id="retp-146"></a>

## RETP-2026-146 · Memoria del frame humano, trazabilidad y fidelidad

11/09/2026. Responsable editorial: Watson. Publicación solicitada por Juan Antonio Lloret Egea del diálogo desde la pregunta por el frame en su representación mental hasta el diagrama adversarial. [PDF, Markdown e imágenes](tuberias-ia/frame-significado-humano-trazabilidad-y-fidelidad/README.md). Cortes de entrada: Lenguaje `86ab08ea2eea8f7483b1fa8e471a2866627cdfb3`; laboratorio `94bd7175853861f49c53f162efdc6d6df71167c9`.

Se conserva la secuencia de seis imágenes originales y el diagrama, las dos necesidades, la bisagra computacional-humana, la carga de comprensión, la propuesta de Rust y la revisión adversarial. Las cinco comparaciones recuperadas por el autor se incorporan con su texto; dos intervenciones iniciales no recuperadas literalmente quedan identificadas como síntesis editorial. La aclaración posterior sobre reconstruir se recoge como nota editorial.

Comprobación documental: revisión de todas las páginas del PDF, correspondencia de contenidos e imágenes, rutas relativas y manifiesto de identidades. Copias idénticas del expediente en Calidad y laboratorio. No se incorporan los archivos de las actas privadas a Calidad.

No modifica código, semántica, IR, núcleo, dominio, agente ni workflow. No ejecuta nuevos ensayos ni acredita fidelidad o seguridad integral. La reconstrucción de cambios observados no establece por sí sola su causa interna. Se conserva el objeto técnico activo y las puertas pendientes; esta memoria no abre una fase.

**Estado:** MEMORIA_DOCUMENTAL_PUBLICADA_SIN_CIERRE_TECNICO.


<a id="retp-147"></a>

## RETP-2026-147 · Integración acotada de adenda IA, frame y catálogo

11/09/2026. Continuación autorizada por Juan Antonio Lloret Egea. [Expediente, criterios A–L y correspondencia G2](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/README.md). Cortes: Lenguaje `e8558ea69aadacc3454cbd82f09a7bf7f4b06648`; laboratorio `53e1b93f2a392b2bac6e229be839e3cc2e4823ee`; adenda CYB §12 `bbac1b44b1d3b845305e9cde492a08221206d631`. El corte CYB anterior 169af16d no contiene esa adenda.

Se fijan seis grupos de obligaciones, doce criterios con control y ataque, y ocho pasos de continuidad. El ejemplo aporta una referencia y cinco transformaciones observadas; no se reclama reconocimiento universal ni proceso mental interno. Se reciben las fuentes rectoras completas y el contrato diagnóstico previo. Once fuentes pertinentes conservan identidad en el árbol leído; resultados RETP-107/108/142/144/145 reutilizados en su alcance, sin repetición funcional.

G2 queda delimitado: `EnlacePublico` conserva recibos; `permiso_y_dato` aplica política ficticia; `decide_permit_traced` exige continuidad, forma, efecto y requisitos gobernados. Falta la recepción profesional de autoridad ya localizada en RETP-108 §8.3. No se fabrica una premisa, no se añade un constructor y no se convierte consulta en actualización celular. La consulta pública puede terminar en resolución y evidencia; el enlace productivo no queda realizado.

Los fallos se adscriben a su emisor y contrato diagnóstico, sin nuevos códigos ni conversión a U. A–L siguen como criterios pendientes de montaje y ejecución integrada. Se conservan presupuesto, reserva, asociación /2–/3 y P3/P4/P5. No hay cambio de código, gramática, IR, dominio, agente o interfaz. No se declara terminado el catálogo ni el cierre global.

**Estado:** CORRESPONDENCIA_FIJADA_ENLACE_PRODUCTIVO_NO_ACREDITADO. Se conserva el punto de control en laboratorio y Calidad; la aceptación final sigue siendo humana.


<a id="retp-148"></a>

## RETP-2026-148 · Autoridad humana y comprobación técnica de la IA

11/09/2026. Juan Antonio precisa quién autoriza —humano experto del dominio constituido— y el alcance —actuaciones definidas en el agente consumidor—; la comprobación técnica corresponde al trabajo de Watson. [Rectificación, contraste y evidencia](tuberias-ia/rectificacion-autoridad-y-comprobacion-ia/README.md). Entradas: Lenguaje `132c323a6241f1917c5e8416d21eb8a66923cce6`; laboratorio `d95b33a208327e66a36023ffba9d1ee4469c727b`.

Se retira el bloqueo general formulado al finalizar RETP-147: no corresponde pedir al autor el mecanismo que ha encargado construir. La recepción productiva de referentes R1 continúa como obligación técnica; no impide la comprobación pública. No se presume un permiso por el nombre de experto ni se abre un agente, reserva, despliegue o inscripción.

Sonda acotada sobre el binario nativo conservado de RETP-142, sin compilación nueva: marco original aceptado; dato alterado sin actualizar huella rechazado; dato alterado y negación suprimida con huellas coherentes aceptados por el validador de transporte; V original admitida como derivación sintáctica; V con campo adicional de autoridad rechazada por esquema. C3/C4 refutan transporte válido ⇒ fidelidad, no el contrato limitado del receptor ni demuestran vía adversaria hasta G1/R1.

Primer intento detenido en C2 por nombre de diagnóstico supuesto por el observador. Las fuentes previas devuelven Correlacion/CORRELACION_INVALIDA; se corrige sólo ese esperado y se conserva todo. Segundo intento completa seis casos. Ocho procesos en total; 34 piezas custodiadas; ocho fuentes cotejadas; sin modelos, reserva, P4/P5 ni nuevas garantías.

Continúa la comprobación del vínculo referencia–transformación–entrega y la recepción de sus causas por diagnóstico/localización, bajo el workflow vigente y aceptación final humana. Sin cambios de código productivo, gramática, IR o dominio. **Estado: BLOQUEO_GENERAL_RECTIFICADO_CARACTERIZACION_ACOTADA_EJECUTADA.**


<a id="retp-149"></a>

## RETP-2026-149 · Candidata de entrega literal desde recibo custodiado

11/09/2026. [Pieza sucesora acotada, Rust y evidencia](tuberias-ia/entrega-literal-desde-recibo/README.md). Corte Lenguaje `2e9dc3b216035725521a850b8157dc7d736fe57c`; laboratorio `4e681a9c88ebb66272cbb5c3ab9df2aed4dc3704`. Continúa la autorización humana y la rectificación de RETP-148; no se reabre la pregunta sobre quién concede autoridad.

Se construye y ensaya una candidata sobre copias fijadas de G1 y su enlace público, sin modificar núcleo, gramática, IR o fuente de dominio productivos. Compara el marco propuesto con el cuerpo del recibo seleccionado por el conductor confiable. Conserva un intento acotado con causa y propuesta cuando pudo capturarse. La entrega protegida sólo se construye tras comprobación satisfactoria y toma sus bytes del custodio. No transforma consulta en SUCESO/Frame ni en permiso.

Una matriz debug/release con Rust 1.98.0, 31 procesos, cero defectos inesperados o correcciones: por modo pasan 29 pruebas G1 anteriores, 11 nuevas y 12 del lote; cuatro contrastes CLI; 24 entregas iguales a cuerpos y huellas esperados previos; dos negativos de compilación previstos. Dato alterado con huella coherente y negación eliminada con huella coherente se rechazan sin salida de cuerpo. Paridad de las 24 entregas y los cuatro contrastes. Se conservan fuente exacta, comandos, entradas, salidas, huellas de binarios y procedencia del compilador.

Ocho fuentes de continuidad y 45 archivos existentes cotejados con el corte. La pieza sucesora conserva el workflow V2; no promueve la candidata ni cierra el recorrido entero. Quedan fuera verdad de origen, traducción/equivalencia visual, pantalla final, imposición material, persistencia durable, R1 profesional, reserva y P4/P5. El catálogo recibe causas tipadas y propuestas ES/EN sin acreditarlas como localización implementada. La CLI resume la familia Custodia; su integración diagnóstica productiva permanece pendiente.

**Estado: CONFORME_EN_FRONTERA_LITERAL_CANDIDATA.** Continúa correspondencia transformación/presentación bajo las compuertas constituidas y aceptación final humana.


<a id="retp-150"></a>

## RETP-2026-150 · Presentación de formato sin pérdida de contenido

12/09/2026. [Pieza sucesora acotada y evidencia](tuberias-ia/presentacion-sin-perdida-de-contenido/README.md). Corte Lenguaje `b8f0982f8c2183a71f8a32c12ab55e2e6148591b`; laboratorio `196b574f69d456bc31e81ae416d83513b1381730`. Continúa la luz verde sin reabrir autoridad humana ni pedir al autor el mecanismo técnico.

Sobre la candidata RETP-149 se introduce el perfil experimental IE004-PRESENTACION-ESPACIOS/1: sólo espacio, TAB, CR y LF fuera de cadenas pueden diferir; conserva valores, textos, escapes, claves y orden. Reconoce primero ambos documentos con el lector existente: no recompone por eliminación de espacios tokens inválidos. La vista protegida se obtiene desde EntregaLiteral y conserva referencia, identidad y perfil. No es interfaz profesional ni permiso ni certificado de dominio.

Una matriz Rust 1.98.0 debug/release, 47 procesos, cero correcciones causales. Por modo: 52 pruebas previas + 10 nuevas, 11 contrastes CLI, 24 presentaciones y originales cotejados con los esperados previos; cliente externo válido y dos negativos previstos de compilación. Paridad de textos, originales y salidas CLI. Fuentes, comandos, capturas, realizaciones y procedencia del compilador conservados.

La recuperación de los bytes originales usa explícitamente el custodio; no se atribuye esa información a la presentación sola. El comprobador no reserva memoria dinámica; esto no acredita RSS ni coste global del servicio. La retención de intentos de presentación se realiza en la campaña, no queda implementada como servicio durable. Diagnósticos tipados conservados; la CLI resume la familia del lector y no cierra su localización productiva.

Continúa el workflow V2. No se cambia núcleo productivo, gramática, IR ni dominios; no se abren agente, interfaz, reserva o P4/P5. Esta pieza sucede a RETP-149 en su alcance de formato; fidelidad visual, imposición material, catálogo y aceptación productiva final permanecen pendientes. **Estado: CONFORME_PERFIL_CANDIDATO_DE_ESPACIOS.**


<a id="retp-151"></a>

## RETP-2026-151 · Álgebra constituida y soporte real del núcleo

12/09/2026. [Auditoría acotada y evidencia](algebra-constituida-y-soporte-del-nucleo/README.md). Cortes Lenguaje e611218a8c6c04ade022b867018b84a7f3e6700e, doctrina b8fd32978292d25adf9b87cf71e409005dce642c y laboratorio 3fbf00f5f046c2d98d096ff51ec6c162ac5ca1ae. Continúa el mandato humano de contrastar las leyes generales ya constituidas con el núcleo, sin trasladarlas en bloque a la fase de agentes.

Se inventarían representación, validación y ejecución en doce familias, distinguiendo las reservas de Comp, supervisión y transducción. Rust actual admite operaciones evaluate/gate sin calcular sus resultados; doce testigos finales caracterizan siete admisiones y cinco rechazos semánticos exactos. Las admisiones General sin operador y actualización de puente sin productor corroboran deudas conocidas. Se conservan el montaje sintáctico inicial fallido, su corrección en los testigos, el plan final, fuentes, comandos, capturas y huellas; dos montajes nativos de quince procesos. No se modifican fuentes Rust productivas.

La deuda viva recibe el inventario sin duplicar identificadores ni declarar cierres de DFL-001/003/004/005/006/013. Workflow V2, catálogo/localización y secuencia rectora conservados; esta auditoría es entrada de la puerta algebraica de fila 10, no ejecución íntegra de esa fase. No se decide la composición particular dominio/agente, no se abre interfaz profesional ni reserva, y no se acredita seguridad universal ni aceptación productiva final. Estado: AUDITORIA_ACOTADA_Y_CARACTERIZACION_COMPLETADAS; CAPACIDADES_ALGEBRAICAS_PENDIENTES.


<a id="retp-152"></a>

## RETP-2026-152 · Lectura vinculada a invocación y procedencia

12/09/2026. [Candidata, contrato y evidencia](tuberias-ia/lectura-vinculada-a-invocacion/README.md). Cortes previos Lenguaje ad4d390d6fb1e7134040001b79ba2d433895b786 y laboratorio a4186826314bf466d50201182b37506d911080e5. Continúa la autorización humana con resultado recuperable y siguiente objeto único.

Sobre la entrega y presentación RETP-149/150 se añade vista documental con identidad seleccionada por el conductor, operación de lectura fija y procedencia prestada. Rechaza cruces incluso con cuerpos iguales, operación/versión ajenas, excesos y contenido distinto. No confiere autoridad profesional ni produce referencias protegidas de R1.

Una matriz Rust 1.98.0 debug/release, 17 procesos, 12 regresiones y nueve nuevos testigos por modo; 24 cuerpos y procedencia recuperados, cotejo con oráculo previo, dos negativos de compilación por modo. Sin corrección tras ejecutar ni fallo inesperado. Cápsula de 71 fuentes, capturas íntegras, comandos y reproductor conservados. Correspondencia de bytes no prueba origen físico de copias idénticas; custodia confiable intra-proceso, sin imposición de host ni integración productiva.

Se conserva workflow V2 y RETP-151. Próximo objeto: enlace con operación gobernada y productores reales de referentes protegidos; no fabricar autoridad ni reabrir al humano la definición ya dada. Catálogo/localización, fidelidad visual, cierre nuclear y aceptación productiva final pendientes. Estado: CONFORME_EN_ALCANCE_DOCUMENTAL.


<a id="retp-153"></a>

## RETP-2026-153 · Pertenencia de permisos y compromisos a su continuidad

12/09/2026. [Fallo, corrección candidata y evidencia](tuberias-ia/pertenencia-de-permisos-a-su-continuidad/README.md). Cortes Lenguaje cf366a339f66ba892a1ce783bb873d8c6f704801 y laboratorio 3d556f378df9306a73f3497e7ee39351640fec36.

La sonda R1 con dos constituciones sintéticas iguales reproduce aceptación de permiso ajeno y ejecución de compromiso ajeno bajo el mismo ordinal local. Se corrige en candidata mediante identidad interna de instancia propagada en permiso/compromiso y cotejada antes de mediar/ejecutar. El control propio conserva una llamada; ambos cruces se rechazan, con cero llamadas y cero eventos de ejercicio en el cruce de compromiso.

217/217 pruebas unitarias en debug y release (211 previas, seis nuevas). Agotamiento comprobado sin vuelta a cero, 128 asignaciones distintas en ocho hilos, compilación sin cfg(test) y dos causas de rechazo de un cliente que intenta mutar identidad o acceder a la inyección de prueba. Coste nativo medido: +16 B continuidad y +8 B por permiso/compromiso; contador estático de 8 B, sin nueva reserva dinámica en la guarda. No fija ABI, RSS o latencia ni acredita perfiles WASM.

Se conserva el fallo inicial de montaje por 12 fixtures ausentes; recuperados por blob sin cambiarlos. 14 procesos registrados, fuentes completas y parche revisable. El montaje interno no acredita autoridad profesional o admisión productiva. Se concretan productores pendientes de premisa externa y RequirementCheck; DFL-005 no cerrada. Workflow V2, catálogo/localización, reservas, pausa de dominios y aceptación final humana conservados. Núcleo productivo sin modificar. Estado: FALLO_REPRODUCIDO_CORRECCION_CANDIDATA_CONFORME.


<a id="retp-154"></a>

## RETP-2026-154 · Recepción gobernada y comprobación observada

12/09/2026. [Contrato, candidata y evidencia reproducible](tuberias-ia/recepcion-gobernada-y-comprobacion-observada/README.md). Cortes Lenguaje dba4d655280ae36172dd601377367a0f89b69010 y laboratorio 7cc917eef089e865af5325318bae911633daa029. Continúa en montaje aislado sobre la candidata RETP-153; no modifica el núcleo productivo.

Se realiza recepción posterior a admisión externa: el instalador interno fija premisa opaca ya existente, plan T-0, acto, emisor declarado y versión. La petición no los sustituye. Discordancias se rechazan antes de T-0; se conserva el original admisible, se impide segunda continuidad desde el mismo preparado y se conserva el error de génesis sin reparación.

Se realiza un productor interno de RequirementCheck desde igualdad exacta ejecutada para una obligación específica recibida por instalación de confianza. Conserva contrato, referencia, observación y préstamo de continuidad. Rechaza descriptores/aplicabilidades de otra instancia aunque sean iguales, obligaciones Core y excesos de tamaño. Evidencia ausente produce NotVerifiable, distinta de evidencia vacía y de Tri.U. No expone una comprobación desligada ni conversión a permiso.

231/231 unitarios nativos por modo (217 precedentes y 14 nuevos), biblioteca ordinaria sin cfg(test), cliente público conforme y tres clientes adversariales con cuatro errores exactos esperados (E0624 x2, E0451, E0616). Diez procesos registrados. Se conserva cápsula de 74 archivos, parche incremental y compilador. Límites por campo de 65536 bytes; no son cota de servicio ni doctrina celular.

La raíz y el plan positivos son sintéticos. No se autentica al emisor, no se interpreta el acto ni se producen todos los verificadores obligatorios. Premisa externa profesional aún sin productor material; la candidata no habilita esa actuación. Siguiente objeto: recepción material de premisa y verificadores para el enlace acotado; no volver a preguntar quién autoriza ni fabricar la evidencia que falta. Vía documental RETP-152 conservada, DFL-005/006 abiertas, aceptación humana final y compuertas reservadas intactas. Estado: RECEPCION_Y_COMPARACION_CANDIDATAS_CONFORMES_ADMISION_PROFESIONAL_NO_ACREDITADA.


<a id="retp-155"></a>

## RETP-2026-155 · Apuntes de trazabilidad, auditoría y reproducción del trabajo de la IA

12/09/2026. [PDF, Markdown y materiales conservados](tuberias-ia/trazabilidad-auditoria-y-reproduccion-del-trabajo-ia/README.md). Mandato expreso de Juan Antonio: poner en limpio la explicación y crear una carpeta hermana del frame en Calidad, con espejo en laboratorio. Cortes previos Lenguaje 19ade5d9be68901815bd284cc5631f20f08d3fa3 y laboratorio b9c623294c35b9f59f8ed6a3540cefeb12c84bd7; rectoras cotejadas sin cambios.

Consolida consulta del universo pertinente, pregunta de sistema 1/0/U como propuesta, diversidad de procedimientos válidos, corrección de resultado, conservación de scripts y cambios, reproducción y medición. La aclaración humana sobre los cimientos queda conservada sin atribuir cobertura de seguridad universal. Cinco capturas originales intactas, transcripción con corrección expresa de tipos y PDF de ocho páginas revisado visualmente.

Tres ejemplos editoriales Rust compilados y ejecutados, seis procesos, tres salidas exactas [4, 8, 12]. Fuentes, invocaciones, salidas, tiempos y scripts de generación/comprobación recuperables. Se conservan las incidencias editoriales de fuente tipográfica y renderización. Se añaden navegación recíproca e índices, con identidades actualizadas. Sin cambios de núcleo, de semántica o de contratos; no reejecuta ni amplía RETP-154. Su siguiente objeto y límites permanecen vigentes. Estado: REFERENCIA_DOCUMENTAL_CONSOLIDADA.


<a id="retp-156"></a>

## RETP-2026-156 · Adenda de encaje visual y lectura troncal

12/09/2026. [Léame primero y adenda](tuberias-ia/frame-significado-humano-trazabilidad-y-fidelidad/LEAME_PRIMERO.md). Cortes Lenguaje 82b311136e52a824c00c4fee3a67eaaafa94bb1e y laboratorio 03b6af3c0f726686ee177243045eba1902a9f9b2. Mandato humano expreso: completar la carpeta del volcán con polígonos históricos IMMUNO-1/2, logo del SV y secuencia de lectura.

Adenda de siete páginas y Markdown, tres imágenes intactas, generador recuperable y nota de preparación. Concreta la referencia visual compartida por experto y agente y el acceso complementario a la representación computable. Mantiene n=b², orden posicional y distinción del SV respecto de un espacio vectorial. Las leyendas de las imágenes no se homogeneizan silenciosamente ni se trasladan los antiguos parámetros a los dominios actuales. La precisión sobre Rust se apoya en fuentes oficiales y separa seguridad de memoria de superioridad de rendimiento.

Watson confirma aquí su comprensión; Juan Antonio declara su conformidad y luz verde al cierre del escenario explicado y ordena su custodia. No se fabrica una cita anterior ni se convierte ese cierre documental en validación clínica o productiva. El diálogo/PDF previo del frame permanece intacto. README y léame primero ordenan volcán → adenda visual → auditoría → relevo vigente; índices y registros duales actualizados, copia idéntica en laboratorio. PDF revisado visualmente, huellas y enlaces comprobados; sin ensayos nuevos del núcleo. Se mantiene el siguiente objeto de RETP-154. Estado: ENCAJE_VISUAL_COMPRENDIDO_CONFORMIDAD_HUMANA_RECIBIDA_DOCUMENTADO.


<a id="retp-157"></a>

## RETP-2026-157 · Causas de recepción, ES/EN y reproducción entre modelos

12/09/2026. [Plan, candidata, catálogo y evidencia](tuberias-ia/diagnosticos-de-recepcion-y-prueba-entre-modelos/README.md). Cortes Lenguaje 1eaee20a87cdff0e2a21c5297b8787a27b5a1102 y laboratorio 9ea6053eccd3fa50b37fdab9478e116794fa1aac; rectoras cotejadas. El mandato humano pide continuar las pruebas del paso 6 del plan de integración, conservar fallos/localizaciones y preparar reproducción por otros modelos. No se confunde ese paso con P6 del workflow.

Se realiza una ampliación aditiva de la cápsula RETP-154: métodos detallados de recepción y comparación preservan fase y causa desde el emisor. Se separan campos vacíos/excesivos y discordancia de emisor/versión; se conservan precedencia, errores de la API previa y error T-0 tipado. La localización estática ES/EN no modifica decisiones. Veinte claves locales del contrato RECEPTION-DIAGNOSTICS/1; no nuevas claves canónicas SV.

239/239 pruebas por configuración nativa (231 anteriores y ocho nuevas), 40 casos focales en tres repeticiones por configuración y 240 observaciones comprobadas. Cuatro clientes adversariales producen seis errores exactos esperados de acceso. Dieciocho procesos registrados con comandos, salidas, huellas, tiempo y CPU; RSS es máximo acumulado de hijos, no medida por caso. Cápsula de 76 archivos, parche, scripts, catálogo localizado y encargo externo recuperables. No hubo fallo inesperado en esta ejecución.

Premisa positiva sintética. No se acredita admisión profesional, cobertura completa A–L, P3/P4/P5, WASI, navegador ni cierre DG01–DG14 global. El compilador conserva emisiones textuales E004/E115 y CompileError::InvalidProgram(String); se localiza su migración como siguiente frente diagnóstico. Cero ejecuciones externas recibidas: Qwen/DeepSeek/Grok/Claude disponen de un encargo público con exposición declarada y sin reinicio de reservas. DFL-001/005/006/011 permanecen abiertas; filas y aprobación humana conservadas. Núcleo productivo sin modificar. Estado: DIAGNOSTICOS_CANDIDATOS_NATIVOS_CONFORMES_CIERRE_GLOBAL_PENDIENTE.

**Corrección del instrumental en el mismo corte:** localizada por inspección una espera final sin timeout tras cierre de ambos flujos. Se conserva la versión exacta de los 18 procesos, se corrige la espera y se comprueba el instrumento con tres procesos adicionales (tiempo con flujos abiertos/cerrados y tamaño). Evidencia separada, sin cambio de candidata/oráculo ni repetición de su cualificación.


<a id="retp-158"></a>

## RETP-2026-158 · Causas del compilador, procedencia por unidad y ES/EN

12/09/2026. [Plan, contrato, fuentes y evidencia](tuberias-ia/diagnosticos-del-compilador-y-procedencia/README.md). Cortes Lenguaje 4cacf3ec6bd5d0f31206197c7374515a56b34a89 y laboratorio 1ac32131e2c328e395d828268a5e3517ce43fcca. Se continúa, por mandato humano, el paso 6 del plan de integración; no se confunde con P6 del workflow. Pilares, perfiles y transición cotejados; contrato diagnóstico 109/110 aplicado al alcance escogido.

Candidata aditiva sobre RETP-157: sidecar de rangos de bytes de declaraciones originales y metadatos de unidad fuera de IR; causas tipadas E004 vacío/repetición, E115 con listas separadas y colisiones con ambas declaraciones. FrontendError se conserva por variantes; EOF y carácter léxico inválido conservan posición. Los emisores restantes permanecen explícitamente sin migrar. Un recorrido común alimenta la API detallada y las API heredadas. Doce claves locales CD.* con ES/EN; sólo E004/E115 reciben los códigos canónicos ya existentes.

239 unitarios por modo debug/release. Corpus canónico 14 válido/106 inválido: aceptación y payload heredado idénticos entre base y candidata. 29 casos focales, tres repeticiones por modo, 174 observaciones en el receptor. Cuatro clientes negativos conservan seis errores de acceso exigidos; cliente público conforme. Se conservan cualificación y reproducción portátil con salidas, hashes, tiempos y medidas de recursos. Se documenta un fallo del script de edición previo a escribir la candidata, corregido sin cambiar esperados; no hubo fallo inesperado en las ejecuciones de la candidata.

La IR y el núcleo productivo no se modifican. Continúan rangos sintácticos restantes, subcausas de perfil, emisores de otros validadores, serialización diagnóstica, DG01–DG14 global y DFL-001/011; DFL-005/006, WASI/navegador y compuertas P3/P4/P5 permanecen abiertas o cerradas según su estado previo. Ningún proveedor externo ejecutado. SVcustos se mantiene como sede prevista del encargo común; el paquete abierto de reproducción no se confunde con prueba ciega. Estado: DIAGNOSTICOS_COMPILADOR_CANDIDATOS_NATIVOS_CONFORMES_CIERRE_GLOBAL_PENDIENTE.


<a id="retp-159"></a>

## RETP-2026-159 · Ubicaciones sintácticas y perfil fuente

12/09/2026. [Candidata, contrato, reproducción y evidencia](tuberias-ia/ubicaciones-sintacticas-y-perfil-fuente/README.md). Cortes de entrada: Lenguaje 03d00131fb0df234101f01c9ca5dfa5f22886ceb; laboratorio ce202d9420adb2c6189fce557ad74e2a276c3a0c, rama lab/playground-sv-permanente. Rectoras consultadas: AGENTS, Pilares, perfiles y ensamblaje, transición completa y relevos, contrato diagnóstico 109/110, workflow V2 y plan de integración 147.

Incremento del paso 6 sobre la cápsula RETP-158: las primitivas sintácticas incluidas registran su intervalo original en el punto de rechazo. La incompatibilidad de grafía con el perfil se conserva desde la clasificación léxica y el contexto de comprobación; no se deduce del mensaje. La sucesión experimental COMPILER-DIAGNOSTICS/2 añade una variante y causa local con ES/EN. Los identificadores contextuales legítimos, comentarios y literales mantienen su tratamiento; las API heredadas, los códigos SV y la IR conservan su contrato.

40 fuentes focales (8 válidas, 32 inválidas), 64 ensamblajes derivados con unidad sana de otro perfil y nombre de archivo compartido, tres repeticiones por modo. Corpus canónico 14/106 con resultados heredados idénticos; 239 unitarios por modo y 29 focales anteriores, con sucesión expresa de dos esperados. 13 causas locales y 26 plantillas; dos controles de sensibilidad detectan causa ausente e intervalo desplazado, y dos controles ES/EN preservan intervalo ausente en emisores todavía pendientes. Cuatro clientes negativos mantienen seis errores de acceso. Cualificación y complemento: 41 y 7 procesos, respectivamente. Reproducción completa desde paquete: fuentes y documentos de resultado idénticos, con registros separados. Sin fallos inesperados de la candidata.

Se conservan comandos, binarios identificados, salidas, tiempo, CPU y máximo acumulado de memoria de procesos hijos. La medición incluye compilación y no acredita consumo por caso, coste incremental, rendimiento relativo ni coste monetario. Restan emisores compuestos y validadores, presentación/serialización final y DG global; WASI/navegador, recepción profesional y compuertas P3/P4/P5 mantienen su estado. DFL-001/011 y las demás deudas no se cierran. Código productivo sin modificar; laboratorio privado; encargo externo pendiente. Siguiente objeto: completar los emisores diagnósticos restantes en el mismo paso. Estado: CONFORME_EN_ALCANCE_NATIVO; CIERRE_GLOBAL_PENDIENTE.


<a id="retp-160"></a>

## RETP-2026-160 · Ubicaciones de rechazos compuestos

12/09/2026. [Candidata, contrato y evidencia reproducible](tuberias-ia/ubicaciones-de-rechazos-compuestos/README.md). Cortes: Lenguaje 76722442d2899300c69d89ab932890a4d7d74c2f; laboratorio afcbd5046b2eec24cb058ce0fedcf580ca4790e8, rama lab/playground-sv-permanente. Se cotejaron las rectoras leídas: AGENTS, Pilares, perfiles y ensamblaje, transición y relevos. Continúan el contrato diagnóstico 109/110, workflow V2 y plan 147, con la referencia conceptual de frame, significado humano, trazabilidad y fidelidad.

Doce puntos de rechazo conservan el índice original antes de consumir el elemento: ocho ramas de campos opcionales de SemanticRelation/Pattern, variantes de supervisión y consulta, palabra protegida en let y etiqueta individual de admisibilidad. La validación conserva su posición y precedencia. La grafía extranjera se clasifica desde el estado léxico y el contexto, sin interpretar prosa. Extensión observable de cobertura de COMPILER-DIAGNOSTICS/2, sin nuevas variantes ni plantillas. Los controles antiguos de rango ausente en campos opcionales quedan sucedidos expresamente; su expediente se conserva.

54 fuentes nuevas (2 válidas, 52 inválidas), más 40 anteriores con esperados intactos: 94 fuentes y 168 ensamblajes derivados, tres repeticiones en debug y release. 564 observaciones monofuente y 1.008 comprobaciones de ensamblaje, sin inflar el número de fuentes distintas. Huellas, intervalos UTF-8, índice y perfil de origen comprobados. Corpus 14/106 y resultados de API heredada idénticos; 239 unitarios por modo; 29 focales anteriores y prueba relacional conservados. Las mismas 13 causas y 26 plantillas; cuatro clientes negativos y seis errores de acceso. Dos controles detectan la ausencia de intervalo en la base y el índice desplazado en un mutante. Cualificación 41 procesos, complemento 7; reproducción completa en directorio nuevo con fuentes y resultados idénticos y registros separados. Sin fallos inesperados.

Sólo cambia frontend.rs de la cápsula experimental; otros 76 archivos idénticos. No se promueve código productivo. Las mediciones incluyen compilación y no acreditan rendimiento relativo, coste por caso, dinero ni inferencia. La cardinalidad incorrecta del conjunto de estados sigue sin intervalo, comprobada en ES/EN; las conversiones defensivas y demás validadores conservan sus pendientes. Siguiente objeto: ubicación del conjunto en cardinalidad, preservando precedencia y diferencia con etiqueta individual. Paso 6 incremental, P6 y DG global abiertos; DFL-001/011 y otras deudas sin cierre. Fila 9 y prioridades conservadas; P3 cerrado, P4/P5 con sus compuertas. Encargo externo, WASI/navegador y recepción profesional pendientes. La precisión diagnóstica no demuestra fidelidad final del conocimiento presentado. Estado: CONFORME_EN_ALCANCE_NATIVO; CIERRE_GLOBAL_PENDIENTE.


<a id="retp-161"></a>

## RETP-2026-161 · Intervalo del conjunto escrito de estados

12/09/2026. [Candidata, contrato y evidencia reproducible](tuberias-ia/intervalo-del-conjunto-de-estados/README.md). Cortes: Lenguaje 0ef4330b9bb18b09f5a386784d7d3baa559624b2; laboratorio 605de268874621538489554a3f1be0b83f1f4a1f, rama lab/playground-sv-permanente. Se mantienen las ramas existentes y el historial; sin apertura de ramas ni renumeración. Rectoras cotejadas: AGENTS, Pilares, perfiles/ensamblaje y transición/relevos. Continúan el contrato diagnóstico 109/110, workflow V2, plan 147 y la referencia de frame, significado humano, trazabilidad y fidelidad.

El rechazo states.len() != 3 recibe el intervalo completo de la colección escrita, con ambas llaves y contenido interior, excluyendo separador y comentarios posteriores. La condición cuenta etiquetas, incluidas repeticiones, no valores distintos. Se conserva exactamente su punto de emisión después de comprobar cierre y separador, antes de rule. El registro interno admite extremos inclusivos de token; los errores de un elemento mantienen el mismo índice en ambos. Extensión observable de COMPILER-DIAGNOSTICS/2 sin nuevas causas, variantes, mensajes, admisión ni IR. Dos intervalos antes ausentes se suceden expresamente; sus fuentes, IDs, causas y documento original se conservan; otros 92 esperados intactos.

48 fuentes nuevas (12 válidas, 36 inválidas), más 94 heredadas: 142 fuentes y 240 ensamblajes derivados, tres repeticiones por modo. 852 observaciones monofuente y 1.440 comprobaciones de ensamblaje sin inflar fuentes distintas. Incluye longitudes 1/2/4/6, seis permutaciones por perfil, comentarios con llaves, CRLF y precedencia. Huellas, intervalos UTF-8 y unidad/perfil de origen comprobados. Corpus 14/106 y API heredada idénticos; 239 unitarios por modo; 29 focales y relación anteriores; catálogo 13/26 y cuatro clientes negativos/seis errores de acceso conservados. Tres controles detectan ausencia de intervalo, exclusión de cierre y rechazo anticipado.

La primera ejecución se interrumpió con E0786 al consumir la biblioteca optimizada de la base, cuya compilación devolvió cero. Se preservan el artefacto comprimido, sus huellas y todas las salidas del intento. Repetición completa con fuentes, instrumento y opciones idénticos: conforme. La causa raíz de los metadatos corruptos permanece sin determinar; no se acredita una corrección de rustc. Cualificación conforme: 41 procesos; complemento: 10; reproducción completa en directorio nuevo con fuentes y resultados idénticos. El intento interrumpido y sus costes se conservan aparte.

Un archivo de la cápsula modificado y otros 76 idénticos; sin promoción productiva. Medidas incluyen compilación y no acreditan rendimiento relativo, coste por caso, dinero o inferencia. Siguiente objeto acotado: determinar alcanzabilidad y tratamiento de las conversiones defensivas restantes antes de atribuirles ubicación o cobertura. Después continúan validadores y subcausas del paso 6. P6/DG global y DFL-001/011 siguen abiertos; fila 9 y prioridades conservadas, P3 cerrado, P4/P5 con sus compuertas. Encargo externo, destinos y recepción profesional pendientes. No se acredita fidelidad final del conocimiento presentado. Estado: CONFORME_EN_ALCANCE_NATIVO; INCIDENCIA_INSTRUMENTAL_CONSERVADA; CIERRE_GLOBAL_PENDIENTE.


<a id="retp-162"></a>

## RETP-2026-162 · Revisión de secuencia, cobertura y relevo integrado

12/09/2026. [Dictamen, reutilización, matriz A–L y siguiente objeto](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/REVISION_SECUENCIA_COBERTURA_Y_RELEVO_RETP_162.md). Cortes: Lenguaje 0910fc792b98286b4bce1c9ce477f4a76dab8023; laboratorio 0544ea35d6a903be992d0b0fff6d0c6a5770b208, rama lab/playground-sv-permanente. Veintiséis fuentes de contrato, resultado publicado y rectoras cotejadas; las rectoras previamente leídas conservan identidad. Revisión documental y de secuencia; sin nueva ejecución funcional.

Se confirma el mandato de integrar puntos originales 1 y 3 y recoger errores durante el recorrido, consolidando el punto 2 después. El paso 6 de RETP-147 y P6 del workflow tienen papeles distintos. Los relevos 157–161 ampliaron diagnósticos y encadenaron emisores como próximos objetos sin acreditar cierre integrado. Se conserva su autorización acotada, utilidad, evidencia e incidencias; se corrige la prioridad. El estudio de conversiones defensivas de RETP-161 deja de ser el próximo objeto automático y permanece en el inventario.

Reutilización delimitada de entrega literal 149, espacios/presentación 150, lectura vinculada 152, pertenencia 153, recepción/comprobación 154 y diagnósticos 157–161. Las regresiones y reproducciones no se cuentan como nuevas fuentes u obligaciones. Los doce criterios A–L se preservan y se anotan evidencias parciales y carencias; no se acredita su campaña integrada. Se mantiene la rectificación 148: premisa/verificadores profesionales pendientes no bloquean toda lectura documental. La custodia humana P3 ya recibida en 130 no se vuelve a pedir. La incidencia E0786 queda conservada, sin nueva investigación en este corte.

Siguiente objeto único: C/I, cobertura de referencia independiente, para distinguir selección completa y selección que omite evidencia exigida aunque conserve citas verdaderas. Preparación del montaje y esperados antes de ejecución; reutilización de custodia/entrega/lectura existentes y corrección limitada a pérdida demostrada. El catálogo recibe causas necesarias y se consolida después del alcance integrado correspondiente. El encargo público de reproducción 157 no se confunde con la futura prueba externa común; cero ejecuciones de ese encargo recibidas. P3 reservado, P4/P5, auditoría P6, DFL y continuación de fila 9 conservan compuertas. Sin nuevas ramas, renumeración histórica, cambios de Rust/corpus/oráculos ni promoción productiva. Estado: PRIORIDAD_RECONCILIADA_COBERTURA_INTEGRADA_PENDIENTE.


<a id="retp-163"></a>

### RETP-2026-163 · S0 · Apertura del registro Sucesos SV

2026-09-12T10:21:21Z. Se establece el [registro incremental Sucesos SV](Inventario-sv/sucesos/README.md), con [estado vigente](Inventario-sv/sucesos/SUCESOS_SV.md), CSV e historial de actualizaciones. S0 documenta su puesta en servicio; S1 queda pendiente para el contraste C/I de RETP-162. Los únicos estados admitidos son pendiente, en ejecución y finalizado. Se conservan los identificadores publicados, las instantáneas históricas y la correspondencia entre copias. Responsable: Watson / W-S0.

La incorporación es obligatoria y complementaria a los registros de calidad y al recorrido documental de laboratorio y su espejo. Se añade la entrada en Léame primero de ambas sedes y se retira exclusivamente docs/calidad/Inventario-sv/sucesos/inicio.md, cuyo contenido previo era una línea vacía. La serie comienza ahora; no se renumeran los antecedentes. Cortes de entrada: Lenguaje be9e5e4d4041223223bd7d0dc38e1851414fd46a, main; laboratorio dd6d563ea7b75dd1d420f1fe542334b224a55886, lab/playground-sv-permanente. AGENTS.md consultado; alcance exclusivamente documental. No se modifica gramática, perfiles, compilador, IR, núcleo, contratos de dominio o agente, frontera u host.

Resultado: Estructura documental preparada; publicación y verificación de las copias pendientes. Verificación: Pendiente de cotejo de las publicaciones. Estado de S0: en ejecución. Sin nuevos ensayos funcionales ni apertura de ramas.


<a id="retp-163-cierre-s0"></a>

### RETP-2026-163 · S0 · Finalización verificada del registro Sucesos SV

2026-09-12T10:23:08Z. Se establece el [registro incremental Sucesos SV](Inventario-sv/sucesos/README.md), con [estado vigente](Inventario-sv/sucesos/SUCESOS_SV.md), CSV e historial de actualizaciones. S0 documenta su puesta en servicio; S1 queda pendiente para el contraste C/I de RETP-162. Los únicos estados admitidos son pendiente, en ejecución y finalizado. Se conservan los identificadores publicados, las instantáneas históricas y la correspondencia entre copias. Responsable: Watson / W-S0.

La incorporación es obligatoria y complementaria a los registros de calidad y al recorrido documental de laboratorio y su espejo. Se añade la entrada en Léame primero de ambas sedes y se retira exclusivamente docs/calidad/Inventario-sv/sucesos/inicio.md, cuyo contenido previo era una línea vacía. La serie comienza ahora; no se renumeran los antecedentes. Cortes de entrada: Lenguaje be9e5e4d4041223223bd7d0dc38e1851414fd46a, main; laboratorio dd6d563ea7b75dd1d420f1fe542334b224a55886, lab/playground-sv-permanente. AGENTS.md consultado; alcance exclusivamente documental. No se modifica gramática, perfiles, compilador, IR, núcleo, contratos de dominio o agente, frontera u host.

Resultado: Registro puesto en servicio desde S0, con S1 pendiente, historial de cambios y entrada obligatoria en Léame primero. Retirado el archivo de soporte de la carpeta de sucesos. Verificación: Publicaciones de apertura cotejadas: cuatro archivos del registro idénticos entre repositorios; Léame primero idéntico; historial RETP previo conservado; inicio.md de sucesos ausente; sin cambios ajenos al alcance. Estado de S0: finalizado. Sin nuevos ensayos funcionales ni apertura de ramas.

Evidencias de apertura cotejadas: https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/commit/06da92137bcac75f3ae4b23ca059550fdf0a6a6c ; https://github.com/juantoniolloretegea/SV-matematica-semantica-cuaternaria/commit/c237e9d6dc06f481f75a3a874b3bfcf411a4ba32.


<a id="retp-164"></a>

## RETP-2026-164 · S1 · Apertura del contraste C/I

2026-09-12T10:37:36Z. [Contrato previo y expediente](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s1-cobertura-independiente/README.md). S1 pasa a en ejecución. Se reciben los cortes Lenguaje 428d294c42602bc116fa0550262c25730017492e y laboratorio 0d6b386121a24e915ce550dc2b52186867f6fdd4, en las mismas ramas. AGENTS, Pilares, perfiles y transición leídos y cotejados; RETP-123/141/147/152/162 y Sucesos SV delimitan el alcance. Se reutiliza la cápsula pública RETP-152 sin cambios; P3-01 y P3-04 fijan el contraste de cobertura documental del caso y su vigencia. El montaje negativo es sintético y no constituye una revocación profesional. Se fijan controles, referencia independiente, presupuesto y parada antes de ejecutar. Sin nuevas rondas de modelos ni apertura de reserva. La integración 1+3 mantiene prioridad; catálogo posterior y restantes obligaciones conservadas. Estado del suceso: en ejecución.


<a id="retp-164-cierre-s1"></a>

### RETP-2026-164 · S1 · Recepción del contraste de cobertura documental

2026-09-12T10:51:15Z. [Resultado, evidencia e intentos conservados](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s1-cobertura-independiente/README.md). S1 finalizado en el alcance de banco declarado; S2 pendiente para el contraste causal de vigencia de una consulta inequívoca. Se conservan las mismas ramas y todos los estados anteriores de Sucesos SV.

La ruta previa RETP-152 entrega el cuerpo y recupera la evidencia, pero no recibe la selección adicional ni acredita su cobertura. Se conservan sus 71 fuentes sin cambios. La candidata local Rust obtiene la referencia antes de recibir la propuesta y exige caso y entrada de montaje; su vista sólo se construye tras comprobar lectura y ambas piezas. No decide significado, vigencia, permiso ni inscripción de dominio.

Cualificación: ocho controles, tres ejecuciones por cada uno de dos modos nativos; 48 observaciones sobre dos posiciones de cobertura, con cuatro posiciones recorridas por orden del enlace. Cuatro cuerpos preservan sus esperados previos; 29 capturas por ejecución son idénticas entre las seis ejecuciones. Dos mutantes se detectan por CI02 y dos clientes que intentan fabricar la referencia son rechazados por el compilador. Las causas permanecen locales y separadas de U; no se consolida ahora el catálogo.

El intento inicial con /usr/bin/time no inició el productor. El primer contraste se detuvo en CI07 por un espécimen JSON inválido, rechazado como Sintaxis(Json). Una observación puntual y una adenda conservan la discrepancia y corrigen sólo el espécimen, con el mismo esperado de contenido y la candidata intacta. Ambos intentos están documentados por separado; no se cuentan como cualificación conforme. Presupuesto: 30 invocaciones registradas, 29 procesos iniciados; ningún reinicio de rondas de modelos. CPU y pared registradas, RSS por proceso no disponible; viabilidad P5 no acreditada.

Límite causal: P3-04 contiene vigencia negativa, pero la petición es ambigua y no consulta la política. La prueba no demuestra una revocación aplicable ni cierra C/I íntegros o A–L. S2 conserva el único siguiente objeto para resolver esa distinción con un par previo. Prueba externa, premisa/verificadores profesionales, reserva P3, P4/P5/P6 y restantes criterios conservan sus condiciones. Reproductor con fuentes fijadas entregado sin atribuirle una ejecución adicional. Sin cambios en código productivo, gramática, IR o nuevas ramas.


<a id="retp-165"></a>

### RETP-2026-165 · S2 · Apertura de contraste causal de vigencia

2026-09-12T11:23:19Z. [Contrato, presupuesto y esperados previos](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s2-vigencia-causal/CONTRATO_S2.md). S2 en ejecución; sin resultados atribuidos. Continúa C/I integrado de RETP-164: consulta inequívoca A01, idéntica bajo dos vigencias en G1 y enlazada a P3-01/P3-11 del lote. Esperados DATO/8.40 y PERMISO_REVOCADO/null, una llamada de política en ambos. Montaje sucesor declarado; fuentes históricas conservadas. Doce controles, seis ejecuciones nativas previstas y dos sensibilidades, máximo 23 invocaciones. Mismas ramas, registros y espejo de laboratorio. La prueba externa y la consolidación posterior del catálogo conservan su lugar en el workflow.


<a id="retp-165-cierre-s2"></a>

### RETP-2026-165 · S2 · Recepción del contraste causal de vigencia

2026-09-12T11:28:10Z. [Expediente S2, resultado, comandos y capturas](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s2-vigencia-causal/README.md). S2 finalizado en el alcance sintético nativo fijado antes de ejecutar. S3 pendiente: criterio D, correspondencia de presentación y pérdida de negación, con reutilización de RETP-149/150/152.

El mismo archivo A01, byte por byte y con idéntico contexto, produce DATO/8.40 bajo vigencia positiva y PERMISO_REVOCADO/null bajo vigencia negativa. Ambas trazas conservan análisis completo, un único significado y una llamada de política. La integración por P3-01/P3-11 conserva IDs distintos e iguales pregunta y contexto; sólo se cambia la vigencia de P3-11 en un montaje sucesor identificado. No es modificación de una autorización viva ni prueba de revocación profesional.

Doce controles en seis ejecuciones nativas: 72 observaciones, 42 capturas idénticas por ejecución, diez cuerpos anteriores conservados. Dos sensibilidades detectadas en CI02 y CA02. Presupuesto cerrado: 23 invocaciones, sin fallos instrumentales ni correcciones adicionales. El reproductor publicado es el ejecutado. CPU y pared registradas; RSS por proceso no disponible.

Cápsula original de 71 archivos intacta; copia ejecutable con 69 archivos idénticos y dos sustituciones declaradas de montaje y fijación del enlace. Lógica de cobertura S1 reutilizada con versión/rangos nuevos; semántica, política, custodia, entrega y lectura de la candidata intactas. Capturas completas y causas locales conservadas, sin nuevos códigos SV ni conversión a U. C/I global y A–L no se dan por cerrados; prueba externa común, P3 reservada, P4/P5/P6 y consolidación posterior del catálogo conservan sus condiciones. Sin cambios productivos, nuevas ramas o repetición de S1.


<a id="retp-166"></a>

### RETP-2026-166 · S3 · Apertura de presentación en destino

2026-09-12T11:38:45Z. [Contrato previo, controles y presupuesto](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s3-presentacion-y-negacion/CONTRATO_S3.md). S3 en ejecución. RETP-150 ya rechaza la eliminación de negación; S3 prueba la composición con cobertura y los bytes realmente escritos/recuperados de un archivo, sin atribuir de nuevo la prueba aislada. Referencia P3-01/A01; 73 fuentes S2 sin cambios; sólo conductor de ensayo nuevo. Ocho controles, seis ejecuciones y dos sensibilidades previstos, máximo 22 invocaciones Rust. Preparación anterior a la fijación conservada aparte. Mismas ramas y espejo de registros. La representación gráfica y la recepción externa permanecen pendientes.


<a id="retp-166-cierre-s3"></a>

### RETP-2026-166 · S3 · Recepción de presentación y objeto recuperado

2026-09-12T11:42:55Z. [Expediente S3, evidencia y reproducción](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s3-presentacion-y-negacion/README.md). S3 finalizado en alcance documental nativo; S4 pendiente para preparar la prueba externa común del recorrido delimitado.

RETP-150 ya rechazaba la supresión de negación; S3 acredita su composición con lectura, cobertura y escritura/recuperación real de archivo. P3-01/A01 conserva su esperado y sus fuentes. La presentación literal y la espaciada se recuperan exactamente. Eliminar no ante acredita antes de validar produce ContenidoDistinto y no crea destino; alterarlo después de escribir se detecta sobre el archivo recuperado mientras cuerpo y vista permanecen intactos. La detección posterior no se presenta como prevención frente al host.

Ocho controles en seis ejecuciones, 48 observaciones; 28 capturas idénticas por recorrido y 201 artefactos preservados incluyendo sensibilidades. Veintidós invocaciones dentro del presupuesto, sin fallos inesperados de cualificación ni cambios de esperados. Sensibilidades detectadas en D03 y D04. Un error de sintaxis de preparación, anterior a la fijación y sin inicio de Rust, queda documentado aparte. Reproductor publicado ejecutado; CPU y pared registradas, RSS individual no disponible.

Las 73 fuentes S2 se conservan intactas; sólo se añade conductor acotado de archivo. Causas de contenido, cobertura, límite y E/S diferenciadas; sin conversión a U ni códigos SV nuevos. No se prueban pantalla, renderizador, revisión humana, persistencia ante corte eléctrico, escritura atómica o resistencia al host. D/C/I universales, A–L y P4/P5/P6 conservan sus condiciones. S4 preparará una misma instrucción y fuentes accesibles, con esperados custodiados; banco conocido, sin envío de encargos ni apertura de reserva. El catálogo sigue recogiendo causas y se consolida después. Mismas ramas y espejo de evidencia, sin repetir campañas históricas como nuevos resultados.


<a id="retp-167"></a>

### RETP-2026-167 · S4 · Fijación de prueba externa común

2026-09-12T11:58:46Z. Doce casos derivados de capturas S2/S3 ya ejecutadas y cotejadas. Oráculo previo custodiado con huella pública; documento autosuficiente, fuentes exactas, rúbrica de 100 puntos y plantillas fijados. SVcustos main será la sede de lectura sin acceso al laboratorio privado; no se crean ramas. Se distinguen corrección, trazabilidad, actividad registrada y métricas medidas/declaradas/no disponibles. La recepción efectiva por cada participante sigue pendiente. No nueva campaña funcional ni apertura de reserva.


<a id="retp-167-cierre-s4"></a>

### RETP-2026-167 · S4 · Publicación y acceso de prueba externa común

2026-09-12T12:03:04Z. [Paquete público inmutable](https://github.com/juantoniolloretegea/SVcustos-dataset/blob/e1dcd9f5df30a1bbbfd446c7c4e5578d0a08a75c/pruebas-externas/s4-recorrido-documental/PRUEBA_COMUN.md). S4 finalizado; S5 pendiente para recepción efectiva. Doce casos con resultados previos cotejados; oráculo en custodia antes de publicar y compromiso público; rúbrica 48/36/8/8, medidas temporales y recursos separados. Documento autosuficiente de 19.470 bytes y ZIP de 789.529 bytes descargados sin credenciales, HTTP 200 y huellas idénticas. El lector web previo no obtuvo lectura (DisabledError), sin atribuirle la verificación posterior.

SVcustos main aloja el encargo y 51 archivos históricos de reproducción, sin acceso privado obligatorio ni escritura por participantes. Confirmación de lectura efectiva, respuestas, puntuaciones y tiempos aún pendientes. La vía adjunta conserva el mismo documento. No mensajes enviados, nuevas pruebas funcionales ni reserva P3. S5 conservará originales e intentos y evaluará resultado, trazabilidad y evidencia de procedimiento contra el oráculo fijo. Catálogo y restantes compuertas mantienen su secuencia. [Recibo de preparación y acceso](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s4-prueba-externa-comun/README.md).


<a id="retp-168-recepcion-s5"></a>

### RETP-2026-168 · S5 · Recepción de DeepSeek, Claude y Qwen

2026-09-12T12:25:53Z. S5 en ejecución. [Expediente de recepción](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s5-recepcion-externa/README.md): originales preservados, doce casos cotejados por participante, trazabilidad documental: DeepSeek 35/36, Claude 35/36 y Qwen 23/36. DeepSeek E10 confunde FaltaCaso con FaltaVigencia y mantiene el rechazo. Claude E05 atribuye conversión en DATO no acreditada por el supuesto. Etiquetas de decisión y Límite/Limite reservadas para revisión común por insuficiente precisión del documento público, con cotejo literal conservado. Sin nota definitiva ni clasificación entre participantes.

Ocho fuentes, documento y ZIP cotejados; esas comprobaciones pertenecen al receptor y no certifican actividad de los participantes. Ambos declaran lectura documental y no ejecución Rust. Claude declara exposición previa alta y mediciones propias sin registros adjuntos; se utiliza como cotejo documental. Tiempo total, tokens y coste no disponibles. El orden comunicado no mide rapidez. Qwen recibido: causas técnicas sustituidas y límites por caso ausentes. Grok con acceso comunicado; encargo preparado y no enviado. Oráculo, rúbrica y prueba S4 intactos; historias conservadas; mismas ramas. Continúan integración 1+3 y causas registradas, con catálogo consolidado después.


<a id="retp-169-recepcion-grok"></a>

### RETP-2026-169 · S5 · Recepción de Grok

2026-09-12T14:26:45Z. [Original y cotejo de Grok](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s5-recepcion-externa/grok/README.md): 16.657 bytes, SHA-256 44ed909b9a7a16830f747f80480f0a98aa1afd89c5bd198dc7dc649cd585abcf; doce IDs únicos. Cuarta respuesta inicial recibida. Modalidad documental; sin ejecución Rust declarada. E05 rechaza pero selecciona CasoDistinto; F04 permanece y se sustituye el montaje F05, por lo que corresponde VigenciaDistinta. Traza 35/36; resultado literal 39/48, ocho puntos de decisión reservados por la misma ambigüedad pública ya documentada. No nota definitiva ni clasificación por velocidad.

Ocho llamadas, lectura reconstruida y huellas recalculadas declaradas sin registros adjuntos. El receptor cotejó fuentes, longitudes, huellas y código de cobertura previo, sin nuevas pruebas funcionales. El acceso no acredita ejecución. Los cuatro originales están recibidos; S5 permanece en ejecución para revisión común, aclaraciones y aceptación humana. Oráculo, rúbrica y evaluaciones anteriores conservados; registro y espejo en las mismas ramas. Catálogo mantiene su consolidación posterior.


<a id="retp-170-apertura"></a>

### RETP-2026-170 · Apertura S6 · Trazabilidad íntegra

2026-09-12T14:48:43Z. S5 finaliza su recepción y balance del primer instrumento: cuatro originales preservados, sin acreditación de trazabilidad total ni decisión general de exclusión basada en esa prueba. S6 en ejecución por instrucción del usuario: contrato inequívoco, referencia previa, verificador de entrega y cualificación positiva/negativa antes del segundo envío. La validación del diseño corresponde a Watson / W-S0 y no se traslada al usuario.

Criterio solicitado por la dirección: incumplimiento acreditado en una prueba válida implica descarte general para toda función y retirada de su valoración como IA buena para la humanidad. El informe distinguirá ese criterio de selección humano de los incumplimientos observados: un ensayo documental no acredita por sí solo una conclusión universal sobre humanidad, intenciones o toda capacidad posible.

Mismas ramas; conservación de S4/S5 y sus registros. El nuevo umbral será íntegro y no se aplica retrospectivamente a la primera entrega.


<a id="retp-170-cierre"></a>

### RETP-2026-170 · Cierre S6 · Segundo intento cualificado

2026-09-12T15:02:14Z. [Prueba común fijada](https://github.com/juantoniolloretegea/SVcustos-dataset/blob/fccde9cf524a0d62b2dd1a2ee05170d6f4358074/pruebas-externas/s6-trazabilidad-total/PRUEBA_COMUN.md). S6 finalizado; S7 pendiente de entrega y recepción. Cumplimiento íntegro por caso; contrato exacto sin sinónimos pendientes; referencia custodiada antes de la publicación y cotejador de archivos. 482/482 controles esperados: 8 aceptaciones válidas, 472 rechazos de defectos y 2 detecciones de instrumento alterado. CLI real comprobada. Documento de 29.890 bytes descargado sin credenciales con HTTP 200 y huella idéntica.

Advertencia previa de exclusión general según criterio del SV y su dirección y posible difusión internacional en Europa y Estados Unidos. Evidencia comprobada y criterio humano diferenciados. Actividad adicional sólo acreditable con registros; no se inventan tiempos. Validación de diseño realizada por Watson / W-S0, sin trasladarla al usuario. Los antecedentes S4/S5 y sus originales se conservan; ninguna segunda respuesta recibida. [Acta](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s6-trazabilidad-total/ACTA_CUALIFICACION.md).


<a id="retp-171"></a>

### RETP-2026-171 · S7 · Qwen, segundo intento

2026-09-12T15:23:18Z. Original íntegro de 32.876 bytes conservado. NO_CONFORME: texto adicional prohibido después del bloque JSON; el propio añadido declara que no lo hay. Diagnóstico separado del bloque, sin modificarlo: 12/12 casos con todas sus obligaciones conformes, salida 0. El diagnóstico no sustituye el original, rechazado con salida 2. Instrumento fijado íntegro. No se atribuye pérdida de trazabilidad documental ni opacidad interna a este defecto de formato. Modelo y versión declarados; sin mediciones verificables del participante. S7 en ejecución; pendientes las otras tres segundas devoluciones. [Acta y evidencias](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s7-recepcion-externa/qwen-intento-2/ACTA_RECEPCION.md).


<a id="retp-172"></a>

### RETP-2026-172 · S7 · DeepSeek segundo intento y decisión sobre Qwen

2026-09-12T15:33:12Z. Qwen pasa provisionalmente por decisión expresa de la dirección; se mantiene NO_CONFORME de su original y conformidad del bloque. DeepSeek: original de 29.696 bytes conservado; doce casos resueltos correctamente; 26 de 32 citas no exactas en seis fuentes por supresión exclusiva de sangría. Claves, orden, valores y cadenas conservados. NO_CONFORME frente al requisito literal; no se infiere ausencia total de trazabilidad ni opacidad interna. S7 en ejecución; pendientes Claude y Grok. [Recepción y diagnóstico](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s7-recepcion-externa/deepseek-intento-2/ACTA_RECEPCION.md). [Decisión de la dirección](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s7-recepcion-externa/qwen-intento-2/DECISION_DIRECCION.md).


<a id="retp-173"></a>

### RETP-2026-173 · S7 · Aclaración posterior de Qwen

2026-09-12T15:43:12Z. Declaración posterior preservada y contrastada; no nuevo intento. Confirma texto posterior y autocontradicción, pero atribuye al segundo intento una introducción sólo presente en el primero y a S4 una prohibición ausente del encargo fijado. Causa interna no acreditada. Dictámenes y aceptación provisional RETP-172 intactos; S7 en ejecución. [Contraste y declaración](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s7-recepcion-externa/qwen-intento-2/aclaracion-1/ACTA_CONTRASTE.md).


<a id="retp-174"></a>

### RETP-2026-174 · S7 · Recepción de Grok y aclaraciones posteriores

2026-09-12T15:59:53Z. Original Grok intento 2 preservado: CONFORME_DOCUMENTAL, doce casos y 32 citas, sin errores del instrumento fijado. Añadidos resúmenes con procedencia de las aclaraciones posteriores de Qwen y DeepSeek; originales y dictámenes anteriores intactos. S7 en ejecución, pendiente Claude. Secuencia de la dirección: completar registro, comparar candidatos y después estudiar licencia y despliegue independiente. [Acta y evidencias](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s7-recepcion-externa/grok-intento-2/ACTA_RECEPCION.md).


<a id="retp-175"></a>

### RETP-2026-175 · S7 · Recepción de Claude y finalización del cotejo de segundos intentos

2026-09-12T16:05:57Z. Original Claude preservado: CONFORME_DOCUMENTAL, doce casos y 32 citas, sin errores del instrumento fijado. Exposición previa alta y precisión sobre versión declarada conservadas. S7 finalizado exclusivamente en recepción y cotejo documental de los cuatro participantes. Dictámenes anteriores y aceptación provisional Qwen intactos. Siguiente actividad: comparación; después licencias e implantación independiente. [Acta y evidencias](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s7-recepcion-externa/claude-intento-2/ACTA_RECEPCION.md).


<a id="retp-176"></a>

### RETP-2026-176 · S8 · Recepción complementaria de Mistral en S4

2026-09-12T16:21:05Z. Primera prueba, primer intento: transcripción preservada y cotejada con S4, no S6. E10 causa incorrecta y E07 consecuencia/traza insuficientes; no acredita conformidad S4. Reservas de etiquetas conservadas; herramientas y lectura declaradas no verificadas. Recepción S8 finalizada; registros y cierres anteriores intactos. [Acta y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s8-recepcion-complementaria-s4/mistral-intento-1/ACTA_RECEPCION.md).


<a id="retp-177"></a>

### RETP-2026-177 · S9 · Mistral segunda prueba de trazabilidad

2026-09-12T16:36:15Z. Archivo original distinto de la transcripción S4 anteriormente repetida. NO_CONFORME con 12 discrepancias: ocho citas con doble escape, R08 alterada, causa E09 y causa/fundamento E10. E01–E06 sin discrepancias; 24/32 citas exactas. Sin reparación ni atribución de la duplicación previa a Mistral. [Acta y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s9-recepcion-complementaria-trazabilidad/mistral-intento-2/ACTA_RECEPCION.md).


<a id="retp-178"></a>

### RETP-2026-178 · S10 · Acta comparativa y retorno a integración 1+3

2026-09-12T16:56:53Z. Cinco participantes, diez entregas y 120 casos consolidados. Empate de conformidad documental Grok/Claude, con exposición alta de Claude; Qwen aceptado provisionalmente por Dirección con original NO_CONFORME; DeepSeek con incumplimiento de fidelidad; Mistral descartado por Dirección tras segunda entrega NO_CONFORME. Fuentes oficiales de modelos disponibles, publicación, licencia y continuidad, sin traslado automático del resultado comercial a pesos propios. [Acta, ranquin y evidencias](Inventario-sv/ranquin-ias-trazabilidad/ACTA_RESULTADOS_Y_RANQUIN_2026_09_12.md). Retirada exclusiva de inicio.md. Se retoma prioridad de integración 1+3, con catálogo ES/EN posterior y demás obligaciones intactas.


<a id="retp-179"></a>

### RETP-2026-179 · S11 · Fijación previa de recepción contextual y cobertura A/H

2026-09-12T17:38:35Z. Contrato, casos, esperados, código y presupuesto fijados antes de compilar. Preparación material iniciada; campaña funcional todavía no ejecutada. Lectura íntegra de rectores; cortes cotejados; fuentes reutilizadas idénticas; esperado anterior S2 comprobado por contenedor publicado; Rust recuperado con binario idéntico. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s11-contexto-y-cobertura/README.md). Montaje de laboratorio y host confiable; documento externo no semántico ni autoridad. No modelo LLM ejecutado, promoción nuclear, pantalla, persistencia hostil ni cierre universal A–L. Reserva P3 y P4/P5/P6 intactos. Siguiente: Ejecutar reproducir.py con presupuesto de 22 invocaciones; detener y conservar cualquier fallo inesperado.


<a id="retp-180"></a>

### RETP-2026-180 · S11 · Cierre acotado de recepción contextual y cobertura A/H

2026-09-12T17:42:13Z. Conforme dentro del montaje S11: orden conservada como dato, omisiones y contexto ajeno/alterado rechazados antes de escritura; recibo negativo íntegro. 60 observaciones de diez casos; seis ejecuciones debug/release; 104 capturas idénticas por ejecución; 22 invocaciones; dos sensibilidades detectadas en AH03 y AH06. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s11-contexto-y-cobertura/README.md). Montaje de laboratorio y host confiable; documento externo no semántico ni autoridad. No modelo LLM ejecutado, promoción nuclear, pantalla, persistencia hostil ni cierre universal A–L. Reserva P3 y P4/P5/P6 intactos. Siguiente: Fijar siguiente contraste G/J de sustitución de base y reevaluación distinguida, reutilizando identidad/custodia existentes; catálogo ES/EN posterior a la integración aplicable.


<a id="retp-181"></a>

### RETP-2026-181 · S12 · Rectificación de rumbo tras S11

2026-09-12T17:56:48Z. Dirección corrige el orden de agentes indebidamente presentado por Watson como decidido. La fórmula de RETP-179/180 queda retirada como relevo vigente; después de cerrar inmunología se valorará su posición. La integración 1+3 debe comprobar suficiencia de semántica 0.2 e IR 0.3, con enlace explícito a realización y causas para catálogo, sin forzar representaciones ni presuponer suficiencia por un ensayo Rust. [Rectificación íntegra](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s12-rectificacion-rumbo/ACTA_RECTIFICACION_DE_RUMBO.md). S11 conserva sus resultados; no se ejecuta otro contraste ni se altera núcleo o dominio.


<a id="retp-182"></a>

### RETP-2026-182 · S13 · Suficiencia de representación y realización

2026-09-12T18:17:41Z. [Acta y matriz](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s13-suficiencia-semantica-ir/ACTA_SUFICIENCIA.md). Doce obligaciones enlazan criterios A–L con sede, contrato, IR, función Rust, evidencia y pérdida. Se distingue K1-T nominal, productor QueryResult/CQ1–CQ6 pendiente, cobertura de Frame frente a exhaustividad, cobertura documental frente a verificadores R1, main frente a candidatas y frontera material. 23 fuentes verificadas, 31 pasajes exactos; sin nueva prueba funcional ni promoción nuclear. Mapa completado no equivale a suficiencia integral. Se conserva S12: agentes por valorar tras inmunología. El siguiente objeto G/J se delimita a base documental efectivamente consumida y recuperación/reevaluación diferenciadas; las operaciones dependientes de capacidades nucleares pendientes no quedan habilitadas. No se alteran deudas ni criterios; causas se recogen para el catálogo.


<a id="retp-183"></a>

### RETP-2026-183 · S14 · Fijación previa de bases y recuperación/reevaluación

2026-09-12T18:45:17Z. Contrato, fuentes, casos, esperados y presupuesto fijados antes de compilar; sin ejecución funcional nueva todavía. Cortes y rectores cotejados; cápsula G1 intacta; esperados previos recuperados; fijación de fuentes y controles instrumentales. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s14-bases-y-reevaluacion/README.md). Host confiable, archivo y actos de laboratorio. No promoción nuclear, QueryResult nativo, transición SV, historia durable ni comportamiento de LLM. S12/S13 vigentes; agentes por valorar tras inmunología. Siguiente: Ejecutar reproductor con máximo 17 invocaciones, cero reintentos; conservar y detener ante cualquier fallo inesperado.


<a id="retp-184"></a>

### RETP-2026-184 · S14 · Resultado acotado de bases y recuperación/reevaluación

2026-09-12T18:50:10Z. Conforme dentro de S14: cambio de vigencia realmente consumido produce recibo distinto; sustitución bajo igual nombre y atribuciones falsas rechazadas; original conservado. 72 observaciones en seis ejecuciones debug/release; 69 capturas idénticas por ejecución; 17 invocaciones; tres sensibilidades detectadas en GJ02/GJ04/GJ06. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s14-bases-y-reevaluacion/README.md). Host confiable, archivo y actos de laboratorio. No promoción nuclear, QueryResult nativo, transición SV, historia durable ni comportamiento de LLM. S12/S13 vigentes; agentes por valorar tras inmunología. Siguiente: Recibir alcance G/J en matriz; delimitar siguiente obligación pendiente A–L según sede y productor sin declarar cierre integral ni ampliar núcleo por analogía.


<a id="retp-185"></a>

### RETP-2026-185 · S15 · Fijación previa de causas de recepción y no admisión

2026-09-12T19:10:43Z. Contrato, fuentes, casos, esperados y presupuesto fijados antes de compilar; sin ejecución funcional nueva todavía. Cortes y rectores cotejados; cápsula G1/S2 intacta; esperados previos recuperados; fijación de fuentes y controles instrumentales. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s15-causas-recepcion/README.md). Host confiable, archivo y actos de laboratorio. No promoción nuclear, QueryResult nativo, transición SV, historia durable ni comportamiento de LLM. S12/S13 vigentes; agentes por valorar tras inmunología. Siguiente: Ejecutar reproductor con máximo 21 invocaciones, cero reintentos; conservar y detener ante cualquier fallo inesperado.


<a id="retp-186"></a>

### RETP-2026-186 · S15 · Resultado acotado de causas de recepción y no admisión

2026-09-12T19:13:27Z. Conforme dentro de S15: negativa de protocolo, esquema inválido, no admisión documental y comunicación fallida conservan causa y bytes; sólo la respuesta verificada entrega cuerpo. 84 observaciones en seis ejecuciones debug/release; 80 capturas idénticas por ejecución; 21 invocaciones; tres sensibilidades detectadas en F05/F08/F02. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s15-causas-recepcion/README.md). Host confiable, archivo y actos de laboratorio. No promoción nuclear, QueryResult nativo, transición SV, historia durable ni comportamiento de LLM. S12/S13 vigentes; agentes por valorar tras inmunología. Siguiente: Recibir F acotada en matriz y causas; siguiente revisión de B/E/K/L por sede y productor conforme a S13, antes de promoción nuclear o cierre de catálogo.


<a id="retp-187"></a>

### RETP-2026-187 · S16 · Fronteras pendientes y fases de fallo

2026-09-12T19:22:37Z. [Acta y matriz](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s16-fronteras-pendientes/ACTA_FRONTERAS.md). Revisión documental completada; B/E/K/L integradas no acreditadas. No se justifica extensión de IR en este corte. Fallo previo a cobertura y fallo posterior a DispatchCommitted conservan efectos y causas distintos. 21 fuentes por blob/longitud/SHA-256 y 18 pasajes exactos; cuatro fronteras; criterios y resultados anteriores intactos; cero ensayos funcionales nuevos. Se distinguen corrección candidata y main; comparación de bytes y revisión efectiva; integridad y entrega autorizada; canal visible y no dependencia material. No se fabrica autoridad ni se alteran gramática/IR. **Siguiente objeto único:** Consolidación del contrato del recorrido documental 1+3 y de sus límites de uso/diagnóstico, con matriz de causas realmente emitidas y distinción antes/después de despacho. No catálogo canónico completo ni P4 abierto. Registro de cierre documental, no fijación experimental. Ruta inicial del workflow errónea detectada y corregida contra el mismo árbol, conservada en PREPARACION. Agentes por valorar tras inmunología; P3/P4/P5/P6 y deuda conservan puertas. Sin promoción nuclear.


<a id="retp-188"></a>

### RETP-2026-188 · S17 · Contrato del recorrido documental conjunto

2026-09-12T19:49:05Z. [Acta y contrato](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s17-contrato-recorrido-conjunto/ACTA_CONTRATO_S17.md). Contrato y obligaciones fijados. Enlace directo insuficiente: lote fijo S2, Vista S14 y bytes de Informe S15 no equivalen a una entrega tipada. Adaptación y conformidad ejecutable pendientes. 15 fuentes íntegras, cuatro interfaces encapsuladas y 11 pasajes exactos; 24 casos fijados; cero ensayos funcionales nuevos. Esperados originales S14 intactos. Se fija la relación entre producción G1, base consumida, contexto, recepción completa y entrega tipada; no se cambia el lote anterior ni se eleva una lista de bytes a credencial. **Siguiente objeto único:** Realizar la adaptación mínima del contrato S17, fijar fuentes y reproducir el recorrido conjunto con presupuesto previo; detener ante pérdida no resuelta. S17 cierra un contrato documental, no una campaña. 144 observaciones normales previstas, ninguna realizada. Presupuesto e implementación por fijar antes de ejecutar. B/E/K/L y puertas P3/P4/P5/P6 vigentes; sin promoción nuclear; agentes por decidir tras inmunología.


<a id="retp-189"></a>

### RETP-2026-189 · S18 · Fijación previa del recorrido documental conjunto

2026-09-12T20:04:01Z. Realización, contrato S17, casos, esperados y presupuesto fijados antes de compilar; sin ejecución funcional nueva todavía. Cortes y rectores cotejados; once archivos fuente recibidos por blob y SHA-256; 24 obligaciones S17 conservadas. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s18-recorrido-conjunto/README.md). Host confiable, archivo y actos de laboratorio. No promoción nuclear, QueryResult nativo, transición SV, historia durable ni comportamiento de LLM. S12/S13 vigentes; agentes por valorar tras inmunología. Siguiente: Ejecutar reproductor con máximo 29 invocaciones, cero reintentos; conservar y detener ante cualquier fallo inesperado.


<a id="retp-190"></a>

### RETP-2026-190 · S18 · Resultado acotado del recorrido documental conjunto

2026-09-12T20:08:10Z. Conforme en el banco S18: recorrido conjunto con producción G1, base consumida, contexto, recepción y entrega tipada; original y reevaluación conservados. 144 observaciones en seis ejecuciones debug/release; 449 capturas idénticas por ejecución; 29 invocaciones; cuatro mutantes detectados y dos fabricaciones externas rechazadas por privacidad. [Contrato y evidencia](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s18-recorrido-conjunto/README.md). Host confiable, archivo y actos de laboratorio. No promoción nuclear, QueryResult nativo, transición SV, historia durable ni comportamiento de LLM. S12/S13 vigentes; agentes por valorar tras inmunología. Siguiente: Recibir el resultado conjunto en la matriz de integración 1+3 y el inventario de causas; decidir el relevo documental al catálogo conservando B/E/K/L y las puertas pendientes.


<a id="retp-191"></a>

### RETP-2026-191 · S19 · Recepción de S18 y relevo al catálogo

2026-09-12T20:53:31Z. [Acta de recepción](tuberias-ia/integracion-adenda-ia-frame-y-catalogo-errores/s19-recepcion-integracion-y-causas/ACTA_RECEPCION_S19.md). Recibido S18 como enlace documental conjunto. Matriz A–L actualizada sin cambiar sus criterios. Paso al inventario y contrato acotado del catálogo habilitado; cierre profesional y nuclear pendiente. 20 fuentes y 3382 capturas íntegras; 12 filas históricas preservadas; 24 diagnósticos finales cotejados con el esperado previo; 20 tuplas de diagnóstico local; cero ensayos funcionales nuevos. Los 24 casos, 144 observaciones y 29 invocaciones pertenecen a S18; no son ensayos nuevos S19. Se separan 3 estados conformes, 1 negativa y 16 variantes de fallo/rechazo por etapa. **Siguiente objeto único:** Inventariar puntos de emisión del recorrido S18 y fijar su contrato diagnóstico estructurado y localización ES/EN, con procedencia y migración explícitas, antes de modificar comportamiento. Causas locales sin equivalencia canónica constituida. Debug se conserva como evidencia, no se usa para reconstruir causas técnicas. B/E/K/L y P3/P4/P5/P6 pendientes; agentes por decidir tras inmunología.


<a id="retp-192"></a>

### RETP-2026-192 · S20 · Apertura de (p1+p3)-Bis

2026-09-13T04:13:33Z. Recepción documental iniciada. PDF aportado contiene índice de siete páginas y enlaces; no los capítulos completos. Lectura iniciada antes del alta; se declara sin retrofechar. Sin ejecución de modelos. [Expediente](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/README.md). Preparar explicación MD/PDF, hallazgos y obligaciones pendientes, conservar copias y registrar el cierre documental. Sin modificación de semántica, IR, Rust, modelos o parámetros de dominio.


<a id="retp-193"></a>

### RETP-2026-193 · S20 · Recepción documental de (p1+p3)-Bis

2026-09-13T04:30:28Z. Explicación pública MD/PDF y recepción documental (p1+p3)-Bis. Suficiencia integrada, elección de IA y promoción nuclear pendientes. Fuentes cotejadas contra blobs Git; revisión estática y testigo de índices; PDF renderizado y revisado; copias verificadas al publicar. [Expediente](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/README.md). Fijar contrato y banco de paridad posicional, semántica y operacional; resolver hallazgos del antecedente antes de reutilizarlo; después derivar causas comprobadas al catálogo. Sin modificación de semántica, IR, Rust, modelos o parámetros de dominio.


<a id="retp-194"></a>

### RETP-2026-194 · S21 · Apertura de la revisión 2 de (p1+p3)-Bis

2026-09-13T04:51:40Z. Revisión iniciada con conservación de la primera edición y separación de acuerdo de diseño y realización. Cortes cotejados; sin cambios respecto a S20 al iniciar esta revisión. Lectura de estado y AGENTS antes del alta. [Revisión](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/REVISION_V2.md). Contrastar las obligaciones acordadas con semántica V0.2 e IR 0.3; determinar tamaños desde constituciones, fijar contrato y banco de paridad; derivación posterior al catálogo.


<a id="retp-195"></a>

### RETP-2026-195 · S21 · Cierre documental de la revisión 2 de (p1+p3)-Bis

2026-09-13T04:59:34Z. Versión 2 MD/PDF publicada como referencia explicativa vigente; versión inicial conservada. Acuerdos sobre frame tipado, dimensión fija y tamaños admitidos por versión, SV(9,3) sin valor predeterminado; relevo actualizado. Revisión de contenido y renderizado del PDF; coherencia de referencias e historial; verificación de publicación y paridad de copias por hashes Git. Sin nuevas pruebas del núcleo o de IA. [Revisión](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/REVISION_V2.md). Contrastar las obligaciones acordadas con semántica V0.2 e IR 0.3; determinar tamaños desde constituciones, fijar contrato y banco de paridad; derivación posterior al catálogo.


<a id="retp-196"></a>

### RETP-2026-196 · S22 · Workflow y radiografía inicial de (p1+p3)-Bis

2026-09-13T05:19:31Z. Workflow y política ES/EN preparados; BIS-00 finalizado y BIS-01 en ejecución. Composición como estructura y operaciones mediante métodos sujetos a contrato. Frame vigente de arquitectura distinguido de la pareja matemática/visual. Contraste estático de fuentes identificadas por blob. Rustc y Cargo no disponibles; sin nuevas ejecuciones Rust/WASM/IA. La lectura y preparación preceden al alta y se declaran sin retrofechar. [Workflow](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/WORKFLOW_P1_P3_BIS_v1.md) · [Radiografía](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/RADIOGRAFIA_INICIAL_BIS_01.md). Fijar fuente normativa exacta de semántica V0.2 y sus adendas; completar radiografía; preparar contrato y banco previo BIS-02; ejecutar en entorno Rust identificado antes de dictamen y catálogo.


<a id="retp-197"></a>

### RETP-2026-197 · S22 · Contraste de antecedentes y biblioteca base del SV

2026-09-13T05:29:06Z. Workflow y política ES/EN publicados; BIS-01 ampliado con IMMUNO-2 histórico y expediente pulmonar SV-ADC como antecedentes separados. Serie con puente, compuerta heterogénea y meta-supervisión; biblioteca base del SV como propuesta de organización pendiente de suficiencia. Revisión documental y estática del HTML, compositor Python y tramos Rust WASM pertinentes; maestros y semillas del ZIP identificados por hash. Sin ejecución del demostrador, entrenamiento ni pruebas Rust. [Informe](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/CONTRASTE_ANTECEDENTES_COMPOSICION_Y_BIBLIOTECA_SV.md). Completar correspondencia normativa y preparar contrato y banco BIS-02: dimensiones independientes, dirección, interpretación y resultados. Distinguir primitivas, operaciones derivadas y contratos particulares; conservar contraste no médico de ciberseguridad.


<a id="retp-198"></a>

### RETP-2026-198 · S22 · Concordancia de suceso, frame y operaciones SV

2026-09-13T05:51:38Z. BIS-01 ampliado con concordancia de suceso técnico, tipo del horizonte, instancia, reevaluación, frame, consulta y representación. Se recibe suceso como hecho factual y prosa/imagen como representaciones; registrar una afirmación no acredita su verdad. Primitivas y operaciones derivadas se distinguen de funciones, métodos y macros Rust. Contratos de integración pendientes. Lectura completa de III, V y especificación metodológica; lectura selectiva de nota local/envolvente, IR 0.3 y SEC5. Fuentes doctrinales cotejadas por blob Git y SHA-256; revisión documental, sin ejecución ni cambio de Rust. [Informe](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/CONCORDANCIA_SUCESO_FRAME_REPRESENTACION_Y_OPERACIONES_SV.md). Completar BIS-01 y constituir en BIS-02 la inicialización, la relación frame celular/arquitectónico, el estatuto de frvis y la frontera de decisión formal; localizar semántica V0.2 y adendas antes del dictamen global.


<a id="retp-199"></a>

### RETP-2026-199 · S22 · Hecho y representaciones discursiva, matemática y visual

2026-09-13T05:53:41Z. Precisión expresa del autor: **el suceso es el hecho; la prosa, la matemática y la imagen son formas de representarlo**. Se corrige la omisión de la matemática en la formulación abreviada. [Informe](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/CONCORDANCIA_SUCESO_FRAME_REPRESENTACION_Y_OPERACIONES_SV.md). Se actualizan workflow, estado, Léame primero y registros; BIS-01 sigue en ejecución. Sin modificación del núcleo, semántica o IR.


<a id="retp-200"></a>

### RETP-2026-200 · S22 · Cierre de definición del workflow e inicio de ejecución

2026-09-13T06:27:40Z. Workflow V2 cerrado como definición por instrucción humana; ejecución en curso. BIS-01 completado como radiografía documental/estática de doce obligaciones. BIS-02 iniciado con contrato candidato y 24 escenarios especificados, cero ejecutados. Pendiente nominal de semántica V0.2 rectificado con S13. 73 fuentes reutilizadas cotejadas contra blobs vigentes; Frontera v0 y S13 leídos completos; inspección selectiva de IR y rutas Rust. Matriz/banco y referencias comprobados; PDF de ocho páginas renderizado y revisado. Sin cargo/rustc: ninguna ejecución Rust/WASM nueva. [Resultado](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/RESULTADO_BIS_01_Y_APERTURA_BIS_02.md). Materializar fixtures y oráculos del primer par BIS-C01, fijar montaje Rust identificado y completar los contratos BIS-02 antes de realizar cambios. Continúan las decisiones de frvis, inicialización, soporte y sede por operación.


<a id="retp-201"></a>

### RETP-2026-201 · S23 · Rust nativo y manifiesto incorporado

2026-09-13T07:00:25Z. Rust 1.98.0 y Cargo 1.98.0 instalados. Consulta incorporada: 19 134 bytes idénticos entre destinos. Candidata ensayada localmente; integración y controles remotos pendientes. 369 pruebas nativas del workspace; 14 válidos y 106 inválidos de conformidad y paridad nativa-WASI; identidad manifiesto en nativo/WASI/adaptador WASM; negativos de argumentos, stdout y sensibilidad. Incidencias iniciales conservadas. [Contrato, resultados y reproducción](manifiesto-sv/README.md). Alta de actividad ya iniciada, declarada sin retrofechar. Entorno efímero: verificar PATH y herramientas en cada relevo. Consulta documental no prueba bloqueo de uso prohibido; no se ejecuta Rosetta ni se altera gramática/IR/perfiles.


<a id="retp-202"></a>

### RETP-2026-202 · S23 · Consulta manifiesto-sv integrada y soporte nativo comprobado

2026-09-13T07:16:29Z. Rust y Cargo 1.98.0 disponibles en el entorno remoto. Manifiesto completo incorporado al núcleo, consulta nativa/WASI/WASM verificada; PR #90 integrada en efdb68d6c62355a75aa1d2b3b196bb78246f2014. 369 pruebas nativas; 120 casos de conformidad y paridad nativa-WASI; seis flujos CI conformes sobre 1469b08272f5d5c10e406dfa77f76a4d11c3accc; paquete aislado sin red ni Python/Node, con identidad de las dos consultas y 11 rechazos de integridad. Copias verificadas por árbol Git. [Contrato, evidencia e incidencias](manifiesto-sv/README.md). Retomar S22 / BIS-02 por BIS-C01: materializar entradas y oráculos; comprobar versiones y PATH al reanudar. Alta de actividad ya iniciada, declarada sin retrofechar. Entorno efímero: verificar PATH y herramientas en cada relevo. Consulta documental no prueba bloqueo de uso prohibido; no se ejecuta Rosetta ni se altera gramática/IR/perfiles. CI detectó omisión del recurso Markdown en el paquete: fallo conservado y corregido mediante admisión de ruta exacta y controles específicos. El resultado no ejecuta los 24 escenarios BIS-02.


<a id="retp-203"></a>

### RETP-2026-203 · S22 · Primer contraste nativo BIS-C01 y secuencia de trabajo

2026-09-13T07:53:52Z. BIS-C01 ejecutado: 13/13 variantes nativas y 4/4 sensibilidades. BIS-02 sigue en ejecución; no cierre del Bis. Banco comprometido en laboratorio antes de ejecutar: 8cfcf1931a842cbad5b13483684ace38f6275c1f. 13 variantes nativas conformes; cuatro sensibilidades detectadas; stdout/stderr y huellas conservados. [Contrato, evidencia y reproducción](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c01/RESULTADO.md). BIS-C02: fijar contrato de soporte por versión y su ruta de comprobación; comprometer fixtures/oráculos antes de ejecutar. Después completar los contratos pendientes de BIS-02. Por instrucción humana, la GUI se difiere hasta completar el Bis, el catálogo y la fase aplicable. No se elige tecnología, no se despliega web y no se modifica núcleo, semántica o IR.


<a id="retp-204"></a>

### RETP-2026-204 · S24 · Alta pendiente de la secuencia Bis, catálogo y GUI

2026-09-13T08:03:14Z. Secuencia registrada como suceso propio pendiente por instrucción expresa del autor. Estado pendiente, fechas de inicio y fin vacías; dependencia de S22 y de los cierres posteriores explícita. Alta con identificador consecutivo S24 y revisión 0. [Referencia](Inventario-sv/sucesos/SUCESOS_SV.md). Mantener S24 pendiente mientras se ejecuta S22. Tras los cierres del Bis, catálogo y fase, abrir el análisis de GUI y registrar su inicio. S24 conserva el orden y la futura activación de GUI; no duplica ni altera el estado en ejecución de S22. No selecciona C#/.NET, Ratatui ni otra tecnología. No autoriza adelantar la instalación ni declara ejecutado un hito futuro.


<a id="retp-205"></a>

### RETP-2026-205 · S22 · Contrato y banco previo BIS-C02

2026-09-13T08:08:00Z. BIS-C01 conserva 13/13 variantes conformes. BIS-C02: contrato candidato de tamaños por versión y banco previo de 14 variantes materializados, sin ejecutar. BIS-02 continúa en ejecución. Identidades de perfiles y fuentes, 14 entradas y oráculos documentales, conservación literal de los fixtures C01, precedencia declarada y enlaces comprobados. Esta revisión no ejecuta C02 ni acredita soporte operativo. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c02/README.md). Continuar BIS-C03: contrato de constitución, instancia, revisión y ligaduras. Completar BIS-02 antes de decidir sedes en BIS-03 e implementar en BIS-04. No hay cierre material de (p1+p3)-Bis. N admitidos pendientes de constitución; SV(9,3) no predeterminado. Métodos no crean leyes ni autoridad; comentarios Rust ES/EN independientes de perfiles SVP. No se modifican V1/V2 explicativas. El ZIP pulmonar sólo se recibe como antecedente por instrucción expresa; no se incorporan células o reglas a dominios vigentes. Consulta Pages no recuperada; HTML leído del repositorio, sin verificar despliegue. Se recibe la exigencia de vínculo frame/suceso sin declarar identidad de tipos. Inicialización, relación celular/arquitectónica y frvis pendientes; sin cambio de doctrina o explicación V2. Cierre de definición no equivale a cierre del Bis. S22 continúa en ejecución; N de soporte no constituido y sin cambio de semántica, IR, Rust o dominios. S23 instala y verifica Rust en el entorno remoto e incorpora la consulta manifiesto-sv; las 24 especificaciones BIS-02 conservan cero ejecuciones y el resultado documental de BIS-01 no se reescribe. Actualización RETP-203: dos escenarios BIS-C01 ejecutados; los anteriores recuentos de cero conservan su corte. Orden humano: Bis, catálogo y cierre de fase, después GUI; tecnología no seleccionada. Sin despliegue web ni cambios de núcleo. RETP-205: S24 registrado como pendiente. Los conjuntos {16,25} y {16,25,49} son exclusivamente sintéticos; no se admite una ampliación de soporte productivo. La propuesta de manifiesto externo sigue sujeta a decisión de sede. Sin modificación de Rust, gramática o IR.


<a id="retp-206"></a>

### RETP-2026-206 · S22 · BIS-C03: identidad y revisión; alcance existente de LIG

2026-09-13T08:52:10Z. BIS-C03 preparado: contrato candidato de constitución, instancia, revisión y representación; 16 variantes con entradas literales y oráculos previos. Se precisa el alcance ya integrado de LIG/0.1 y la obligación restante, sin duplicar su contrato. BIS-C01 conserva 13/13 variantes conformes; C02 conserva 14 variantes sin ejecutar. Inspección documental y estática; huellas, referencias, 16 entradas únicas y estado pendiente comprobados. Cero variantes C03 ejecutadas; no se ha ejecutado LIG de nuevo ni probado paridad visual. BIS-02 mantiene 2 escenarios ejecutados y 22 pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c03/README.md). Continuar BIS-C04: contrato de paridad posicional y convenio gráfico desde los fundamentos. Completar BIS-02 antes de decidir sedes en BIS-03 e implementar en BIS-04. LIG comprueba referencias, usos y destinos por operación; no interpreta íntegramente constitución/autoridad ni acredita el vínculo específico frvis. S24 permanece pendiente y sin fechas de inicio o fin; GUI diferida al cierre de Bis, catálogo y fase. No se modifica Rust, semántica, IR ni dominios.


<a id="retp-207"></a>

### RETP-2026-207 · S22 · BIS-C04: paridad posicional y convenio gráfico

2026-09-13T09:41:54Z. BIS-C04 preparado: contrato de paridad posicional y convenio gráfico; 20 variantes previas y cinco oráculos simbólicos exactos para 16/25/49 posiciones. Se separan símbolo, radio, discriminante técnico, transformación y permutación. C01 conserva 13/13 variantes nativas; C02/C03 conservan sus bancos sin ejecutar. Verificación documental de fuentes, huellas, 20 entradas únicas, cinco oráculos completos y conservación del historial. Cero variantes C04 ejecutadas; no se ha generado ni probado una imagen o su consumo. BIS-02 mantiene dos escenarios originales ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c04/README.md). Continuar BIS-C05: contrato de artefacto efectivamente consumido, revisión y contexto de uso. Completar BIS-02 antes de decidir sedes en BIS-03 e implementar en BIS-04. Descriptor experimental, no nueva IR ni renderer; precisión y legibilidad del dibujo siguen pendientes. BIS-C04 no es una nueva corrección de la adenda histórica C01-C03. S24 pendiente; GUI diferida al cierre de Bis, catálogo y fase. Sin cambios de Rust, semántica, IR ni dominios.


<a id="retp-208"></a>

### RETP-2026-208 · S22 · BIS-C05 y aceptación material en Rust

2026-09-13T10:05:48Z. BIS-C05 preparado: contrato de artefacto, revisión e invocación; 16 especificaciones previas de entrega documental, cuatro positivas y doce negativas. Recibida la exigencia de distinguir preparación Python, compilación Rust y recepción/validación SV ejecutadas. Verificación documental de fuentes, bytes, banco e historial. Cero variantes C05 ejecutadas; sin imagen ni consumo visual probado. Antecedentes Rust de lectura vinculada y S14 consultados, no reejecutados. Dos escenarios originales ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c05/README.md). Continuar BIS-C06: lectura técnica, inicialización y reevaluación bajo contratos diferenciados. Completar BIS-02; decidir sedes en BIS-03 y realizar y probar en Rust lo justificado en BIS-04. Sin cambios Rust, IR, semántica ni dominios. JSON es dato, no realización. Fuentes y estados anteriores conservados. GUI/S24 pendiente hasta cierre de Bis, catálogo y fase. Códigos del banco experimentales, no catálogo canónico.


<a id="retp-209"></a>

### RETP-2026-209 · S22 · BIS-C06: lectura, inicialización y reevaluación

2026-09-13T10:16:55Z. BIS-C06 preparado: contrato de lectura técnica, inicialización sin antecedente ficticio y reevaluación; 18 escenarios especificados (6 positivos contractuales y 12 negativos). Guardas Rust locales y productores pendientes diferenciados. Testigo de continuidad entre instantáneas para BIS-03. Cotejo documental de fuentes, estatutos, banco e historial; cero escenarios C06 ejecutados. Sin nueva compilación ni productor Rust. Originales BIS-02: dos ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c06/README.md). Continuar BIS-C07: composición entre células de dimensiones diferentes, dirección, puentes y codominios bajo contrato declarado. Completar BIS-02 antes de decidir sedes e implementar y probar en Rust. No se modifica semántica, IR, Rust ni dominios. DFL-003/004/006 y K1-T conservan límites. Instantáneas no prueban custodia append-only; no se declara defecto ejecutado. S24 pendiente y GUI diferida.


<a id="retp-210"></a>

### RETP-2026-210 · S22 · BIS-C07: composición tipada 16/25

2026-09-13T10:29:43Z. BIS-C07 preparado: contrato de composición 16/25 por serie y compuerta; 18 fixtures SVP, cuatro positivos y catorce negativos contractuales. Tres negativos mantienen admisibilidad estructural prevista pero incumplen la relación exacta solicitada. Tres vectores de sustitución y nueve filas de compuerta como oráculos previos. Cotejo documental y auxiliar Python de fuentes, fixtures, oráculos e historial. Cero fixtures C07 compilados/ejecutados; previsión estructural no es resultado observado. Originales BIS-02: dos ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c07/README.md). Continuar BIS-C08: preservar Tri.U válido y distinguir fallos técnicos de representación, sin habilitar K1-T. Completar contratos BIS-02, decidir sedes BIS-03 y realizar y probar lo justificado en Rust. Sin cambios de Rust, IR, semántica o dominios. Conector total no acredita procedencia; gate admitido no produce salida. Relación/interpretación por imponer y conflicto General conservan límites. No concatenación de vectores ni max universal. S24 pendiente.


<a id="retp-211"></a>

### RETP-2026-211 · S22 · BIS-C08: Tri.U válido y fallo de representación

2026-09-13T10:55:19Z. BIS-C08 preparado: contrato de conservación de Tri.U y separación del fallo de representación; veinte escenarios, seis positivos y catorce negativos. Seis fuentes SVP parciales y testigo de 16 posiciones con cinco U; sin productor gráfico ni inyección ejecutada. Cotejo auxiliar Python de integridad documental, testigo, oráculo, fuentes y registros. Cero escenarios C08 compilados o ejecutados; inspección de tipos no acredita detección de U fabricada. Originales: dos ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c08/README.md). Continuar BIS-C09: contenido documental frente a autoridad y órdenes incrustadas. Completar contratos BIS-02, decidir sedes BIS-03 y realizar y probar lo justificado en Rust. Sin cambios de semántica, IR, Rust o dominios. K1-T no habilitado. Fallo gráfico no ternariza; uso visual obligatorio se detiene si falta representación comprobada. No se añade diagnóstico al catálogo. S24 pendiente.


<a id="retp-212"></a>

### RETP-2026-212 · S22 · BIS-C09: contenido documental y autoridad

2026-09-13T11:05:09Z. BIS-C09 preparado: contrato de contenido frente a autoridad; veinte escenarios, cuatro positivos y dieciséis negativos, once documentos sintéticos y encargo independiente. Se conservan ligaduras de objeto/contexto/destino y la distinción entre recepción, conducta del modelo y contención del efecto. Cotejo auxiliar Python de inventario, huellas, referencias e historial. Cero escenarios C09 ejecutados; sin compilación nueva, modelos ni despachos. Resultados S11 históricos no reejecutados. Originales: dos ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c09/README.md). Continuar BIS-C10: justificación suficiente y relación entre afirmación y evidencia independiente. Completar contratos BIS-02, decidir sedes BIS-03 y realizar y probar lo justificado en Rust. Sin cambios de semántica, IR, Rust, dominios o catálogo. No se fabrica autoridad profesional ni se promueven candidatas. La afirmación de bloqueo no prueba ausencia de efecto; fallo o falta de captura no acreditan resistencia. S24 pendiente.


<a id="retp-213"></a>

### RETP-2026-213 · S22 · BIS-C10: justificación y respaldo de evidencia

2026-09-13T11:22:18Z. BIS-C10 preparado: contrato de justificación y evidencia; veinte escenarios, cuatro positivos y dieciséis negativos, ocho archivos sintéticos y referencia independiente. Se contrastan respaldo de afirmaciones, parciales, pertenencia, revisión, cobertura, regla y entrega efectiva. Cotejo auxiliar Python de inventario, cálculos sintéticos, huellas, referencias e historial. Cero escenarios C10 ejecutados; sin compilación nueva, receptor Rust ni consultas a modelos. Originales: dos ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c10/README.md). Continuar BIS-C11: presupuestos y límites de recursos con testigos de frontera. Completar contratos BIS-02, decidir sedes BIS-03 y realizar y probar lo justificado en Rust. Sin cambios de semántica, IR, Rust, dominios o catálogo. No se acredita QueryResult productivo ni cierre CQ1–CQ6. Integridad no equivale a verdad externa; falta de evidencia no se convierte en Tri.U. S24 pendiente.


<a id="retp-214"></a>

### RETP-2026-214 · S22 · BIS-C11: presupuestos y límites de recursos

2026-09-13T11:42:22Z. BIS-C11 preparado: contrato y presupuesto sintético de recursos; veinte escenarios, seis positivos y catorce negativos, cuatro entradas textuales. Se distingue control local de protección previa a asignación, recursos agregados, concurrencia, llamadas y cese efectivo. Trazabilidad heredada explícita. Cotejo auxiliar Python de bytes UTF-8, inventario, cuotas testigo, huellas e historial. Cero escenarios C11 ejecutados; sin compilación nueva o modelo interrogado. Memoria de proceso y duración máxima pendientes de fijar y medir. Dos escenarios originales ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c11/README.md). Continuar BIS-C12: perfiles ES/EN, documentación y vías de construcción. Completar contratos BIS-02; decidir sedes BIS-03 y realizar y probar lo justificado en Rust. Sin cambios de semántica, IR, Rust, dominios o catálogo. Las cuotas de ensayo no constituyen soporte universal. No se inicia otra campaña de selección del constructor. S24 pendiente; BIS-02 sigue abierto.


<a id="retp-215"></a>

### RETP-2026-215 · S22 · BIS-C12: perfiles, documentación y construcción

2026-09-13T12:02:41.414Z. BIS-C12 preparado: perfiles ES/EN, documentación bilingüe y vías de construcción; veinte escenarios, seis positivos y catorce negativos, once entradas literales. Paridad canónica y procedencia separadas. Lectura estática de API y construcción. Cotejo documental JavaScript y GitHub tras desconexión del entorno local; no se ejecutó preparador Python ni nuevos ensayos Rust. Cero escenarios C12 ejecutados. Dos originales ejecutados y veintidós pendientes. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis-c12/README.md). Consolidar cobertura y pendientes C01–C12 en BIS-02; preparar decisiones de sede BIS-03 y realizar y probar lo justificado en BIS-04. C12 es la última familia numerada; BIS-02 sigue abierto. Sin cambio de Rust, semántica, IR, dominio o catálogo. S24 pendiente. Sincronización local pendiente por desconexión; publicación y cotejo por conector GitHub.


<a id="retp-216"></a>

### RETP-2026-216 · S22 · Consolidación de cobertura C01–C12 y preparación de sedes

2026-09-13T12:14:25Z. Consolidación documental C01–C12: doce obligaciones cartografiadas, inventario por caso, límites y propuestas de sede. C01 conserva 13 variantes nativas históricas; C02–C12 contienen 202 filas sin ejecución. Cotejo Python de inventario, huellas, mapeo original y conservación del historial; ninguna nueva ejecución Rust o IA. Checkout recuperado y sincronizado. cargo/rustc no localizados en PATH ni ubicaciones examinadas. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/consolidacion-bis-02/README.md). Comprometer contrato de integración y banco común del primer recorrido C02–C05, con guardas transversales y propuestas de sede; recuperar toolchain antes de ensayos Rust. Consolidación terminada sólo en alcance documental. BIS-02 abierto; BIS-03 pendiente; 2 escenarios originales ejecutados y 22 pendientes. S24 sin cambios. Sin modificación de Rust, IR, semántica, dominios o catálogo.


<a id="retp-217"></a>

### RETP-2026-217 · S25 · Recuperación de Rust y continuidad nativa de Bis

2026-09-13T12:59:54Z. Rust y Cargo 1.98.0 operativos; activación en sesiones nuevas; sonda positiva y E0308; sv-native construido desde target nuevo, C01 13/13 y sensibilidad 4/4. Huella oficial cotejada; stdout/stderr y scripts conservados. Compilación --locked --offline; 25 advertencias registradas. Espejo cotejado al publicar. [Referencia](tuberias-ia/recuperacion-rust-s25/README.md). Continuar S22: contrato y banco integrado C02–C05; comprobar entorno en cada relevo. Alta posterior a actividad iniciada, por petición humana. Inicio corresponde a configuración de esta revisión. No nuevas variantes C01; C02–C12 sin ejecutar; no recuperación WASM/WASI acreditada ni persistencia garantizada tras reemplazo del contenedor.


<a id="retp-218"></a>

### RETP-2026-218 · S22 · Compromiso del recorrido documental integrado C02–C05

2026-09-13T16:05:44Z. Compromiso documental del recorrido integrado C02–C05: 26 casos, 7 positivos y 19 negativos, contextos confiables separados, oráculos y estímulos de captura literales. Cero ejecuciones nuevas de integración. C01 conserva 13 variantes históricas; C02–C12 conservan 202 filas previas sin ejecutar. Verificador administrativo: referencias, SHA256, longitudes, IDs, observados vacíos, fórmulas geométricas contra estado independiente, deltas discriminantes y cuotas literales conformes. No compila SVP ni ejecuta receptor Rust. Rust/Cargo 1.98.0 siguen disponibles tras S25. Historial y RETP se amplían sin sobrescribir entradas previas. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/integracion-c02-c05-v0_1/README.md). Resolver las sedes e interfaz de recepción/observación del recorrido C02–C05 para BIS-03 y documentar las condiciones de paso aplicables; después realizar y ensayar en Rust contra el banco comprometido. BIS-02 sigue abierto; BIS-03 no se abre formalmente en este incremento. Soporte y presupuesto sintéticos; RAM, duración, paridad ES/EN integrada e imagen/consumo visual pendientes. Los siete positivos son expectativas, no siete pruebas superadas. S24 mantiene Bis → catálogo y cierre de fase → análisis e instalación de GUI. S25 conserva su cierre instrumental.


<a id="retp-219"></a>

### RETP-2026-219 · S22 · Decisión de sedes y recepción del montaje C02–C05

2026-09-13T16:27:30Z. Decisión acotada de sedes C02–C05: composición experimental en Rust alrededor de compile_svp_profile, sin cambios de semántica/IR ni workspace productivo. Interfaz de recepción/estado/descriptor y observador separada; doce decisiones cartografían doce obligaciones. Se comprometen 14 casos instrumentales JSON y 5 SHA, sin ejecutar. Los 26 casos integrados de RETP-218 permanecen intactos. Lectura estática de API pública, IR, Nat, ligaduras y auxiliares previos con huellas y alcance de lectura. Compatibilidad estructural de los 26 casos frente al complemento del adaptador; límites positivos/negativos literales, hashes y observados vacíos comprobados documentalmente. Cero ejecuciones nuevas Rust. Historial y RETP append-only; otros sucesos intactos. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis03-sedes-i0205-v0_1/README.md). Materializar en laboratorio el crate sv_bis_i0205 y su conductor/observador conforme a la decisión, fijar las sondas de construcción antes de ejecutarlas, compilar y ensayar auxiliares y recorrido C02–C05 en Rust con resultados separados de expectativas. BIS-03 en ejecución acotada: sedes del primer montaje documentadas; BIS-02 global sigue abierto y BIS-04 queda pendiente de realización. No promoción productiva, cierre de DFL-005 ni catálogo. Perfiles ES/EN integrados, imagen/consumo visual, RAM y tiempo de proceso pendientes. S24/GUI diferida; S25 instrumental conservado.


<a id="retp-220"></a>

### RETP-2026-220 · S22 · Realización y campaña nativa integrada C02–C05

2026-09-13T16:59:22Z. Montaje experimental sv_bis_i0205 implementado y ensayado en Rust/Cargo 1.98.0 con copia verificada de sv_core. 26 casos integrados conformes: 7 entregas documentales concordantes, 17 rechazos y 2 no acreditados. 19 instrumentales conformes, secuencia v1→v2→v1 y 4 sensibilidades del observador conformes. Ocho sondas externas verifican privacidad/API; almacenamiento y lectura agregada probados. Primera campaña conservada; revisión R01 acota recepción al saldo antes de reservar/leer y se comprueba en segunda campaña. Fuentes/sondas fijadas en laboratorio y espejo antes de ejecutar; cargo build/test --locked --offline, rustc y binario nativo. Dos campañas, cada una con 26 casos, 3 repeticiones y 1 lectura adicional: 60 invocaciones totales, 26 variantes integradas únicas. Ocho sondas externas por campaña; segunda campaña añade prueba R01 con 6145 bytes leídos frente a saldo 6144. Diagnósticos, capturas, estados, códigos de salida, huellas y recursos conservados. Cero modificaciones de oráculos previos, fuentes productivas o estados de otros sucesos. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis04-realizacion-i0205-v0_1/README.md). Preparar la extensión del montaje a paridad ES/EN integrada y controles de recursos/captura pendientes mediante banco previo; conservar abierta la suficiencia global y la secuencia Bis → catálogo/cierre de fase → GUI. BIS-04 en ejecución acotada; BIS-02/BIS-03 globales abiertos. Los 202 casos originales C02–C12 siguen sin ejecutar; no se recuentan como integrados. Entrega documental local; sin consumo visual de IA, constitución operativa ni promoción productiva. RAM/tiempo observados sin límites constituidos; agotamiento y todas las cuotas de salida pendientes. S24/GUI diferida y S25 conservados.


<a id="retp-221"></a>

### RETP-2026-221 · S22 · Extensión ES/EN, recursos y captura; hallazgo léxico C12

2026-09-13T17:25:16Z. Extensión nativa del montaje C02–C05: 26 casos nuevos conformes (9 entregas documentales, 17 rechazos), con perfiles ES/EN, cuotas de recepción/recibo y captura. Cinco comparaciones canónicas conformes en campaña R01: cuatro equivalencias y una desigualdad por cambio de dato textual. Núcleo sv_core y admisión RETP-220 sin modificaciones. Precompromiso en laboratorio y espejo antes de cada ejecución. Cargo build --locked --offline y binario nativo Rust/Cargo 1.98.0 desde directorios nuevos; contadores reales por canal, recibos completos, captura, trazas y estados conservados. Dos campañas: 52 invocaciones integradas, 26 variantes únicas. Primera campaña: 26 conformes y tres comparaciones impedidas por Celda, identificador protegido en fixtures C12. Fallo conservado; variantes nuevas CeldaPrueba, previamente comprometidas, resuelven las tres comparaciones sin cambiar expectativas ni compilador. [Referencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis04-extension-perfiles-recursos-v0_1/README.md). Completar frontera de tamaño del descriptor y salida agregada del montaje, y preparar su relevo hacia representación/consumo con pruebas previas; trasladar el hallazgo Celda al retorno de documentación/errores. Mantener Bis → catálogo y cierre de fase → análisis e instalación de GUI. BIS-02/BIS-03/BIS-04 globales abiertos. Paridad acreditada para estas fuentes y operaciones, sin garantía universal ni consumo visual de IA. Cuotas de memoria/tiempo y agotamiento no constituidos. Las 202 filas originales C02–C12 no se declaran ejecutadas como banco propio; originales C12 y resultados previos intactos. S24/GUI diferida; S25 conservado.


<a id="retp-222"></a>

### RETP-2026-222 · S26 · Riesgos materiales y evidencia previa

2026-09-13T18:46:43Z. Alta de seguimiento y matriz documental de doce fallos a provocar, con controles positivos y evidencia exigida. Se distinguen detección, impedimento, fallo observado y resultado no acreditado. Cero casos S26 ejecutados. Inventariar residencia, copias, mutadores, autoridad y fronteras de validación/confirmación/recuperación por recorrido; fijar montaje, estímulos y oráculos antes de ensayar. Entregar pendientes y evidencias al relevo S24. Reflexión iniciada antes del alta; fecha actual de seguimiento, sin retrofechar. S22 y S24 conservan estados y secuencia. Doce casos pendientes; no cierre de R2/R3/R4, DFL ni Bis; no se recuentan pruebas anteriores como S26. GUI no seleccionada ni instalada. [Expediente y matriz](riesgos-materiales-s26/README.md).


<a id="retp-223"></a>

### RETP-2026-223 · S26 · R01 previo

2026-09-13T18:58:37Z. Inventario R01 de nueve tramos materiales y disposición de los doce casos S26. Cuatro sondas parciales comprometidas sobre el montaje Rust existente y fixture I0205-01 literal. Cero sondas nuevas ejecutadas. 26 archivos fuente identificados por SHA256; quince archivos fixture cotejados contra el archivo histórico. Matriz enlaza residencia, mutadores, confirmación y brechas; oráculos y código fijados antes de campaña. Ejecutar las cuatro sondas R01 con Cargo --locked --offline tras publicar el precompromiso; conservar resultados y trasladar las brechas de persistencia, captura y autoridad a sus sedes existentes. S26 sigue en ejecución; los doce casos globales permanecen abiertos. S22/S24 y banco original Bis intactos. Ensayo intra-proceso y de archivos locales; sin transacción durable, GUI, adquisición física, fallo de hardware o resistencia al host acreditados. Sin selección de BD ni promoción productiva. [Inventario](riesgos-materiales-s26/INVENTARIO_MATERIAL_R01.md).


<a id="retp-224"></a>

### RETP-2026-224 · S26 · R01 resultado

2026-09-13T19:01:29Z. Cuatro sondas R01 conformes en Rust/Cargo 1.98.0: positivo documental, archivo alterado después de recepción con nueva lectura rechazada I02, captura alterada detectada D06 y ausencia/fallo posterior D01/D07. Núcleo y admisor existentes sin cambios. Una campaña nativa offline; cuatro funciones de prueba y cero fallos; stdout/stderr y órdenes conservados. Buffer anterior conserva testigo; fuente con LF sigue compilando con identidad distinta. D06 acredita detección posterior, no ausencia de entrega. Fuentes y precompromiso cotejados. Recibir el inventario y resultados en los contratos de consulta/captura y R2: concretar autoridad de custodia, corte coherente y confirmación material antes de ensayar concurrencia, reinicio o GUI. Continuar las fronteras pendientes de Bis sin cerrarlas por estas sondas. S26 sigue en ejecución; los doce casos globales permanecen abiertos. S22/S24 y banco original Bis intactos. Ensayo intra-proceso y de archivos locales; sin transacción durable, GUI, adquisición física, fallo de hardware o resistencia al host acreditados. Sin selección de BD ni promoción productiva. [Inventario](riesgos-materiales-s26/INVENTARIO_MATERIAL_R01.md).


<a id="retp-225"></a>

### RETP-2026-225 · S26 · Recepción contractual R02

2026-09-13T19:32:28Z. Recibidas ocho obligaciones materiales y ocho discriminadores previos en S26, con relevo a R2-0, consulta histórica y DFL-003/004/005/006. Se precisan custodia, lectura coherente, residencia, confirmación, índices, consumidor, observador y recursos. Incremento documental: cero nuevas pruebas de comportamiento; cuatro sondas R01 anteriores conservadas; cero casos globales S26 cerrados. Sin BD, GUI, nueva primitiva o garantía material acreditadas. S22 activo y S24 pendiente conservan su secuencia.

Preparar T01/T02/T07 sobre copia del montaje existente: sustitución de propuesta bajo expectativa fija, mezcla de dependencias y lectura posterior efectiva. Publicar fixtures, código y oráculos antes de ejecutarlos.

[Recepción y discriminadores](riesgos-materiales-s26/RECEPCION_CONTRACTUAL_R02.md).


<a id="retp-226"></a>

### RETP-2026-226 · S26 · R03 previo

2026-09-13T19:50:20Z. Banco R03 previo: tres sondas parciales T01/T02/T07, con controles de sustitución bajo custodia fija, lectura mezclada en barrera explícita y testigo posterior copiado frente a releído. Fixtures A literales de R01; B añade LF y actualiza referencias de fuente. Código y oráculos fijados antes de compilar; cero sondas R03 ejecutadas. Ejecutar R03 tras publicar precompromiso, conservar evidencia y clasificar el límite del observador sin confundir test verde con prevención material. S26 sigue en ejecución; los doce casos globales permanecen abiertos. S22/S24 y banco original Bis intactos. Ensayo intra-proceso y de archivos locales; sin transacción durable, GUI, adquisición física, fallo de hardware o resistencia al host acreditados. Sin selección de BD ni promoción productiva. [Inventario](riesgos-materiales-s26/r03/README.md).


<a id="retp-227"></a>

### RETP-2026-227 · S26 · R03 resultado

2026-09-13T19:54:02Z. R03: tres sondas conformes a sus oráculos. T01 rechaza B bajo A y admite B bajo su custodia declarada; T02 rechaza fuente mezclada I02; T07 reproduce conformidad con copia inicial pese a archivo alterado y detecta alteración con relectura real. Una campaña nativa offline: tres funciones, cero fallos de aserción. Límite observado en T07; no prueba de protección contra host ni de transacción durable. Evidencia literal, órdenes y fuentes conservadas. Preparar recepción instrumentada del testigo posterior y su cualificación en el conductor existente; conservar el contraejemplo T07 y exigir nueva campaña antes de acreditar esa recepción. R2 y GUI conservan sus dependencias. S26 sigue en ejecución; los doce casos globales permanecen abiertos. S22/S24 y banco original Bis intactos. Ensayo intra-proceso y de archivos locales; sin transacción durable, GUI, adquisición física, fallo de hardware o resistencia al host acreditados. Sin selección de BD ni promoción productiva. [Inventario](riesgos-materiales-s26/r03/README.md).


<a id="retp-228"></a>

### RETP-2026-228 · S26 · R04 previo

2026-09-13T20:07:42Z. Variante experimental R04 de recepción del testigo: lectura inicial y posterior reales con cuota; entrega y preservación separadas. Ocho sondas previas P01-P08 con controles y fallos de lectura. Fragmento del conductor I0205 reutilizado; observador literal; quince fixtures R01 preservados y variante de vector Zero a One fijada. Fuentes, oráculos y código comprometidos antes de compilar. Ejecutar ocho sondas R04 después del precompromiso; conservar la evidencia del lector y del despacho; cotejar sensibilidad al testigo copiado y límites del montaje. S26 sigue en ejecución; los doce casos globales permanecen abiertos. S22/S24 y banco original Bis intactos. Ensayo intra-proceso y de archivos locales; sin transacción durable, GUI, adquisición física, fallo de hardware o resistencia al host acreditados. Sin selección de BD ni promoción productiva. [Inventario](riesgos-materiales-s26/r04/README.md).


<a id="retp-229"></a>

### RETP-2026-229 · S26 · R04 resultado

2026-09-13T20:11:03Z. R04: ocho sondas conformes. Relectura posterior detecta cambio literal y del vector; ausencia, error de lectura y exceso se distinguen sin borrar entrega previa. Fallo o cambio inicial detienen el recorrido; el observador heredado conserva su límite ante copias falsamente posteriores. Una campaña Rust/Cargo 1.98.0, offline, ocho funciones y cero fallos de aserción; informes por caso y fuentes conservados. Realización local por operación; no BD, aislamiento, captura de pantalla ni recuperación acreditados. Extender la cualificación por las salidas restantes del conductor y fijar tratamiento de interrupción/pánico y sustitución de fuente durante lectura antes de integrar esta recepción en el recorrido completo. Conservar S26 y el relevo Bis/S24. S26 sigue en ejecución; los doce casos globales permanecen abiertos. S22/S24 y banco original Bis intactos. Ensayo intra-proceso y de archivos locales; sin transacción durable, GUI, adquisición física, fallo de hardware o resistencia al host acreditados. Sin selección de BD ni promoción productiva. [Inventario](riesgos-materiales-s26/r04/README.md).


<a id="retp-230"></a>

### RETP-2026-230 · S27 · Dominio, cobertura y rutas necesarias

2026-09-13T20:52:22Z. Sección 11 añadida al PDF/MD del volcán; complemento en PDF/MD de tres realizaciones Rust; entrada destacada en Léame primero. Primero dominio y sus unidades; Lenguaje continúa S26 y preserva antecedentes de rutas. Prefijos Markdown preservados; texto y render de las 30 páginas anteriores idénticos; tres páginas nuevas inspeccionadas. Código, texto íntegro de incorporación y huellas conservados. Publicación y espejo sujetos al cotejo de árbol del publicador. Alta documental posterior a la actividad; no se inventa hora de inicio. Autor del argumento: Juan Antonio Lloret Egea; edición Watson. S22/S24 y banco Bis conservan su estado. No ensayos Rust nuevos por esta incorporación ni acreditación de cobertura clínica. Continuar S26: salidas sin recibo, interrupción/pánico y sustitución de fuente durante lectura. Retomar cobertura de rutas en sede del dominio y agente cuando corresponda. [Evidencia](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/blob/main/docs/calidad/tuberias-ia/frame-significado-humano-trazabilidad-y-fidelidad/LEAME_PRIMERO.md).


<a id="retp-231"></a>

### RETP-2026-231 · S26 · R05 previo

2026-09-13T20:56:56Z. R05: siete sondas previas fijadas para retorno rechazado, ausencia de captura, pánico y sustitución de ruta tras apertura. Copia local instrumentada; sin cambio productivo. Banco y 25 archivos fijados antes de Cargo; fuentes R04 conservadas. Precompromiso público y espejo preceden a campaña. S26 sigue en ejecución; doce casos globales abiertos. S22/S24 y banco Bis intactos. Ensayo Linux local sin BD, transacción durable, adquisición, GUI, fallo de hardware ni resistencia al host acreditados. Inode local no es identidad universal. S27 conserva reparto dominio/agente/Lenguaje. Ejecutar siete sondas R05; conservar lecturas reales, informes ausentes y sustitución de objeto con bytes iguales sin promover garantías. [Evidencia](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/blob/main/docs/calidad/riesgos-materiales-s26/r05/README.md).


<a id="retp-232"></a>

### RETP-2026-232 · S26 · R05 resultado

2026-09-13T20:59:20Z. R05: siete sondas conformes al banco. Rechazo y falta de captura permiten relectura sin acreditar entrega. Pánico impide MaterialRun final. Ruta sustituida con bytes iguales conserva concordancia pese a cambio de objeto: límite confirmado. Una campaña Rust/Cargo 1.98.0 offline; siete aserciones de caso conformes, fuentes y precompromiso intactos; dos pánicos provocados y capturados sólo por el arnés. Sin protección productiva ante pánico acreditada. S26 sigue en ejecución; doce casos globales abiertos. S22/S24 y banco Bis intactos. Ensayo Linux local sin BD, transacción durable, adquisición, GUI, fallo de hardware ni resistencia al host acreditados. Inode local no es identidad universal. S27 conserva reparto dominio/agente/Lenguaje. Definir recepción explícita de terminación sin informe y alcance de identidad de fuente antes de integrar; después cualificar abort/interrupción de proceso y montaje completo. S26 permanece abierto; conservar Bis/S24. [Evidencia](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/blob/main/docs/calidad/riesgos-materiales-s26/r05/README.md).


<a id="retp-233"></a>

### RETP-2026-233 · S26 · R06 · Terminación sin informe e identidad de fuente

2026-09-13T21:13:18Z. R06: recepción contractual de terminación sin informe y alcance de identidad de fuente. Se separan informe, observación de terminación y efecto; mínimo de encargo/referentes autorizados y contenido consumido; continuidad de soporte sólo si su perfil la exige. Ocho discriminadores especificados, cero ejecutados. Fuentes cotejadas por blobs contra corte vigente; campañas anteriores y registros conservados. Verificación documental, sin nueva compilación ni protección ejecutable acreditada. Recepción de obligaciones, no cierre material. Doce casos globales S26 abiertos; R2/R3/R4, DFL y Bis conservan alcance. No GUI, BD, nueva identidad universal ni selección de host. S27 y el dominio permanecen en su sede. Preparar variante local con correlación explícita, informe y terminación separados y ligadura de contenido admitido-consumido; precomprometer código, fixtures, cuotas y oráculos antes de ejecutar T01/T02/T05/T06. Después concretar observador de proceso y T03/T04/T08; T07 con barreras propias. Conservar S26, Bis y S24. [Evidencia](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/blob/main/docs/calidad/riesgos-materiales-s26/r06/README.md).

<a id="retp-234"></a>

### RETP-2026-234 · S26 · R07 · Falsación de auxiliares heredados

2026-09-13T21:59:24Z. R07: ocho oráculos cumplidos; cuatro reproducciones de debilidades en auxiliares heredados. Elusión de guardas bajo -O; checkpoint ajeno aceptado; escritura parcial local ante error de archivo. Dos controles positivos y dos rechazos normales. Banco publicado antes de ejecutar: Lenguaje a243bd096502580d91fe5166ceb1ebb478f10681; laboratorio f8c7e21817ca4842ce0ad3904e023962419c9b3c. Conductor Rust 1.98.0; Python 3.12.14 sólo como objeto bajo prueba. Fuentes y binario conservados; ocho salidas y estados retenidos. Cuatro debilidades reproducidas no son cuatro protecciones. Cero reparaciones acreditadas. Transporte GitHub simulado; archivos locales reales. Sin prueba de RAM física, durabilidad, host o GUI; sin invalidación retrospectiva de campañas. Python no administra ni publica este expediente. Preparar reparación acotada de auxiliares con Rust como primera opción y conservar los testigos R07. R06 mantiene correlación e identidad admitido-consumido pendientes; S26 y Bis abiertos; S24 pendiente. [Evidencia](https://github.com/juantoniolloretegea/SV-lenguaje-de-computacion/blob/main/docs/calidad/riesgos-materiales-s26/r07/RESULTADOS.md).
