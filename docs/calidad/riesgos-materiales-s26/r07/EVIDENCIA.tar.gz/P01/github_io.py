from pathlib import Path
A='a'*40
def log(x):
 p=Path('llamadas.txt');p.write_text((p.read_text() if p.exists() else '')+x+'\n')
def fetch(url):
 log('fetch '+url)
 if '/git/ref/' in url:return {'object':{'sha':A}}
 if '/git/trees/' in url:return {'sha':'b'*40,'truncated':False,'tree':[]}
 raise RuntimeError('URL no prevista')
def call(name,args):
 log('call '+name)
 if name=='create_tree':return {'sha':'b'*40}
 if name=='create_commit':return {'sha':'c'*40}
 if name=='update_ref':return {'success':True}
 raise RuntimeError('Operacion no prevista')
