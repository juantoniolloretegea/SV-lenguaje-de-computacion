import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from publicar_archivos import publicar
print('DEBUG='+str(__debug__),flush=True)
bad=sys.argv[1]=='bad'
stale=sys.argv[1]=='stale'
r=publicar('fixture/otro' if stale else 'fixture/repo','main',{'out.txt':'inexistente.txt'} if stale else {},'fixture','checkpoint.json',expected_base=('d' if bad or stale else 'a')*40)
print('RETORNO='+json.dumps(r,sort_keys=True),flush=True)
