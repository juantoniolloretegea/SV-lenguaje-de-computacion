//! Cotejo administrativo de las tres representaciones de Sucesos; no es prueba SV.
#![forbid(unsafe_code)]
#[allow(dead_code)]
#[path="../lenguaje/docs/calidad/riesgos-materiales-s26/r08/auxiliar.rs"] mod auxiliar;
use std::{fs,path::Path,collections::{BTreeMap,BTreeSet}};
fn run()->Result<(),Box<dyn std::error::Error>>{
 let a:Vec<_>=std::env::args().collect();let d=Path::new(a.get(1).ok_or("directorio")?);
 let c=auxiliar::csv(&fs::read(d.join("SUCESOS_SV.csv"))?)?;
 let h=auxiliar::csv(&fs::read(d.join("HISTORIAL_SUCESOS_SV.csv"))?)?;
 let md=fs::read_to_string(d.join("SUCESOS_SV.md"))?;
 let mut hh=vec!["revision".to_string()];hh.extend(c[0].clone());if hh!=h[0]{return Err("cabecera".into());}
 let mut last=BTreeMap::new();let mut seen=BTreeSet::new();
 for r in &h[1..]{let rev:u64=r[0].parse()?;if !seen.insert((r[1].clone(),rev)){return Err("revision duplicada".into());}
 let x=last.entry(r[1].clone()).or_insert((rev,&r[1..]));if rev>x.0{*x=(rev,&r[1..]);}}
 let mut ids=BTreeSet::new();
 for r in &c[1..]{if !ids.insert(&r[0]){return Err("suceso duplicado".into());}
 let l=last.get(&r[0]).ok_or("historial ausente")?;if l.1!=r{return Err(format!("fila distinta {}",r[0]).into());}
 let heading=format!("## {} · ",r[0]);let start=md.find(&heading).ok_or("seccion")?;
 let end=md[start+heading.len()..].find("\n## ").map(|n|start+heading.len()+n+1).unwrap_or(md.len());let block=&md[start..end];
 for (k,v) in c[0].iter().zip(r){if k=="id"||k=="actividad"{continue;}
 let p=format!("**{k}:** ");let values:Vec<_>=block.lines().filter_map(|s|s.strip_prefix(&p)).collect();
 if values!=vec![if v.is_empty(){"—"}else{v.as_str()}]{return Err(format!("campo MD {} {k}",r[0]).into());}}
 }
 if ids.len()!=29||last.get("S26").map(|x|x.0)!=Some(25)||last.get("S28").map(|x|x.0)!=Some(2){return Err("corte esperado".into());}
 println!("29 sucesos concordantes en CSV, MD e historial; S26 revision 25; S28 revision 2.");
 Ok(())
}
fn main(){if let Err(e)=run(){eprintln!("{e}");std::process::exit(1);}}
