//! Adaptador administrativo de lectura Git/archivos para el auxiliar R08 existente.
//! No contiene oráculos ni operaciones del banco SV.
#![forbid(unsafe_code)]
#[allow(dead_code)]
#[path="../lenguaje/docs/calidad/riesgos-materiales-s26/r08/auxiliar.rs"]
mod auxiliar;
use std::{fs,path::Path,process::{Command,Stdio},io::Write,os::unix::fs::PermissionsExt};
fn run()->Result<(),Box<dyn std::error::Error>>{
 let a:Vec<_>=std::env::args().collect();
 if a.len()!=4 {return Err("uso: cotejar ROOT ESPERADO OBSERVADO".into());}
 let root=Path::new(&a[1]);
 let expected=auxiliar::publication(&auxiliar::read(Path::new(&a[2]))?)?;
 let mut input=String::new();
 for (p,(m,t,_)) in &expected.entries {
  if t!="blob" || !matches!(m.as_str(),"100644"|"100755") {return Err(format!("fuera de perfil: {p} {m} {t}").into());}
  let path=root.join(p);let md=fs::symlink_metadata(&path)?;
  if !md.is_file(){return Err(format!("no regular: {p}").into());}
  let mode=if md.permissions().mode()&0o111==0 {"100644"}else{"100755"};
  if mode!=m{return Err(format!("modo distinto: {p}").into());}
  let s=path.to_str().ok_or("ruta no UTF8")?;
  if s.contains(['\n','\r','"','\\']){return Err("ruta fuera de perfil".into());}
  input.push_str(s);input.push('\n');
 }
 let mut child=Command::new("git").args(["hash-object","--no-filters","--stdin-paths"]).stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped()).spawn()?;
 let mut stdin=child.stdin.take().ok_or("stdin")?;
 let writer=std::thread::spawn(move||stdin.write_all(input.as_bytes()));
 let output=child.wait_with_output()?;writer.join().map_err(|_|"escritor")??;
 if !output.status.success(){return Err(String::from_utf8(output.stderr)?.into());}
 let hashes=String::from_utf8(output.stdout)?;
 let lines:Vec<_>=hashes.lines().collect();
 if lines.len()!=expected.entries.len(){return Err("numero de objetos distinto".into());}
 let mut text=String::from("SV-AUX-PUB/1\n");
 for (k,v) in &expected.context {text+=&format!("{k}\t{v}\n");}
 for ((p,(m,t,_)),h) in expected.entries.iter().zip(lines){text+=&format!("entry\t{p}\t{m}\t{t}\t{h}\n");}
 fs::write(&a[3],text)?;
 auxiliar::check_publication(Path::new(&a[2]),Path::new(&a[3]))?;
 println!("COMPROBACION_LOCAL_CONFORME archivos={} commit={}",expected.entries.len(),expected.context["commit"]);
 Ok(())
}
fn main(){if let Err(e)=run(){eprintln!("{e}");std::process::exit(1);}}
