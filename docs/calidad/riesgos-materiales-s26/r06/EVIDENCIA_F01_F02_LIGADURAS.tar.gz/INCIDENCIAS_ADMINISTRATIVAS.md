# Incidencias administrativas conservadas

Estas incidencias no son casos del banco LIG ni cambian sus oráculos.

- El intento de clonar el laboratorio por Git HTTPS terminó con retorno 128: `fatal: could not read Username for 'https://github.com': No such device or address`. Se utilizó el conector GitHub ya autorizado para el espejo y la lectura completa de árboles.
- Primera compilación del registrador administrativo: `rustc +1.98.0 --edition=2021 ejecutar.rs -o ejecutar`, retorno 1, `error: multiple input filenames provided (first two filenames are `+1.98.0` and `ejecutar.rs`)`. El intento inmediato de usar el ejecutable todavía inexistente devolvió 127. La instalación directa se verificó como 1.98.0; la corrección de invocación del banco se publicó antes de compilarlo. No había casos SV ejecutados.
- R08 rechazó dos descriptores con una línea vacía final: PUB_CAMPO. Los archivos `*-esperado.fallo-formato.tsv` conservan esos bytes y los registros cotejo-main-antes/cotejo-base-antes sus retornos 1. Los descriptores se regeneraron sin esa línea y los cotejos r1 fueron conformes. El código de R08 permanece intacto.
- Una consulta administrativa `git status --short` se lanzó desde el directorio de evidencias, que no es un repositorio, y fue rechazada. El estado Git válido se consultó desde el checkout del Lenguaje. No hubo escritura en ese intento.

Los seis comandos del banco publicados con rutas directas terminaron con retorno 0. Los diagnósticos de compilación de sv_core (25 advertencias por perfil, principalmente código no utilizado y una anotación de lifetime) se conservan en stderr. No se aplicó cargo fix ni se alteró el núcleo.

El Word se materializó sin cambios y se revisó con el renderizador documental Python/LibreOffice; ese uso se limita a formato y metadatos de transferencia, fuera de las pruebas SV. Las pruebas y su registro de ejecución utilizan Rust. Git, tar y sha256sum sirven al transporte, conservación e identificación administrativa.
