
<a id="retp-237"></a>

### RETP-2026-237 · S22 · Fronteras conjuntas de salida

Fronteras conjuntas de descriptor y recibo: doce variantes EN/ES conformes en cada perfil Rust; 24 invocaciones, cero discrepancias y cuatro sensibilidades detectadas por campaña.

Precompromiso Lenguaje 0452670b1d78c581592acca7740814c1c4cdef05 y laboratorio 74c013fc4d0cef1aa6e0b09486e9709700324ae5; ambos cotejados con R08 antes de ejecutar. Rust 1.98.0 offline/locked: debug y optimizado sin debug-assertions; 12/12 por perfil, salida 0; 157 huellas de entrada intactas.

La rama agregada de rechazo es inalcanzable bajo ambos límites individuales; no se declara ejecutada. Sin imagen ni consumo visual de IA, consulta histórica completa, resistencia al host ni cotas RAM/tiempo. Incidencias auxiliares preservadas. Las 202 filas originales y recuentos globales Bis no cambian; S26 y Bis siguen abiertos.

Preparar incremento de representación/consumo según el relevo C04/C05: sede, componente, canal, captura final, presupuesto y oráculos antes de ejecutar. Conservar Celda para catálogo y el orden Bis, catálogo/cierre de fase, GUI C#/.NET.

[Evidencia](tuberias-ia/paridad-imagen-celula-matematica/estudio-nucleo-agentes/bis04-extension-perfiles-recursos-v0_1/RESULTADOS_FRONTERAS_SALIDA.md).
