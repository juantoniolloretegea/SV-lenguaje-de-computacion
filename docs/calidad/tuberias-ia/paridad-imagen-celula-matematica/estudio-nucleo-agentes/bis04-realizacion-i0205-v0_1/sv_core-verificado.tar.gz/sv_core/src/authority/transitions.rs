//! Transiciones de autoridad y génesis lógica de R1-2 y R1-3.
//!
//! R1-2 conserva la única vía productiva inicial de autoridad: T-0 bajo
//! premisa externa opaca y continuidad no habitada. R1-3 superpone sobre esa
//! misma puerta la constitución inicial de `Req` y `Applicable` para las formas
//! sujetas a control, sin ejecutar comprobaciones ni producir permisos.
//!
//! La continuidad representada aquí es lógica e intra-proceso. No acredita
//! continuidad material entre procesos, réplicas, restauraciones o estados
//! persistentes.

use std::collections::{BTreeMap, BTreeSet};

use super::{
    AccumulationContract, ConstitutedAuthority, EffectDescriptor, EffectEnvelope, FormDescriptor,
    GovernedDomain, InvalidAuthorityScope,
};
use crate::control::{
    AuthorityHolderRef, AuthorityRef, ContextRef, ContinuityOccupancy, EffectFamilyRef, EffectRef,
    FormRef, GovernedObjectRef, RequirementRef, TransitionClass, VerifierRef,
};
use crate::requirements::initial::{
    constitute_initial, ApplicabilityProposal, InitialRequirementError, InitialRequirementState,
    RequirementBinding, RequirementProposal,
};
use crate::requirements::{RequirementSet, VerifierApplicability};

/// Disposición de una clase T-* respecto de la constitución de autoridad en
/// R1-2.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TransitionDisposition {
    /// T-0: única vía productiva de autoridad materializada en este corte.
    GenesisOnly,
    /// T-I, T-V, T-H y T-E: no pueden constituir autoridad.
    NonAuthorizing,
    /// T-G, T-C y T-R: no aplican cambios; R1-3 constituye requisitos pero no
    /// hace productivas estas transiciones.
    BlockedPendingRequirements,
}

/// Clasifica una transición sin ejecutar efectos ni modificar autoridad.
#[inline]
pub const fn transition_disposition(class: TransitionClass) -> TransitionDisposition {
    match class {
        TransitionClass::Genesis => TransitionDisposition::GenesisOnly,
        TransitionClass::Information
        | TransitionClass::Verification
        | TransitionClass::Enablement
        | TransitionClass::Exercise => TransitionDisposition::NonAuthorizing,
        TransitionClass::Governance
        | TransitionClass::Constitutive
        | TransitionClass::Recovery => TransitionDisposition::BlockedPendingRequirements,
    }
}

/// Premisa constituyente externa consumida por la puerta T-0.
///
/// El tipo es deliberadamente opaco y no ofrece constructor público. Su mera
/// existencia tampoco constituye autoridad SV: sólo satisface una premisa de
/// entrada del modelo lógico de T-0. La legitimidad material de su procedencia
/// queda fuera de R1.
///
/// ```compile_fail
/// use sv_core::authority::transitions::ExternalGenesisPremise;
/// let _premise = ExternalGenesisPremise { consumed: false };
/// ```
#[derive(Debug)]
pub struct ExternalGenesisPremise {
    consumed: bool,
}

impl ExternalGenesisPremise {
    #[cfg(test)]
    fn for_test() -> Self {
        Self { consumed: false }
    }

    /// Indica si la premisa ya fue consumida por una génesis completada.
    #[inline]
    pub const fn is_consumed(&self) -> bool {
        self.consumed
    }
}

/// Capacidad interna de constitución inicial de requisitos.
///
/// No tiene constructor accesible fuera de este módulo y no implementa
/// `Clone`. El submódulo de requisitos exige una referencia a esta capacidad
/// para convertir propuestas en objetos constituidos.
#[derive(Debug)]
pub(crate) struct GenesisControlToken {
    _private: (),
}

/// Descripción ordinaria de un efecto propuesto para la constitución inicial.
///
/// Una propuesta no es un `EffectDescriptor` constituido.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EffectProposal {
    reference: EffectRef,
    family: EffectFamilyRef,
    object: GovernedObjectRef,
    context: ContextRef,
}

impl EffectProposal {
    pub fn new(
        reference: EffectRef,
        family: EffectFamilyRef,
        object: GovernedObjectRef,
        context: ContextRef,
    ) -> Self {
        Self {
            reference,
            family,
            object,
            context,
        }
    }
}

/// Descripción ordinaria de una forma propuesta para el estado inicial.
///
/// La clase T-* queda fijada en la propuesta y no puede elegirse después por el
/// ejecutor.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FormProposal {
    reference: FormRef,
    transition_class: TransitionClass,
    effect_family: EffectFamilyRef,
    context_bindings: Vec<ContextRef>,
    required_authority: Option<AuthorityRef>,
    accumulation: AccumulationContract,
}

impl FormProposal {
    pub fn new(
        reference: FormRef,
        transition_class: TransitionClass,
        effect_family: EffectFamilyRef,
        context_bindings: impl IntoIterator<Item = ContextRef>,
        required_authority: Option<AuthorityRef>,
        accumulation: AccumulationContract,
    ) -> Self {
        Self {
            reference,
            transition_class,
            effect_family,
            context_bindings: context_bindings.into_iter().collect(),
            required_authority,
            accumulation,
        }
    }

    /// Predicado cerrado de sujeción a control para la representación de R1.
    ///
    /// No existe un booleano libre suministrable por el ejecutor. Una forma se
    /// considera controlada si depende de autoridad previa o pertenece a una
    /// clase que puede modificar gobierno, constitución o recuperación.
    #[inline]
    fn subject_to_control(&self) -> bool {
        self.required_authority.is_some()
            || matches!(
                self.transition_class,
                TransitionClass::Governance
                    | TransitionClass::Constitutive
                    | TransitionClass::Recovery
            )
    }
}

/// Descripción ordinaria de una autoridad propuesta para el estado inicial.
///
/// La propuesta no confiere autoridad y no puede convertirse en
/// `ConstitutedAuthority` fuera de la puerta T-0 de este módulo.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AuthorityProposal {
    reference: AuthorityRef,
    holder: AuthorityHolderRef,
    context: ContextRef,
    effects: Vec<EffectProposal>,
    governed_objects: Vec<GovernedObjectRef>,
}

impl AuthorityProposal {
    pub fn new(
        reference: AuthorityRef,
        holder: AuthorityHolderRef,
        context: ContextRef,
        effects: impl IntoIterator<Item = EffectProposal>,
        governed_objects: impl IntoIterator<Item = GovernedObjectRef>,
    ) -> Self {
        Self {
            reference,
            holder,
            context,
            effects: effects.into_iter().collect(),
            governed_objects: governed_objects.into_iter().collect(),
        }
    }
}

/// Propuesta completa de estado inicial para T-0.
///
/// Las propuestas de requisitos y aplicabilidad forman parte del mismo plan;
/// no existe en esta unidad una operación posterior para completarlas sobre
/// una continuidad ya habitada.
#[derive(Debug, PartialEq, Eq)]
pub struct GenesisPlan {
    forms: Vec<FormProposal>,
    authorities: Vec<AuthorityProposal>,
    requirements: Vec<RequirementProposal>,
    applicabilities: Vec<ApplicabilityProposal>,
}

impl GenesisPlan {
    pub fn new(
        forms: impl IntoIterator<Item = FormProposal>,
        authorities: impl IntoIterator<Item = AuthorityProposal>,
    ) -> Self {
        Self {
            forms: forms.into_iter().collect(),
            authorities: authorities.into_iter().collect(),
            requirements: Vec::new(),
            applicabilities: Vec::new(),
        }
    }

    /// Añade propuestas de constitución inicial de R1-3.
    ///
    /// Las propuestas continúan siendo datos ordinarios hasta que T-0 las
    /// valide y las constituya de forma atómica.
    pub fn with_initial_control(
        mut self,
        requirements: impl IntoIterator<Item = RequirementProposal>,
        applicabilities: impl IntoIterator<Item = ApplicabilityProposal>,
    ) -> Self {
        self.requirements = requirements.into_iter().collect();
        self.applicabilities = applicabilities.into_iter().collect();
        self
    }

    #[inline]
    pub fn form_count(&self) -> usize {
        self.forms.len()
    }

    #[inline]
    pub fn authority_count(&self) -> usize {
        self.authorities.len()
    }

    #[inline]
    pub fn requirement_proposal_count(&self) -> usize {
        self.requirements.len()
    }

    #[inline]
    pub fn applicability_proposal_count(&self) -> usize {
        self.applicabilities.len()
    }
}

/// Rechazo cerrado de una génesis lógica.
///
/// Ninguna variante pertenece a `Tri` ni constituye un valor semántico de
/// dominio.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum GenesisError {
    AlreadyInhabited,
    PremiseAlreadyConsumed,
    EmptyInitialForms,
    EmptyInitialAuthorities,
    DuplicateFormRef(FormRef),
    DuplicateAuthorityRef(AuthorityRef),
    AuthorizingFormWithoutRequiredAuthority {
        form: FormRef,
        class: TransitionClass,
    },
    MissingRequiredAuthority {
        form: FormRef,
        authority: AuthorityRef,
    },
    ControlledFormWithoutContext(FormRef),
    InvalidAuthorityScope(InvalidAuthorityScope),
    InvalidInitialRequirements(InitialRequirementError),
}

impl From<InvalidAuthorityScope> for GenesisError {
    fn from(error: InvalidAuthorityScope) -> Self {
        Self::InvalidAuthorityScope(error)
    }
}

impl From<InitialRequirementError> for GenesisError {
    fn from(error: InitialRequirementError) -> Self {
        Self::InvalidInitialRequirements(error)
    }
}

/// Continuidad autoritativa lógica de R1.
///
/// El tipo no implementa `Clone`. Crear un valor `Uninhabited` representa un
/// estado lógico vacío; no demuestra que el proceso material sea una
/// continuidad autoritativa nueva.
#[derive(Debug, PartialEq, Eq)]
pub struct AuthorityContinuity {
    occupancy: ContinuityOccupancy,
    forms: BTreeMap<FormRef, FormDescriptor>,
    authorities: BTreeMap<AuthorityRef, ConstitutedAuthority>,
    initial_requirements: InitialRequirementState,
}

impl AuthorityContinuity {
    /// Crea únicamente el estado lógico vacío del modelo intra-proceso.
    #[inline]
    pub fn uninhabited() -> Self {
        Self {
            occupancy: ContinuityOccupancy::Uninhabited,
            forms: BTreeMap::new(),
            authorities: BTreeMap::new(),
            initial_requirements: InitialRequirementState::default(),
        }
    }

    #[inline]
    pub const fn occupancy(&self) -> ContinuityOccupancy {
        self.occupancy
    }

    /// Disponibilidad lógica de T-0 dentro de este objeto de continuidad.
    #[inline]
    pub const fn t0_available(&self) -> bool {
        matches!(self.occupancy, ContinuityOccupancy::Uninhabited)
    }

    #[inline]
    pub fn form_count(&self) -> usize {
        self.forms.len()
    }

    #[inline]
    pub fn authority_count(&self) -> usize {
        self.authorities.len()
    }

    #[inline]
    pub fn requirement_set_count(&self) -> usize {
        self.initial_requirements.requirement_set_count()
    }

    #[inline]
    pub fn verifier_applicability_count(&self) -> usize {
        self.initial_requirements.applicability_count()
    }

    #[inline]
    pub fn form(&self, reference: &FormRef) -> Option<&FormDescriptor> {
        self.forms.get(reference)
    }

    #[inline]
    pub fn authority(&self, reference: &AuthorityRef) -> Option<&ConstitutedAuthority> {
        self.authorities.get(reference)
    }

    /// Devuelve el `Req` constituido para una ligadura inicial exacta.
    #[inline]
    pub fn requirement_set(
        &self,
        form: &FormRef,
        effect_family: &EffectFamilyRef,
        context: &ContextRef,
    ) -> Option<&RequirementSet> {
        self.initial_requirements
            .requirement_set(form, effect_family, context)
    }

    /// Devuelve una relación de aplicabilidad constituida por T-0.
    #[inline]
    pub fn verifier_applicability(
        &self,
        requirement: &RequirementRef,
        verifier: &VerifierRef,
        context: &ContextRef,
    ) -> Option<&VerifierApplicability> {
        self.initial_requirements
            .applicability(requirement, verifier, context)
    }

    /// Puerta de T-0 de R1-2 con la conjunción constitutiva de R1-3.
    ///
    /// La operación continúa consumiendo la misma premisa opaca de R1-2. Toda
    /// validación se completa sobre objetos locales y sólo después se compromete
    /// el estado completo de la continuidad.
    pub fn apply_genesis(
        &mut self,
        premise: &mut ExternalGenesisPremise,
        plan: GenesisPlan,
    ) -> Result<(), GenesisError> {
        if matches!(self.occupancy, ContinuityOccupancy::Inhabited) {
            return Err(GenesisError::AlreadyInhabited);
        }

        if premise.consumed {
            return Err(GenesisError::PremiseAlreadyConsumed);
        }

        if plan.forms.is_empty() {
            return Err(GenesisError::EmptyInitialForms);
        }

        if plan.authorities.is_empty() {
            return Err(GenesisError::EmptyInitialAuthorities);
        }

        let mut authority_refs = BTreeSet::new();
        for authority in &plan.authorities {
            if !authority_refs.insert(authority.reference.clone()) {
                return Err(GenesisError::DuplicateAuthorityRef(
                    authority.reference.clone(),
                ));
            }
        }

        let mut form_refs = BTreeSet::new();
        let mut controlled_bindings = Vec::new();
        for form in &plan.forms {
            if !form_refs.insert(form.reference.clone()) {
                return Err(GenesisError::DuplicateFormRef(form.reference.clone()));
            }

            if matches!(
                form.transition_class,
                TransitionClass::Governance
                    | TransitionClass::Constitutive
                    | TransitionClass::Recovery
            ) && form.required_authority.is_none()
            {
                return Err(GenesisError::AuthorizingFormWithoutRequiredAuthority {
                    form: form.reference.clone(),
                    class: form.transition_class,
                });
            }

            if let Some(required) = &form.required_authority {
                if !authority_refs.contains(required) {
                    return Err(GenesisError::MissingRequiredAuthority {
                        form: form.reference.clone(),
                        authority: required.clone(),
                    });
                }
            }

            if form.subject_to_control() {
                if form.context_bindings.is_empty() {
                    return Err(GenesisError::ControlledFormWithoutContext(
                        form.reference.clone(),
                    ));
                }
                for context in &form.context_bindings {
                    controlled_bindings.push(RequirementBinding::new(
                        form.reference.clone(),
                        form.effect_family.clone(),
                        context.clone(),
                    ));
                }
            }
        }

        let mut authorities = BTreeMap::new();
        for proposal in plan.authorities {
            let governed_domain = GovernedDomain {
                objects: proposal.governed_objects.into_iter().collect(),
            };

            let mut effects = BTreeSet::new();
            for effect in proposal.effects {
                if effect.context != proposal.context {
                    return Err(GenesisError::InvalidAuthorityScope(
                        InvalidAuthorityScope::EffectOutsideAuthorityContext,
                    ));
                }

                if !governed_domain.objects.contains(&effect.object) {
                    return Err(GenesisError::InvalidAuthorityScope(
                        InvalidAuthorityScope::EffectOutsideGovernedDomain,
                    ));
                }

                effects.insert(EffectDescriptor {
                    reference: effect.reference,
                    family: effect.family,
                    object: effect.object,
                    context: effect.context,
                });
            }

            let reference = proposal.reference.clone();
            authorities.insert(
                reference,
                ConstitutedAuthority {
                    reference: proposal.reference,
                    holder: proposal.holder,
                    context: proposal.context,
                    max_effects: EffectEnvelope { effects },
                    governed_domain,
                },
            );
        }

        let token = GenesisControlToken { _private: () };
        let initial_requirements = constitute_initial(
            &token,
            controlled_bindings,
            plan.requirements,
            plan.applicabilities,
        )?;

        let mut forms = BTreeMap::new();
        for proposal in plan.forms {
            let reference = proposal.reference.clone();
            forms.insert(
                reference,
                FormDescriptor {
                    reference: proposal.reference,
                    transition_class: proposal.transition_class,
                    effect_family: proposal.effect_family,
                    context_bindings: proposal.context_bindings.into_iter().collect(),
                    required_authority: proposal.required_authority,
                    accumulation: proposal.accumulation,
                },
            );
        }

        self.forms = forms;
        self.authorities = authorities;
        self.initial_requirements = initial_requirements;
        self.occupancy = ContinuityOccupancy::Inhabited;
        premise.consumed = true;
        Ok(())
    }
}

impl Default for AuthorityContinuity {
    fn default() -> Self {
        Self::uninhabited()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::control::{
        ApplicabilityRuleRef, ConflictResolutionRuleRef, ControlId, CoverageRuleRef,
        RequirementRef, TransitionClass, VerifierFamilyRef, VerifierRef,
    };
    use crate::requirements::initial::{
        ConflictResolutionRuleProposal, CoverageRuleProposal,
    };
    use crate::requirements::{CoreRequirementKind, RequirementClass};

    fn id(value: &str) -> ControlId {
        ControlId::new(value).unwrap()
    }

    fn form_ref(value: &str) -> FormRef {
        FormRef::from_core_id(id(value))
    }

    fn effect_family_ref(value: &str) -> EffectFamilyRef {
        EffectFamilyRef::from_core_id(id(value))
    }

    fn effect_ref(value: &str) -> EffectRef {
        EffectRef::from_core_id(id(value))
    }

    fn context_ref(value: &str) -> ContextRef {
        ContextRef::from_core_id(id(value))
    }

    fn authority_ref(value: &str) -> AuthorityRef {
        AuthorityRef::from_core_id(id(value))
    }

    fn holder_ref(value: &str) -> AuthorityHolderRef {
        AuthorityHolderRef::from_core_id(id(value))
    }

    fn object_ref(value: &str) -> GovernedObjectRef {
        GovernedObjectRef::from_core_id(id(value))
    }

    fn requirement_ref(value: &str) -> RequirementRef {
        RequirementRef::from_core_id(id(value))
    }

    fn verifier_ref(value: &str) -> VerifierRef {
        VerifierRef::from_core_id(id(value))
    }

    fn verifier_family_ref(value: &str) -> VerifierFamilyRef {
        VerifierFamilyRef::from_core_id(id(value))
    }

    fn applicability_rule_ref(value: &str) -> ApplicabilityRuleRef {
        ApplicabilityRuleRef::from_core_id(id(value))
    }

    fn conflict_rule_ref(value: &str) -> ConflictResolutionRuleRef {
        ConflictResolutionRuleRef::from_core_id(id(value))
    }

    fn coverage_rule_ref(value: &str) -> CoverageRuleRef {
        CoverageRuleRef::from_core_id(id(value))
    }

    fn mandatory_requirement_proposals(
        form: &str,
        family: &str,
        context: &str,
    ) -> Vec<RequirementProposal> {
        [
            ("form", CoreRequirementKind::FormValidity),
            ("authority", CoreRequirementKind::ApplicableAuthority),
            (
                "verifier",
                CoreRequirementKind::VerifierAdmissibilityAndApplicability,
            ),
            ("no-self", CoreRequirementKind::NoSelfAccreditation),
        ]
        .into_iter()
        .map(|(suffix, kind)| {
            RequirementProposal::new(
                requirement_ref(&format!("req:{form}:{suffix}")),
                RequirementClass::Core(kind),
                form_ref(form),
                effect_family_ref(family),
                context_ref(context),
                [verifier_family_ref("verifier-family:canonical")],
                applicability_rule_ref("applicability:canonical"),
            )
        })
        .collect()
    }

    fn controlled_plan_with_initial_control(
        requirements: Vec<RequirementProposal>,
        applicabilities: Vec<ApplicabilityProposal>,
    ) -> GenesisPlan {
        let authority = authority_ref("authority:genesis");
        let context = "context:genesis";
        GenesisPlan::new(
            [FormProposal::new(
                form_ref("form:exercise"),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref(context)],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref(context),
                [EffectProposal::new(
                    effect_ref("effect:write-one"),
                    effect_family_ref("family:write"),
                    object_ref("object:one"),
                    context_ref(context),
                )],
                [object_ref("object:one")],
            )],
        )
        .with_initial_control(requirements, applicabilities)
    }

    fn valid_plan() -> GenesisPlan {
        let form = "form:exercise";
        let context = "context:genesis";
        controlled_plan_with_initial_control(
            mandatory_requirement_proposals(form, "family:write", context),
            vec![ApplicabilityProposal::new(
                verifier_ref("verifier:canonical"),
                verifier_family_ref("verifier-family:canonical"),
                requirement_ref("req:form:exercise:form"),
                context_ref(context),
                applicability_rule_ref("applicability:canonical"),
            )],
        )
    }

    fn uncontrolled_plan() -> GenesisPlan {
        GenesisPlan::new(
            [FormProposal::new(
                form_ref("form:information"),
                TransitionClass::Information,
                effect_family_ref("family:read"),
                [context_ref("context:genesis")],
                None,
                AccumulationContract::NotApplicable,
            )],
            [AuthorityProposal::new(
                authority_ref("authority:root"),
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [],
                [object_ref("object:one")],
            )],
        )
    }

    fn assert_rejected_genesis_is_atomic(
        continuity: &AuthorityContinuity,
        premise: &ExternalGenesisPremise,
    ) {
        assert_eq!(continuity.occupancy(), ContinuityOccupancy::Uninhabited);
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
        assert_eq!(continuity.form_count(), 0);
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
        assert_eq!(continuity.verifier_applicability_count(), 0);
    }

    #[test]
    fn valid_t0_constitutes_initial_state_and_consumes_genesis() {
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        continuity.apply_genesis(&mut premise, valid_plan()).unwrap();

        assert_eq!(continuity.occupancy(), ContinuityOccupancy::Inhabited);
        assert!(!continuity.t0_available());
        assert!(premise.is_consumed());
        assert_eq!(continuity.form_count(), 1);
        assert_eq!(continuity.authority_count(), 1);
        assert_eq!(continuity.requirement_set_count(), 1);
        assert_eq!(continuity.verifier_applicability_count(), 1);
        assert!(continuity.form(&form_ref("form:exercise")).is_some());
        assert!(continuity
            .authority(&authority_ref("authority:genesis"))
            .is_some());
        assert!(continuity
            .requirement_set(
                &form_ref("form:exercise"),
                &effect_family_ref("family:write"),
                &context_ref("context:genesis")
            )
            .is_some());
        assert!(continuity
            .verifier_applicability(
                &requirement_ref("req:form:exercise:form"),
                &verifier_ref("verifier:canonical"),
                &context_ref("context:genesis")
            )
            .is_some());
    }

    #[test]
    fn coverage_rule_is_constituted_by_t0_and_bound_to_requirement() {
        let form = "form:exercise";
        let context = "context:genesis";
        let requirement = requirement_ref("req:form:exercise:form");
        let required = verifier_ref("verifier:coverage");
        let rule_reference = coverage_rule_ref("coverage-rule:form");
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements[0] = requirements[0].clone().with_coverage_rule(CoverageRuleProposal::new(
            rule_reference.clone(),
            [required.clone()],
        ));
        let plan = controlled_plan_with_initial_control(
            requirements,
            vec![ApplicabilityProposal::new(
                required.clone(),
                verifier_family_ref("verifier-family:canonical"),
                requirement.clone(),
                context_ref(context),
                applicability_rule_ref("applicability:canonical"),
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        continuity.apply_genesis(&mut premise, plan).unwrap();

        let descriptor = continuity
            .requirement_set(
                &form_ref(form),
                &effect_family_ref("family:write"),
                &context_ref(context),
            )
            .and_then(|set| set.requirement(&requirement))
            .expect("T-0 debe constituir la obligación");
        let rule = descriptor
            .coverage_rule()
            .expect("T-0 debe ligar la regla de cobertura al descriptor");
        assert_eq!(rule.reference(), &rule_reference);
        assert_eq!(rule.requirement(), &requirement);
        assert_eq!(rule.required_verifiers().collect::<Vec<_>>(), vec![&required]);
        assert!(premise.is_consumed());
    }

    #[test]
    fn empty_coverage_required_set_rejects_t0_atomically() {
        let form = "form:exercise";
        let context = "context:genesis";
        let requirement = requirement_ref("req:form:exercise:form");
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements[0] = requirements[0].clone().with_coverage_rule(CoverageRuleProposal::new(
            coverage_rule_ref("coverage-rule:empty"),
            [],
        ));
        let plan = controlled_plan_with_initial_control(requirements, vec![]);
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::EmptyCoverageRequiredVerifierSet(requirement)
            ))
        );
        assert_rejected_genesis_is_atomic(&continuity, &premise);
    }

    #[test]
    fn duplicate_coverage_required_verifier_rejects_t0_atomically() {
        let form = "form:exercise";
        let context = "context:genesis";
        let requirement = requirement_ref("req:form:exercise:form");
        let repeated = verifier_ref("verifier:repeated");
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements[0] = requirements[0].clone().with_coverage_rule(CoverageRuleProposal::new(
            coverage_rule_ref("coverage-rule:duplicate-verifier"),
            [repeated.clone(), repeated.clone()],
        ));
        let plan = controlled_plan_with_initial_control(requirements, vec![]);
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::DuplicateCoverageRequiredVerifier {
                    requirement,
                    verifier: repeated,
                }
            ))
        );
        assert_rejected_genesis_is_atomic(&continuity, &premise);
    }

    #[test]
    fn coverage_required_verifier_without_applicability_rejects_t0_atomically() {
        let form = "form:exercise";
        let context = "context:genesis";
        let requirement = requirement_ref("req:form:exercise:form");
        let missing = verifier_ref("verifier:not-applicable");
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements[0] = requirements[0].clone().with_coverage_rule(CoverageRuleProposal::new(
            coverage_rule_ref("coverage-rule:requires-applicable"),
            [missing.clone()],
        ));
        let plan = controlled_plan_with_initial_control(requirements, vec![]);
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::CoverageVerifierNotApplicable {
                    requirement,
                    verifier: missing,
                }
            ))
        );
        assert_rejected_genesis_is_atomic(&continuity, &premise);
    }

    #[test]
    fn duplicate_coverage_rule_reference_across_requirements_rejects_t0_atomically() {
        let form = "form:exercise";
        let context = "context:genesis";
        let shared = coverage_rule_ref("coverage-rule:shared");
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements[0] = requirements[0].clone().with_coverage_rule(CoverageRuleProposal::new(
            shared.clone(),
            [verifier_ref("verifier:one")],
        ));
        requirements[1] = requirements[1].clone().with_coverage_rule(CoverageRuleProposal::new(
            shared.clone(),
            [verifier_ref("verifier:two")],
        ));
        let plan = controlled_plan_with_initial_control(requirements, vec![]);
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::DuplicateCoverageRuleRef(shared)
            ))
        );
        assert_rejected_genesis_is_atomic(&continuity, &premise);
    }

    #[test]
    fn second_t0_on_the_same_continuity_is_rejected() {
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut first = ExternalGenesisPremise::for_test();
        continuity.apply_genesis(&mut first, valid_plan()).unwrap();

        let mut second = ExternalGenesisPremise::for_test();
        let result = continuity.apply_genesis(&mut second, valid_plan());

        assert_eq!(result, Err(GenesisError::AlreadyInhabited));
        assert!(!second.is_consumed());
        assert_eq!(continuity.form_count(), 1);
        assert_eq!(continuity.requirement_set_count(), 1);
    }

    #[test]
    fn rejected_empty_genesis_does_not_consume_t0_or_premise() {
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, GenesisPlan::new([], []));

        assert_eq!(result, Err(GenesisError::EmptyInitialForms));
        assert_eq!(continuity.occupancy(), ContinuityOccupancy::Uninhabited);
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
        assert_eq!(continuity.form_count(), 0);
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
    }

    #[test]
    fn consumed_external_premise_cannot_seed_another_genesis() {
        let mut first_continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();
        first_continuity
            .apply_genesis(&mut premise, valid_plan())
            .unwrap();

        let mut second_continuity = AuthorityContinuity::uninhabited();
        let result = second_continuity.apply_genesis(&mut premise, valid_plan());

        assert_eq!(result, Err(GenesisError::PremiseAlreadyConsumed));
        assert!(second_continuity.t0_available());
    }

    #[test]
    fn duplicate_form_reference_is_rejected_atomically() {
        let authority = authority_ref("authority:genesis");
        let duplicated = form_ref("form:duplicate");
        let form = || {
            FormProposal::new(
                duplicated.clone(),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref("context:genesis")],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )
        };
        let plan = GenesisPlan::new(
            [form(), form()],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [],
                [object_ref("object:one")],
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(result, Err(GenesisError::DuplicateFormRef(duplicated)));
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
    }

    #[test]
    fn duplicate_authority_reference_is_rejected_atomically() {
        let duplicated = authority_ref("authority:duplicate");
        let authority = || {
            AuthorityProposal::new(
                duplicated.clone(),
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [],
                [object_ref("object:one")],
            )
        };
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref("form:exercise"),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref("context:genesis")],
                Some(duplicated.clone()),
                AccumulationContract::SingleUse,
            )],
            [authority(), authority()],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::DuplicateAuthorityRef(duplicated))
        );
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
    }

    #[test]
    fn authorizing_form_requires_prior_authority_reference() {
        let root = authority_ref("authority:root");
        let form = form_ref("form:govern");
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form.clone(),
                TransitionClass::Governance,
                effect_family_ref("family:govern"),
                [context_ref("context:genesis")],
                None,
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                root,
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [],
                [object_ref("object:one")],
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::AuthorizingFormWithoutRequiredAuthority {
                form,
                class: TransitionClass::Governance,
            })
        );
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
    }

    #[test]
    fn missing_required_authority_is_rejected() {
        let missing = authority_ref("authority:missing");
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref("form:exercise"),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref("context:genesis")],
                Some(missing.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority_ref("authority:other"),
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [],
                [object_ref("object:one")],
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::MissingRequiredAuthority {
                form: form_ref("form:exercise"),
                authority: missing,
            })
        );
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
    }

    #[test]
    fn authority_effect_outside_context_is_rejected_without_partial_state() {
        let authority = authority_ref("authority:genesis");
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref("form:exercise"),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref("context:genesis")],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [EffectProposal::new(
                    effect_ref("effect:write-one"),
                    effect_family_ref("family:write"),
                    object_ref("object:one"),
                    context_ref("context:foreign"),
                )],
                [object_ref("object:one")],
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidAuthorityScope(
                InvalidAuthorityScope::EffectOutsideAuthorityContext
            ))
        );
        assert!(continuity.t0_available());
        assert_eq!(continuity.form_count(), 0);
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
        assert!(!premise.is_consumed());
    }

    #[test]
    fn authority_effect_outside_domain_is_rejected_without_partial_state() {
        let authority = authority_ref("authority:genesis");
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref("form:exercise"),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref("context:genesis")],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [EffectProposal::new(
                    effect_ref("effect:write-one"),
                    effect_family_ref("family:write"),
                    object_ref("object:outside"),
                    context_ref("context:genesis"),
                )],
                [object_ref("object:inside")],
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidAuthorityScope(
                InvalidAuthorityScope::EffectOutsideGovernedDomain
            ))
        );
        assert!(continuity.t0_available());
        assert_eq!(continuity.form_count(), 0);
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
        assert!(!premise.is_consumed());
    }

    #[test]
    fn controlled_form_without_requirements_is_rejected_atomically() {
        let authority = authority_ref("authority:genesis");
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref("form:exercise"),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref("context:genesis")],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [],
                [object_ref("object:one")],
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        let result = continuity.apply_genesis(&mut premise, plan);

        assert!(matches!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::MissingRequirementSet { .. }
            ))
        ));
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
    }

    #[test]
    fn missing_mandatory_core_rejects_whole_genesis() {
        let authority = authority_ref("authority:genesis");
        let form = "form:exercise";
        let context = "context:genesis";
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements.pop();
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref(form),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref(context)],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref(context),
                [],
                [object_ref("object:one")],
            )],
        )
        .with_initial_control(requirements, []);

        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();
        let result = continuity.apply_genesis(&mut premise, plan);

        assert!(matches!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::MissingMandatoryCore { .. }
            ))
        ));
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
    }

    #[test]
    fn applicability_mismatch_rejects_whole_genesis() {
        let authority = authority_ref("authority:genesis");
        let form = "form:exercise";
        let context = "context:genesis";
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref(form),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref(context)],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref(context),
                [],
                [object_ref("object:one")],
            )],
        )
        .with_initial_control(
            mandatory_requirement_proposals(form, "family:write", context),
            [ApplicabilityProposal::new(
                verifier_ref("verifier:bad"),
                verifier_family_ref("verifier-family:wrong"),
                requirement_ref("req:form:exercise:form"),
                context_ref(context),
                applicability_rule_ref("applicability:canonical"),
            )],
        );

        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();
        let result = continuity.apply_genesis(&mut premise, plan);

        assert!(matches!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::ApplicabilityMismatch { .. }
            ))
        ));
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
    }

    #[test]
    fn conflict_rule_without_applicable_decisive_verifier_rejects_t0_atomically() {
        let authority = authority_ref("authority:genesis");
        let form = "form:exercise";
        let context = "context:genesis";
        let requirement = requirement_ref("req:form:exercise:form");
        let decisive = verifier_ref("verifier:decisive");
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements[0] = requirements[0].clone().with_conflict_resolution_rule(
            ConflictResolutionRuleProposal::new(
                conflict_rule_ref("conflict-rule:form"),
                decisive.clone(),
            ),
        );

        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref(form),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref(context)],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref(context),
                [],
                [object_ref("object:one")],
            )],
        )
        .with_initial_control(requirements, []);

        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();
        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::ConflictResolverNotApplicable {
                    requirement,
                    verifier: decisive,
                }
            ))
        );
        assert_eq!(continuity.occupancy(), ContinuityOccupancy::Uninhabited);
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
        assert_eq!(continuity.form_count(), 0);
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
        assert_eq!(continuity.verifier_applicability_count(), 0);
    }

    #[test]
    fn duplicate_conflict_rule_reference_across_requirements_rejects_t0_atomically() {
        let authority = authority_ref("authority:genesis");
        let form = "form:exercise";
        let context = "context:genesis";
        let shared = conflict_rule_ref("conflict-rule:shared");
        let mut requirements = mandatory_requirement_proposals(form, "family:write", context);
        requirements[0] = requirements[0].clone().with_conflict_resolution_rule(
            ConflictResolutionRuleProposal::new(
                shared.clone(),
                verifier_ref("verifier:decisive-one"),
            ),
        );
        requirements[1] = requirements[1].clone().with_conflict_resolution_rule(
            ConflictResolutionRuleProposal::new(
                shared.clone(),
                verifier_ref("verifier:decisive-two"),
            ),
        );

        let plan = GenesisPlan::new(
            [FormProposal::new(
                form_ref(form),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [context_ref(context)],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref(context),
                [],
                [object_ref("object:one")],
            )],
        )
        .with_initial_control(requirements, []);

        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();
        let result = continuity.apply_genesis(&mut premise, plan);

        assert_eq!(
            result,
            Err(GenesisError::InvalidInitialRequirements(
                InitialRequirementError::DuplicateConflictResolutionRuleRef(shared)
            ))
        );
        assert_eq!(continuity.occupancy(), ContinuityOccupancy::Uninhabited);
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
        assert_eq!(continuity.form_count(), 0);
        assert_eq!(continuity.authority_count(), 0);
        assert_eq!(continuity.requirement_set_count(), 0);
        assert_eq!(continuity.verifier_applicability_count(), 0);
    }

    #[test]
    fn uncontrolled_genesis_remains_valid_without_requirements() {
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        continuity
            .apply_genesis(&mut premise, uncontrolled_plan())
            .unwrap();

        assert_eq!(continuity.occupancy(), ContinuityOccupancy::Inhabited);
        assert!(premise.is_consumed());
        assert_eq!(continuity.requirement_set_count(), 0);
    }

    #[test]
    fn controlled_form_without_context_is_rejected_before_constitution() {
        let authority = authority_ref("authority:genesis");
        let form = form_ref("form:exercise");
        let plan = GenesisPlan::new(
            [FormProposal::new(
                form.clone(),
                TransitionClass::Exercise,
                effect_family_ref("family:write"),
                [],
                Some(authority.clone()),
                AccumulationContract::SingleUse,
            )],
            [AuthorityProposal::new(
                authority,
                holder_ref("holder:root"),
                context_ref("context:genesis"),
                [],
                [object_ref("object:one")],
            )],
        );
        let mut continuity = AuthorityContinuity::uninhabited();
        let mut premise = ExternalGenesisPremise::for_test();

        assert_eq!(
            continuity.apply_genesis(&mut premise, plan),
            Err(GenesisError::ControlledFormWithoutContext(form))
        );
        assert!(continuity.t0_available());
        assert!(!premise.is_consumed());
    }

    #[test]
    fn information_verification_enablement_and_exercise_are_non_authorizing() {
        for class in [
            TransitionClass::Information,
            TransitionClass::Verification,
            TransitionClass::Enablement,
            TransitionClass::Exercise,
        ] {
            assert_eq!(
                transition_disposition(class),
                TransitionDisposition::NonAuthorizing
            );
        }
    }

    #[test]
    fn governance_constitutive_and_recovery_remain_non_productive() {
        for class in [
            TransitionClass::Governance,
            TransitionClass::Constitutive,
            TransitionClass::Recovery,
        ] {
            assert_eq!(
                transition_disposition(class),
                TransitionDisposition::BlockedPendingRequirements
            );
        }
    }

    #[test]
    fn only_genesis_has_productive_disposition_in_r1_3_unit_2() {
        assert_eq!(
            transition_disposition(TransitionClass::Genesis),
            TransitionDisposition::GenesisOnly
        );
    }
}

#[cfg(test)]
mod reuse_tests;
