use std::cmp::Ordering;
use std::collections::{BTreeMap, BTreeSet, VecDeque};

use crate::frame::resolved::{
    FrameCandidate, ResolvedArchitecture, ResolvedCoupledState, ResolvedEvalResult,
    ResolvedGateResult, ResolvedSupervisionResult, ResolvedSupervisionTarget,
};
use crate::resolution::resolved::ResolvedTargetState;
use crate::{
    AdmissibilitySpec, Frame, IrObjectKind, IrOperationKind, IrProgram, IrQueryContext,
    IrSupervisableTarget, Nat, ResSpec, Tri,
};

#[derive(Clone, Copy)]
enum Symbol<'a> {
    Object(&'a IrObjectKind),
    Operation(&'a IrOperationKind),
}

struct Symbols<'a> {
    by_name: BTreeMap<&'a str, Symbol<'a>>,
}

impl<'a> Symbols<'a> {
    fn new(program: &'a IrProgram) -> Result<Self, String> {
        let mut by_name = BTreeMap::new();
        for object in program.objects() {
            if by_name
                .insert(object.name(), Symbol::Object(object.kind()))
                .is_some()
            {
                return Err(format!("identificador duplicado: {}", object.name()));
            }
        }
        for operation in program.operations() {
            if by_name
                .insert(operation.name(), Symbol::Operation(operation.kind()))
                .is_some()
            {
                return Err(format!("identificador duplicado: {}", operation.name()));
            }
        }
        Ok(Self { by_name })
    }

    fn object(&self, name: &str) -> Result<&'a IrObjectKind, String> {
        match self.by_name.get(name).copied() {
            Some(Symbol::Object(kind)) => Ok(kind),
            Some(Symbol::Operation(_)) => Err(format!("{name} no es un objeto declarado")),
            None => Err(format!("referencia no declarada: {name}")),
        }
    }

    fn operation(&self, name: &str) -> Result<&'a IrOperationKind, String> {
        match self.by_name.get(name).copied() {
            Some(Symbol::Operation(kind)) => Ok(kind),
            Some(Symbol::Object(_)) => Err(format!("{name} no es un resultado de operación")),
            None => Err(format!("referencia no declarada: {name}")),
        }
    }
}

pub(crate) fn validate_program(program: &IrProgram) -> Result<(), String> {
    let symbols = Symbols::new(program)?;
    for object in program.objects() {
        validate_object(object.name(), object.kind(), &symbols)?;
    }
    for operation in program.operations() {
        validate_operation(operation.name(), operation.kind(), &symbols)?;
    }
    // N0-03: conservar la precedencia de los rechazos relacionales N0-02.
    for object in program.objects() {
        if let IrObjectKind::OutputSemantics { mappings } = object.kind() {
            let mut seen = BTreeSet::new();
            let mut duplicates = BTreeSet::new();
            for (key, _) in mappings {
                if !seen.insert(key.as_str()) {
                    duplicates.insert(key.as_str());
                }
            }
            if !duplicates.is_empty() {
                return Err(format!(
                    "E115 (InvalidOutputSemantics): OutputSemantics {}: repetidas=[{}]",
                    object.name(),
                    duplicates.into_iter().collect::<Vec<_>>().join(", "),
                ));
            }
        }
    }
    // N0-04: resolver sobre el programa completo, sin desplazar rechazos previos.
    for object in program.objects() {
        if let IrObjectKind::Horizon { architecture, .. } = object.kind() {
            expect_object(&symbols, architecture, "CompositionGraph", |kind|
                matches!(kind, IrObjectKind::CompositionGraph { .. }))?;
        }
    }
    // J-H1: Horizon enumerates declared event types, not their occurrences.
    // Preserve earlier diagnostics and reject repetition without normalizing.
    for object in program.objects() {
        if let IrObjectKind::Horizon { events, .. } = object.kind() {
            let mut seen = BTreeSet::new();
            for event in events {
                if !seen.insert(event.as_str()) {
                    return Err(format!("Horizon {}: tipo de suceso repetido: {event}", object.name()));
                }
            }
        }
    }
    // J-D0: local nominal identity; no inferred (cell, position) or numeric binding.
    // Preserve the previous diagnostics and the original order in the IR.
    for object in program.objects() {
        if let IrObjectKind::Domain { parameters, .. } = object.kind() {
            let mut seen = BTreeSet::new();
            for parameter in parameters {
                if !seen.insert(parameter.as_str()) {
                    return Err(format!("Domain {}: parámetro nominal repetido: {parameter}", object.name()));
                }
            }
        }
    }
    Ok(())
}

fn validate_object(name: &str, kind: &IrObjectKind, symbols: &Symbols<'_>) -> Result<(), String> {
    match kind {
        IrObjectKind::Codomain { values } => {
            if values.is_empty() {
                return Err(format!(
                    "E004 (InvalidCodomain): codomain {name} vacío"
                ));
            }
            let mut seen = BTreeSet::new();
            let mut duplicates = BTreeSet::new();
            for value in values {
                if !seen.insert(value.as_str()) {
                    duplicates.insert(value.as_str());
                }
            }
            if !duplicates.is_empty() {
                return Err(format!(
                    "E004 (InvalidCodomain): codomain {name} repite: {}",
                    duplicates.into_iter().collect::<Vec<_>>().join(", ")
                ));
            }
        }
        IrObjectKind::OutputSemantics { .. } => {}
        IrObjectKind::CellSpec {
            b,
            codomain,
            semantics,
            role,
            ..
        } => {
            if nat_cmp_text(b, "3") == Ordering::Less {
                return Err(format!("CellSpec {name}: b debe ser >= 3"));
            }
            let codomain_kind = expect_object(symbols, codomain, "Codomain", |k| matches!(k, IrObjectKind::Codomain { .. }))?;
            let semantics_kind = expect_object(symbols, semantics, "OutputSemantics", |k| matches!(k, IrObjectKind::OutputSemantics { .. }))?;
            if !matches!(role.as_str(), "Base" | "Supervisor" | "Composite") {
                return Err(format!("CellSpec {name}: rol no reconocido: {role}"));
            }
            let expected: BTreeSet<&str> = match codomain_kind {
                IrObjectKind::Codomain { values } => values.iter().map(String::as_str).collect(),
                _ => unreachable!(),
            };
            let mappings = match semantics_kind {
                IrObjectKind::OutputSemantics { mappings } => mappings,
                _ => unreachable!(),
            };
            let mut seen = BTreeSet::new();
            let mut duplicates = BTreeSet::new();
            for (key, _) in mappings {
                if !seen.insert(key.as_str()) {
                    duplicates.insert(key.as_str());
                }
            }
            let missing: Vec<_> = expected.difference(&seen).copied().collect();
            let extra: Vec<_> = seen.difference(&expected).copied().collect();
            if !duplicates.is_empty() || !missing.is_empty() || !extra.is_empty() {
                return Err(format!(
                    "E115 (InvalidOutputSemantics): CellSpec {name}, OutputSemantics {semantics}, Codomain {codomain}: repetidas=[{}]; ausentes=[{}]; ajenas=[{}]",
                    duplicates.into_iter().collect::<Vec<_>>().join(", "),
                    missing.join(", "),
                    extra.join(", "),
                ));
            }
        }
        IrObjectKind::CoupledSpec { cell, bridges } => {
            let cell = expect_object(symbols, cell, "CellSpec", |k| matches!(k, IrObjectKind::CellSpec { .. }))?;
            let n = match cell { IrObjectKind::CellSpec { n, .. } => n, _ => unreachable!() };
            for position in bridges {
                if nat_is_zero(position) || nat_cmp(position, n) == Ordering::Greater {
                    return Err(format!("CoupledSpec {name}: posición puente fuera de rango"));
                }
            }
            // J1.2: BridgeSet is a set of Nat values. Reject repetition;
            // do not deduplicate or reorder the declared positions.
            let mut seen = BTreeSet::new();
            for position in bridges {
                if !seen.insert(position.as_decimal()) {
                    return Err(format!("CoupledSpec {name}: posición puente repetida: {}", position.as_decimal()));
                }
            }
        }
        IrObjectKind::Connector { source_codomain, mapping, .. } => {
            let codomain = expect_object(symbols, source_codomain, "Codomain", |k| matches!(k, IrObjectKind::Codomain { .. }))?;
            let expected: BTreeSet<&str> = match codomain {
                IrObjectKind::Codomain { values } => values.iter().map(String::as_str).collect(),
                _ => unreachable!(),
            };
            let mut seen = BTreeSet::new();
            for (key, _) in mapping {
                if !seen.insert(key.as_str()) {
                    return Err(format!("Connector {name}: clave duplicada"));
                }
            }
            if seen != expected {
                return Err(format!("Connector {name}: mapping incompleto o inconsistente"));
            }
        }
        IrObjectKind::AdmissibilityTable { input_codomains, output_codomain, table } => {
            validate_admissibility_table(name, input_codomains, output_codomain, table, symbols)?;
        }
        IrObjectKind::CaptureSpec { parameter_id, observation_space, failure_symbol, .. } => {
            if nat_is_zero(parameter_id) || observation_space.is_empty() || failure_symbol != "Bottom" {
                return Err(format!("CaptureSpec {name}: definición no canónica"));
            }
        }
        IrObjectKind::AdmissibilitySpec { parameter_id, states, rule } => {
            let labels: BTreeSet<&str> = states.iter().map(|state| state.label()).collect();
            if labels != BTreeSet::from(["Ok", "Degraded", "NotAdmitted"]) {
                return Err(format!("AdmissibilitySpec {name}: estados no canónicos"));
            }
            AdmissibilitySpec::new(name, parameter_id.clone(), rule.clone())
                .map_err(|error| format!("AdmissibilitySpec {name}: {error:?}"))?;
        }
        IrObjectKind::Ternarizer { observation_space, partition_zero, partition_one, partition_u, .. } => {
            if observation_space.is_empty() || partition_zero.is_empty() || partition_one.is_empty() || partition_u.is_empty() {
                return Err(format!("Ternarizer {name}: definición incompleta"));
            }
        }
        IrObjectKind::ResSpec { .. } => {}
        IrObjectKind::CellState { spec, vector } => {
            let cell = expect_object(symbols, spec, "CellSpec", |k| matches!(k, IrObjectKind::CellSpec { .. }))?;
            let n = match cell { IrObjectKind::CellSpec { n, .. } => n, _ => unreachable!() };
            if !nat_eq_usize(n, vector.len()) {
                return Err(format!("CellState {name}: longitud de vector incompatible"));
            }
        }
        IrObjectKind::CoupledState { spec, base_vector, updated_vector } => {
            validate_coupled_state(name, spec, base_vector, updated_vector, symbols)?;
        }
        IrObjectKind::CompositionGraph { nodes, edges, relation, regime } => {
            validate_graph(name, nodes, edges, relation, regime, symbols)?;
        }
        IrObjectKind::SemanticRelation { .. } | IrObjectKind::Pattern { .. } => {}
        IrObjectKind::Horizon { architecture, events } => {
            if architecture.is_empty() || events.is_empty() {
                return Err(format!("Horizon {name}: definición incompleta"));
            }
        }
        IrObjectKind::Frame {
            index,
            architecture,
            cell_states,
            eval_results,
            gate_results,
            supervision,
            criticalities,
        } => validate_frame_via_c03(
            name,
            index,
            architecture,
            cell_states,
            eval_results,
            gate_results,
            supervision,
            criticalities,
            symbols,
        )?,
        IrObjectKind::TransitionData { horizon_ref, events, induced_parameters, .. } => {
            let horizon = expect_object(symbols, horizon_ref, "Horizon", |k| matches!(k, IrObjectKind::Horizon { .. }))?;
            let declared: BTreeSet<&str> = match horizon {
                IrObjectKind::Horizon { events, .. } => events.iter().map(String::as_str).collect(),
                _ => unreachable!(),
            };
            if events.iter().any(|(event, _)| !declared.contains(event.as_str())) {
                return Err(format!("TransitionData {name}: suceso fuera del Horizon"));
            }
            if induced_parameters.is_empty() {
                return Err(format!("TransitionData {name}: induced_parameters vacío"));
            }
        }
        IrObjectKind::Trajectory { entries } => {
            if entries.is_empty() {
                return Err(format!("Trajectory {name}: entries vacío"));
            }
            let last = entries.len() - 1;
            for (index, (frame, transition)) in entries.iter().enumerate() {
                expect_object(symbols, frame, "Frame", |k| matches!(k, IrObjectKind::Frame { .. }))?;
                if index < last && transition.is_none() {
                    return Err(format!("Trajectory {name}: entrada no final sin transición"));
                }
                if index == last && transition.is_some() {
                    return Err(format!("Trajectory {name}: última entrada con transición"));
                }
                if let Some(transition) = transition {
                    expect_object(symbols, transition, "TransitionData", |k| matches!(k, IrObjectKind::TransitionData { .. }))?;
                }
            }
        }
        IrObjectKind::Domain { horizon, capture_specs, admissibility_specs, ternarizers, .. } => {
            validate_domain(name, horizon, capture_specs, admissibility_specs, ternarizers, symbols)?;
        }
        IrObjectKind::Agent { architecture, domain, .. } => {
            let domain = expect_object(symbols, domain, "Domain", |k| matches!(k, IrObjectKind::Domain { .. }))?;
            let horizon_name = match domain { IrObjectKind::Domain { horizon, .. } => horizon, _ => unreachable!() };
            let horizon = expect_object(symbols, horizon_name, "Horizon", |k| matches!(k, IrObjectKind::Horizon { .. }))?;
            let domain_architecture = match horizon { IrObjectKind::Horizon { architecture, .. } => architecture, _ => unreachable!() };
            if architecture != domain_architecture {
                return Err(format!("Agent {name}: architecture incompatible con Domain"));
            }
        }
        IrObjectKind::QuerySpec { query_type, scope, .. } => {
            if query_type == "PendingU" {
                return Err(format!("QuerySpec {name}: PendingU no habilitado"));
            }
            let expected_scope = match query_type.as_str() {
                "PointEvaluation" => "Cell",
                "TrajectoryState" => "Trajectory",
                "FrameComparison" => "Pair",
                "CoverageState" | "GlobalCriticality" => "Architecture",
                _ => return Err(format!("QuerySpec {name}: query_type no reconocido")),
            };
            if scope != expected_scope {
                return Err(format!("QuerySpec {name}: scope incompatible"));
            }
        }
    }
    Ok(())
}

fn validate_admissibility_table(
    name: &str,
    input_codomains: &[String],
    output_codomain: &str,
    table: &[(Vec<String>, String)],
    symbols: &Symbols<'_>,
) -> Result<(), String> {
    let mut domains = Vec::with_capacity(input_codomains.len());
    for codomain in input_codomains {
        let kind = expect_object(symbols, codomain, "Codomain", |k| matches!(k, IrObjectKind::Codomain { .. }))?;
        let values = match kind { IrObjectKind::Codomain { values } => values, _ => unreachable!() };
        domains.push(values);
    }
    let out = expect_object(symbols, output_codomain, "Codomain", |k| matches!(k, IrObjectKind::Codomain { .. }))?;
    let out_values: BTreeSet<&str> = match out {
        IrObjectKind::Codomain { values } => values.iter().map(String::as_str).collect(),
        _ => unreachable!(),
    };
    let Some(expected_count) = domains.iter().try_fold(1usize, |acc, values| acc.checked_mul(values.len())) else {
        return Err(format!("AdmissibilityTable {name}: cardinalidad no representable"));
    };
    let domain_sets: Vec<BTreeSet<&str>> = domains.iter().map(|v| v.iter().map(String::as_str).collect()).collect();
    let mut seen = BTreeSet::new();
    for (inputs, output) in table {
        if inputs.len() != domain_sets.len() {
            return Err(format!("AdmissibilityTable {name}: aridad incompatible"));
        }
        if inputs.iter().enumerate().any(|(i, value)| !domain_sets[i].contains(value.as_str())) {
            return Err(format!("AdmissibilityTable {name}: entrada fuera de codominio"));
        }
        if !out_values.contains(output.as_str()) {
            return Err(format!("AdmissibilityTable {name}: salida fuera de codominio"));
        }
        if !seen.insert(inputs.clone()) {
            return Err(format!("AdmissibilityTable {name}: fila duplicada"));
        }
    }
    if seen.len() != expected_count {
        return Err(format!("AdmissibilityTable {name}: tabla incompleta"));
    }
    Ok(())
}

fn validate_coupled_state(
    name: &str,
    spec: &str,
    base_vector: &[Tri],
    updated_vector: &[Tri],
    symbols: &Symbols<'_>,
) -> Result<(), String> {
    let coupled = expect_object(symbols, spec, "CoupledSpec", |k| matches!(k, IrObjectKind::CoupledSpec { .. }))?;
    let (cell_name, bridges) = match coupled { IrObjectKind::CoupledSpec { cell, bridges } => (cell, bridges), _ => unreachable!() };
    let cell = expect_object(symbols, cell_name, "CellSpec", |k| matches!(k, IrObjectKind::CellSpec { .. }))?;
    let n = match cell { IrObjectKind::CellSpec { n, .. } => n, _ => unreachable!() };
    if !nat_eq_usize(n, base_vector.len()) || !nat_eq_usize(n, updated_vector.len()) {
        return Err(format!("CoupledState {name}: longitud incompatible"));
    }
    let bridge_set: BTreeSet<&str> = bridges.iter().map(Nat::as_decimal).collect();
    for (index, (before, after)) in base_vector.iter().zip(updated_vector).enumerate() {
        if before != after && !bridge_set.contains((index + 1).to_string().as_str()) {
            return Err(format!("CoupledState {name}: actualización fuera de BridgeSet"));
        }
    }
    Ok(())
}

fn validate_graph(
    name: &str,
    nodes: &[String],
    edges: &[(String, String, Nat, String)],
    relation: &str,
    regime: &str,
    symbols: &Symbols<'_>,
) -> Result<(), String> {
    expect_object(symbols, relation, "SemanticRelation", |k| matches!(k, IrObjectKind::SemanticRelation { .. }))?;
    for node in nodes {
        expect_object(symbols, node, "CoupledSpec", |k| matches!(k, IrObjectKind::CoupledSpec { .. }))?;
    }
    let node_set: BTreeSet<&str> = nodes.iter().map(String::as_str).collect();
    let mut simple_targets = BTreeSet::new();
    let mut indegree: BTreeMap<&str, usize> = node_set.iter().map(|n| (*n, 0)).collect();
    let mut adjacency: BTreeMap<&str, Vec<&str>> = node_set.iter().map(|n| (*n, Vec::new())).collect();

    for (source, target, position, connector_name) in edges {
        if !node_set.contains(source.as_str()) || !node_set.contains(target.as_str()) {
            return Err(format!("Graph {name}: arista fuera del conjunto de nodos"));
        }
        let connector = expect_object(symbols, connector_name, "Connector", |k| matches!(k, IrObjectKind::Connector { .. }))?;
        let source_spec = symbols.object(source)?;
        let target_spec = symbols.object(target)?;
        let (source_cell_name, target_bridges) = match (source_spec, target_spec) {
            (IrObjectKind::CoupledSpec { cell, .. }, IrObjectKind::CoupledSpec { bridges, .. }) => (cell, bridges),
            _ => return Err(format!("Graph {name}: nodo no CoupledSpec")),
        };
        if !target_bridges.iter().any(|bridge| bridge == position) {
            return Err(format!("Graph {name}: posición fuera de BridgeSet"));
        }
        let (connector_codomain, connector_position) = match connector {
            IrObjectKind::Connector { source_codomain, target_position, .. } => (source_codomain, target_position),
            _ => unreachable!(),
        };
        if connector_position != position {
            return Err(format!("Graph {name}: target_position incompatible"));
        }
        let source_cell = expect_object(symbols, source_cell_name, "CellSpec", |k| matches!(k, IrObjectKind::CellSpec { .. }))?;
        let source_codomain = match source_cell { IrObjectKind::CellSpec { codomain, .. } => codomain, _ => unreachable!() };
        if connector_codomain != source_codomain {
            return Err(format!("Graph {name}: source_codomain incompatible"));
        }
        adjacency.get_mut(source.as_str()).unwrap().push(target.as_str());
        *indegree.get_mut(target.as_str()).unwrap() += 1;
        if regime == "Simple" && !simple_targets.insert((target.as_str(), position.as_decimal().to_owned())) {
            return Err(format!("Graph {name}: concurrencia en régimen Simple"));
        }
    }

    let mut queue: VecDeque<&str> = indegree.iter().filter_map(|(node, degree)| (*degree == 0).then_some(*node)).collect();
    let mut visited = 0usize;
    while let Some(node) = queue.pop_front() {
        visited += 1;
        if let Some(targets) = adjacency.get(node) {
            for target in targets {
                let degree = indegree.get_mut(target).unwrap();
                *degree -= 1;
                if *degree == 0 { queue.push_back(target); }
            }
        }
    }
    if visited != node_set.len() {
        return Err(format!("Graph {name}: ciclo detectado"));
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn validate_frame_via_c03(
    name: &str,
    index: &Nat,
    architecture: &str,
    cell_states: &[String],
    eval_results: &[String],
    gate_results: &[String],
    supervision: &[String],
    criticalities: &[String],
    symbols: &Symbols<'_>,
) -> Result<(), String> {
    let graph = expect_object(symbols, architecture, "CompositionGraph", |k| matches!(k, IrObjectKind::CompositionGraph { .. }))?;
    let nodes = match graph { IrObjectKind::CompositionGraph { nodes, .. } => nodes.clone(), _ => unreachable!() };
    let architecture = ResolvedArchitecture::new(architecture, nodes);

    let mut states = Vec::with_capacity(cell_states.len());
    for reference in cell_states {
        let state = expect_object(symbols, reference, "CoupledState", |k| matches!(k, IrObjectKind::CoupledState { .. }))?;
        let spec = match state { IrObjectKind::CoupledState { spec, .. } => spec.clone(), _ => unreachable!() };
        states.push(ResolvedCoupledState::new(reference, spec));
    }

    let mut evals = Vec::with_capacity(eval_results.len());
    for reference in eval_results {
        let operation = symbols.operation(reference)?;
        let source = match operation {
            IrOperationKind::Evaluate { state } => state.clone(),
            _ => return Err(format!("Frame {name}: eval_results contiene no-Evaluate")),
        };
        evals.push(ResolvedEvalResult::new(reference, source));
    }

    let mut gates = Vec::with_capacity(gate_results.len());
    for reference in gate_results {
        let operation = symbols.operation(reference)?;
        let inputs = match operation {
            IrOperationKind::Gate { eval_results, .. } => eval_results.clone(),
            _ => return Err(format!("Frame {name}: gate_results contiene no-Gate")),
        };
        gates.push(ResolvedGateResult::new(reference, inputs));
    }

    let mut supervisions = Vec::with_capacity(supervision.len());
    for reference in supervision {
        let operation = symbols.operation(reference)?;
        let (meta_eval, target) = match operation {
            IrOperationKind::Supervise { meta_eval, target } => (meta_eval.clone(), target),
            _ => return Err(format!("Frame {name}: supervision contiene no-Supervise")),
        };
        let target = match target {
            IrSupervisableTarget::Cell { reference } => ResolvedSupervisionTarget::cell(reference),
            IrSupervisableTarget::Composed { reference } => ResolvedSupervisionTarget::composed(reference),
            IrSupervisableTarget::System { reference } => ResolvedSupervisionTarget::system(reference),
        };
        supervisions.push(ResolvedSupervisionResult::new(reference, meta_eval, target));
    }

    let candidate = FrameCandidate::new(name, index.clone(), architecture)
        .with_cell_states(states)
        .with_eval_results(evals)
        .with_gate_results(gates)
        .with_supervision(supervisions)
        .with_criticalities(criticalities.to_vec());

    Frame::from_candidate(candidate)
        .map(|_| ())
        .map_err(|error| format!("Frame {name}: {error:?}"))
}

fn validate_domain(
    name: &str,
    horizon: &str,
    capture_specs: &[String],
    admissibility_specs: &[String],
    ternarizers: &[String],
    symbols: &Symbols<'_>,
) -> Result<(), String> {
    expect_object(symbols, horizon, "Horizon", |k| matches!(k, IrObjectKind::Horizon { .. }))?;
    if capture_specs.is_empty() || admissibility_specs.is_empty() || ternarizers.is_empty() {
        return Err(format!("Domain {name}: cadenas de constitución vacías"));
    }
    let mut capture_ids = BTreeSet::new();
    let mut capture_spaces = BTreeSet::new();
    for reference in capture_specs {
        let kind = expect_object(symbols, reference, "CaptureSpec", |k| matches!(k, IrObjectKind::CaptureSpec { .. }))?;
        if let IrObjectKind::CaptureSpec { parameter_id, observation_space, .. } = kind {
            capture_ids.insert(parameter_id.as_decimal());
            capture_spaces.insert(observation_space.as_str());
        }
    }
    let mut admissibility_ids = BTreeSet::new();
    for reference in admissibility_specs {
        let kind = expect_object(symbols, reference, "AdmissibilitySpec", |k| matches!(k, IrObjectKind::AdmissibilitySpec { .. }))?;
        if let IrObjectKind::AdmissibilitySpec { parameter_id, .. } = kind {
            admissibility_ids.insert(parameter_id.as_decimal());
        }
    }
    if capture_ids != admissibility_ids {
        return Err(format!("Domain {name}: parameter_id incompatibles"));
    }
    let mut ternarizer_spaces = BTreeSet::new();
    for reference in ternarizers {
        let kind = expect_object(symbols, reference, "Ternarizer", |k| matches!(k, IrObjectKind::Ternarizer { .. }))?;
        if let IrObjectKind::Ternarizer { observation_space, .. } = kind {
            ternarizer_spaces.insert(observation_space.as_str());
        }
    }
    if !capture_spaces.is_subset(&ternarizer_spaces) {
        return Err(format!("Domain {name}: observation_space sin Ternarizer"));
    }
    Ok(())
}

fn validate_operation(name: &str, kind: &IrOperationKind, symbols: &Symbols<'_>) -> Result<(), String> {
    match kind {
        IrOperationKind::Evaluate { state } => {
            if !matches!(symbols.object(state)?, IrObjectKind::CellState { .. } | IrObjectKind::CoupledState { .. }) {
                return Err(format!("Evaluate {name}: fuente no evaluable"));
            }
        }
        IrOperationKind::Gate { eval_results, table } => validate_gate(name, eval_results, table, symbols)?,
        IrOperationKind::Resolve { target_state, target_position, with_spec, context_instance, mechanism_instance } => {
            validate_resolve_via_c02(name, target_state, target_position, with_spec, context_instance, mechanism_instance, symbols)?;
        }
        IrOperationKind::Query { spec, by, context } => validate_query(name, spec, by, context, symbols)?,
        IrOperationKind::Supervise { meta_eval, target } => validate_supervise(name, meta_eval, target, symbols)?,
        IrOperationKind::Compose { graph, relations, patterns } => {
            expect_object(symbols, graph, "CompositionGraph", |k| matches!(k, IrObjectKind::CompositionGraph { .. }))?;
            if relations.is_empty() || patterns.is_empty() {
                return Err(format!("Compose {name}: relations/patterns no puede estar vacío"));
            }
            for relation in relations {
                expect_object(symbols, relation, "SemanticRelation", |k| matches!(k, IrObjectKind::SemanticRelation { .. }))?;
            }
            for pattern in patterns {
                expect_object(symbols, pattern, "Pattern", |k| matches!(k, IrObjectKind::Pattern { .. }))?;
            }
        }
        IrOperationKind::Projection { source, field } => {
            let source_kind = symbols.operation(source)?;
            let allowed: &[&str] = match source_kind {
                IrOperationKind::Evaluate { .. } => &["source_state", "counts", "threshold", "classification", "criticality", "deltas"],
                IrOperationKind::Gate { .. } => &["inputs", "table", "output"],
                IrOperationKind::Resolve { .. } => &["target", "previous", "reviewed_to", "resolved_to", "context_ref", "mechanism_ref"],
                IrOperationKind::Query { .. } => &["response", "justification", "metadata"],
                IrOperationKind::Supervise { .. } => &["meta_eval", "target", "verdict"],
                IrOperationKind::Compose { .. } | IrOperationKind::Projection { .. } => return Err(format!("Projection {name}: fuente no proyectable")),
            };
            if !allowed.contains(&field.as_str()) {
                return Err(format!("Projection {name}: campo inexistente"));
            }
        }
    }
    Ok(())
}

fn validate_gate(name: &str, eval_results: &[String], table: &str, symbols: &Symbols<'_>) -> Result<(), String> {
    let table = expect_object(symbols, table, "AdmissibilityTable", |k| matches!(k, IrObjectKind::AdmissibilityTable { .. }))?;
    let expected = match table { IrObjectKind::AdmissibilityTable { input_codomains, .. } => input_codomains, _ => unreachable!() };
    if eval_results.len() != expected.len() {
        return Err(format!("Gate {name}: número de entradas incompatible"));
    }
    let mut actual = Vec::with_capacity(eval_results.len());
    for input in eval_results {
        let operation = symbols.operation(input)?;
        if !matches!(operation, IrOperationKind::Evaluate { .. }) {
            return Err(format!("Gate {name}: entrada no EvalResult"));
        }
        actual.push(codomain_of_eval(operation, symbols).ok_or_else(|| format!("Gate {name}: codominio indeterminado"))?);
    }
    if actual.iter().map(String::as_str).ne(expected.iter().map(String::as_str)) {
        return Err(format!("Gate {name}: codominios posicionales incompatibles"));
    }
    Ok(())
}

fn codomain_of_eval(kind: &IrOperationKind, symbols: &Symbols<'_>) -> Option<String> {
    let state = match kind { IrOperationKind::Evaluate { state } => state, _ => return None };
    match symbols.object(state).ok()? {
        IrObjectKind::CellState { spec, .. } => match symbols.object(spec).ok()? {
            IrObjectKind::CellSpec { codomain, .. } => Some(codomain.clone()), _ => None,
        },
        IrObjectKind::CoupledState { spec, .. } => match symbols.object(spec).ok()? {
            IrObjectKind::CoupledSpec { cell, .. } => match symbols.object(cell).ok()? {
                IrObjectKind::CellSpec { codomain, .. } => Some(codomain.clone()), _ => None,
            },
            _ => None,
        },
        _ => None,
    }
}

#[allow(clippy::too_many_arguments)]
fn validate_resolve_via_c02(
    name: &str,
    target_state: &str,
    target_position: &Nat,
    with_spec: &str,
    context_instance: &str,
    mechanism_instance: &str,
    symbols: &Symbols<'_>,
) -> Result<(), String> {
    let spec_kind = expect_object(symbols, with_spec, "ResSpec", |k| matches!(k, IrObjectKind::ResSpec { .. }))?;
    let (context, mechanism, mapping) = match spec_kind {
        IrObjectKind::ResSpec { context, mechanism, mapping } => (context, mechanism, mapping),
        _ => unreachable!(),
    };
    let spec = ResSpec::new(with_spec, context, mechanism, mapping);
    let state_kind = symbols.object(target_state)?;
    let state = match state_kind {
        IrObjectKind::CellState { vector, .. } => ResolvedTargetState::cell(target_state, vector.clone()),
        IrObjectKind::CoupledState { updated_vector, .. } => ResolvedTargetState::coupled(target_state, updated_vector.clone()),
        other => ResolvedTargetState::other(target_state, ir_kind_label(other)),
    };
    crate::resolution::review_u(
        &state,
        target_position.clone(),
        &spec,
        context_instance,
        mechanism_instance,
        None,
    )
    .map(|_| ())
    .map_err(|error| format!("Resolve {name}: {error:?}"))
}

fn ir_kind_label(kind: &IrObjectKind) -> &'static str {
    match kind {
        IrObjectKind::Codomain { .. } => "Codomain",
        IrObjectKind::OutputSemantics { .. } => "OutputSemantics",
        IrObjectKind::CellSpec { .. } => "CellSpec",
        IrObjectKind::CoupledSpec { .. } => "CoupledSpec",
        IrObjectKind::Connector { .. } => "Connector",
        IrObjectKind::AdmissibilityTable { .. } => "AdmissibilityTable",
        IrObjectKind::CaptureSpec { .. } => "CaptureSpec",
        IrObjectKind::AdmissibilitySpec { .. } => "AdmissibilitySpec",
        IrObjectKind::Ternarizer { .. } => "Ternarizer",
        IrObjectKind::ResSpec { .. } => "ResSpec",
        IrObjectKind::CellState { .. } => "CellState",
        IrObjectKind::CoupledState { .. } => "CoupledState",
        IrObjectKind::CompositionGraph { .. } => "CompositionGraph",
        IrObjectKind::SemanticRelation { .. } => "SemanticRelation",
        IrObjectKind::Pattern { .. } => "Pattern",
        IrObjectKind::Horizon { .. } => "Horizon",
        IrObjectKind::Frame { .. } => "Frame",
        IrObjectKind::TransitionData { .. } => "TransitionData",
        IrObjectKind::Trajectory { .. } => "Trajectory",
        IrObjectKind::Domain { .. } => "Domain",
        IrObjectKind::Agent { .. } => "Agent",
        IrObjectKind::QuerySpec { .. } => "QuerySpec",
    }
}

fn validate_query(name: &str, spec: &str, by: &str, context: &IrQueryContext, symbols: &Symbols<'_>) -> Result<(), String> {
    let spec = expect_object(symbols, spec, "QuerySpec", |k| matches!(k, IrObjectKind::QuerySpec { .. }))?;
    let query_type = match spec { IrObjectKind::QuerySpec { query_type, .. } => query_type, _ => unreachable!() };
    let agent = expect_object(symbols, by, "Agent", |k| matches!(k, IrObjectKind::Agent { .. }))?;
    let (agent_architecture, agent_domain) = match agent { IrObjectKind::Agent { architecture, domain, .. } => (architecture, domain), _ => unreachable!() };
    let actual_type = match context {
        IrQueryContext::PointEval { reference } => {
            expect_object(symbols, reference, "Frame", |k| matches!(k, IrObjectKind::Frame { .. }))?; "PointEvaluation"
        }
        IrQueryContext::TrajectoryView { reference } => {
            expect_object(symbols, reference, "Trajectory", |k| matches!(k, IrObjectKind::Trajectory { .. }))?; "TrajectoryState"
        }
        IrQueryContext::FrameComparison { references } => {
            for reference in references { expect_object(symbols, reference, "Frame", |k| matches!(k, IrObjectKind::Frame { .. }))?; }
            "FrameComparison"
        }
        IrQueryContext::ArchitectureView { architecture, cells, evals, gates } => {
            if architecture != agent_architecture { return Err(format!("Query {name}: ArchitectureView fuera del Agent")); }
            for reference in cells { expect_object(symbols, reference, "CellSpec", |k| matches!(k, IrObjectKind::CellSpec { .. }))?; }
            for reference in evals { if !matches!(symbols.operation(reference)?, IrOperationKind::Evaluate { .. }) { return Err(format!("Query {name}: eval no EvalResult")); } }
            for reference in gates { if !matches!(symbols.operation(reference)?, IrOperationKind::Gate { .. }) { return Err(format!("Query {name}: gate no GateResult")); } }
            "GlobalCriticality"
        }
        IrQueryContext::CoverageReport { references } => {
            expect_object(symbols, &references[0], "Domain", |k| matches!(k, IrObjectKind::Domain { .. }))?;
            if &references[0] != agent_domain { return Err(format!("Query {name}: CoverageReport fuera del Agent")); }
            "CoverageState"
        }
    };
    if query_type != actual_type { return Err(format!("Query {name}: QueryContext incompatible con QuerySpec")); }
    Ok(())
}

fn validate_supervise(name: &str, meta_eval: &str, target: &IrSupervisableTarget, symbols: &Symbols<'_>) -> Result<(), String> {
    let meta = symbols.operation(meta_eval)?;
    let state = match meta { IrOperationKind::Evaluate { state } => state, _ => return Err(format!("Supervise {name}: meta_eval no EvalResult")) };
    match target {
        IrSupervisableTarget::Cell { reference } => if !matches!(symbols.operation(reference)?, IrOperationKind::Evaluate { .. }) { return Err(format!("Supervise {name}: CellTarget de tipo incorrecto")); },
        IrSupervisableTarget::Composed { reference } => if !matches!(symbols.operation(reference)?, IrOperationKind::Gate { .. }) { return Err(format!("Supervise {name}: ComposedTarget de tipo incorrecto")); },
        IrSupervisableTarget::System { reference } => { expect_object(symbols, reference, "CompositionGraph", |k| matches!(k, IrObjectKind::CompositionGraph { .. }))?; }
    }
    if role_of_state(state, symbols) != Some("Supervisor") {
        return Err(format!("Supervise {name}: meta_eval no procede de Supervisor"));
    }
    Ok(())
}

fn role_of_state<'a>(state: &str, symbols: &'a Symbols<'a>) -> Option<&'a str> {
    match symbols.object(state).ok()? {
        IrObjectKind::CellState { spec, .. } => match symbols.object(spec).ok()? { IrObjectKind::CellSpec { role, .. } => Some(role), _ => None },
        IrObjectKind::CoupledState { spec, .. } => match symbols.object(spec).ok()? {
            IrObjectKind::CoupledSpec { cell, .. } => match symbols.object(cell).ok()? { IrObjectKind::CellSpec { role, .. } => Some(role), _ => None },
            _ => None,
        },
        _ => None,
    }
}

fn expect_object<'a, F>(symbols: &'a Symbols<'a>, name: &str, expected: &str, predicate: F) -> Result<&'a IrObjectKind, String>
where
    F: FnOnce(&IrObjectKind) -> bool,
{
    let kind = symbols.object(name)?;
    if predicate(kind) { Ok(kind) } else { Err(format!("{name}: se esperaba {expected}")) }
}

fn nat_is_zero(value: &Nat) -> bool { value.as_decimal() == "0" }
fn nat_cmp(left: &Nat, right: &Nat) -> Ordering { decimal_cmp(left.as_decimal(), right.as_decimal()) }
fn nat_cmp_text(left: &Nat, right: &str) -> Ordering { decimal_cmp(left.as_decimal(), right) }
fn decimal_cmp(left: &str, right: &str) -> Ordering {
    left.len().cmp(&right.len()).then_with(|| left.as_bytes().cmp(right.as_bytes()))
}
fn nat_eq_usize(value: &Nat, expected: usize) -> bool { value.as_decimal() == expected.to_string() }

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decimal_order_does_not_narrow_unbounded_nat() {
        assert_eq!(decimal_cmp("9", "10"), Ordering::Less);
        assert_eq!(decimal_cmp("184467440737095516160", "3"), Ordering::Greater);
    }
}
