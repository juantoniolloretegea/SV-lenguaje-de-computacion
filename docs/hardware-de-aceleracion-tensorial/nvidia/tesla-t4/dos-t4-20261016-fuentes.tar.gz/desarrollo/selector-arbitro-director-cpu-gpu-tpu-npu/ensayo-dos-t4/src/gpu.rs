use cudarc::driver::{sys, CudaContext, CudaFunction, CudaStream, LaunchConfig, PushKernelArg};
use nvml_wrapper::{enum_wrappers::device::TemperatureSensor, enums::device::UsedGpuMemory, Nvml};
use serde::Serialize;
use serde_json::{json, Value};
use std::{
    fs::{self, OpenOptions},
    io::Write,
    path::Path,
    sync::Arc,
    time::{Duration, Instant},
};
use sv_ensayo_gpu_kaggle::{validar, Solicitud, R};
pub(crate) const PTX: &str =
    include_str!("../../../ensayo-gpu-kaggle-rust-20261013/gpu/calculo.ptx");
pub(crate) const SELECTOR: &str = include_str!("../../src/lib.rs");
pub(crate) const MARGEN: u64 = 64 * 1024 * 1024;
pub(crate) fn err(e: impl std::fmt::Display) -> String {
    e.to_string()
}
pub(crate) fn save<T: Serialize>(dir: &Path, name: &str, v: &T) -> R<()> {
    let mut f = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(dir.join(name))
        .map_err(err)?;
    f.write_all(&serde_json::to_vec_pretty(v).map_err(err)?)
        .and_then(|_| f.sync_all())
        .map_err(err)
}
pub(crate) fn read<T: serde::de::DeserializeOwned>(p: impl AsRef<Path>) -> R<T> {
    serde_json::from_slice(&fs::read(p).map_err(err)?).map_err(err)
}
pub(crate) fn observed<T: Serialize, E: std::fmt::Display>(r: Result<T, E>) -> Value {
    match r {
        Ok(v) => json!({"valor":v,"error":null}),
        Err(e) => json!({"valor":null,"error":e.to_string()}),
    }
}
pub(crate) fn uuid(c: &CudaContext) -> R<String> {
    let h = c
        .uuid()
        .map_err(err)?
        .bytes
        .iter()
        .map(|b| format!("{:02x}", *b as u8))
        .collect::<String>();
    Ok(format!(
        "GPU-{}-{}-{}-{}-{}",
        &h[..8],
        &h[8..12],
        &h[12..16],
        &h[16..20],
        &h[20..]
    ))
}
pub(crate) fn gpu_sample(n: &Nvml, id: &str) -> R<Value> {
    let d = n.device_by_uuid(id).map_err(err)?;
    Ok(
        json!({"uuid":id,"memoria":observed(d.memory_info().map(|v|json!({"total":v.total,"free":v.free,"used":v.used}))),"utilizacion":observed(d.utilization_rates().map(|v|json!({"gpu":v.gpu,"memory":v.memory}))),"energia_mj":observed(d.total_energy_consumption()),"potencia_mw":observed(d.power_usage()),"temperatura_c":observed(d.temperature(TemperatureSensor::Gpu)),"procesos_propios":observed(d.running_compute_processes().map(|p|p.into_iter().filter(|p|p.pid==std::process::id()).map(|p|json!({"pid":p.pid,"memoria_bytes":match p.used_gpu_memory{UsedGpuMemory::Used(v)=>Some(v),UsedGpuMemory::Unavailable=>None}})).collect::<Vec<_>>())),"alcance":"NVML global del dispositivo; no energía exclusiva de la solicitud"}),
    )
}
pub(crate) fn cpu_sample() -> R<Value> {
    let mut sys = sysinfo::System::new();
    let pid = sysinfo::Pid::from_u32(std::process::id());
    sys.refresh_processes_specifics(
        sysinfo::ProcessesToUpdate::Some(&[pid]),
        true,
        sysinfo::ProcessRefreshKind::nothing()
            .without_tasks()
            .with_cpu()
            .with_memory(),
    );
    let p = sys.process(pid).ok_or("CPU no observable")?;
    Ok(
        json!({"pid":pid.as_u32(),"inicio_unix_s":p.start_time(),"cpu_acumulada_ms":p.accumulated_cpu_time(),"rss_bytes":p.memory(),"alcance":"Proceso completo incluido control y observación; resolución del sistema operativo"}),
    )
}
pub(crate) fn cpu_free() -> u64 {
    let mut s = sysinfo::System::new();
    s.refresh_memory();
    s.available_memory()
}
pub(crate) fn cpu_calc(s: &Solicitud) -> R<Vec<i32>> {
    validar(s)?;
    let (m, k, n) = (s.filas as usize, s.interior as usize, s.columnas as usize);
    let mut out = vec![0i32; m * n];
    for i in 0..m {
        for q in 0..k {
            for j in 0..n {
                out[i * n + j] += s.a[i * k + q] * s.b[q * n + j];
            }
        }
    }
    Ok(out)
}
pub(crate) fn median(v: &[u64]) -> R<u64> {
    if v.len() != 5 {
        return Err("cinco_medidas_requeridas".into());
    }
    let mut x = v.to_vec();
    x.sort_unstable();
    Ok(x[2])
}
pub(crate) fn micros(d: Duration) -> u64 {
    u64::try_from(d.as_nanos().div_ceil(1000)).unwrap_or(u64::MAX)
}

pub(crate) struct Gpu {
    pub(crate) context: Arc<CudaContext>,
    pub(crate) stream: Arc<CudaStream>,
    pub(crate) function: CudaFunction,
    pub(crate) id: String,
}
impl Gpu {
    pub(crate) fn calculate(&self, s: &Solicitud) -> R<(Vec<i32>, Value)> {
        let bytes = validar(s)?;
        if uuid(&self.context)? != self.id
            || (self.context.mem_get_info().map_err(err)?.0 as u64) < bytes + MARGEN
        {
            return Err("GPU cambió o memoria insuficiente".into());
        }
        let total = Instant::now();
        let t = Instant::now();
        let a = self.stream.clone_htod(&s.a).map_err(err)?;
        let b = self.stream.clone_htod(&s.b).map_err(err)?;
        let mut c = self
            .stream
            .alloc_zeros::<i32>((s.filas * s.columnas) as usize)
            .map_err(err)?;
        self.stream.synchronize().map_err(err)?;
        let upload = micros(t.elapsed());
        let start = self
            .stream
            .record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT))
            .map_err(err)?;
        // Longitudes y cotas verificadas, asignaciones independientes, lectura sincronizada.
        unsafe {
            self.stream
                .launch_builder(&self.function)
                .arg(&a)
                .arg(&b)
                .arg(&mut c)
                .arg(&s.filas)
                .arg(&s.interior)
                .arg(&s.columnas)
                .launch(LaunchConfig::for_num_elems(s.filas * s.columnas))
                .map_err(err)?;
        }
        let end = self
            .stream
            .record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT))
            .map_err(err)?;
        end.synchronize().map_err(err)?;
        let cuda_ms = start.elapsed_ms(&end).map_err(err)?;
        let t = Instant::now();
        let out = self.stream.clone_dtoh(&c).map_err(err)?;
        self.stream.synchronize().map_err(err)?;
        let download = micros(t.elapsed());
        drop((a, b, c));
        self.stream.synchronize().map_err(err)?;
        Ok((
            out,
            json!({"total_us":micros(total.elapsed()),"envio_y_asignacion_us":upload,"recuperacion_us":download,"cuda_ms":cuda_ms,"lanzamientos_cuda":1,"bytes_entrada":4*(s.a.len()+s.b.len()),"bytes_salida":4*s.filas*s.columnas}),
        ))
    }
}
