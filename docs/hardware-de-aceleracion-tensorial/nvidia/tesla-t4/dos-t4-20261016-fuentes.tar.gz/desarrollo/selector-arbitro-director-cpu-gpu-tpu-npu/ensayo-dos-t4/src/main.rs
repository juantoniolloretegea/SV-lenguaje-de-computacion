mod gpu;
use cudarc::{driver::CudaContext, nvrtc::Ptx};
use explorador::enlace::{CapacidadRecibida, EvidenciaAdaptador};
use explorador::sondas::{Cpu, Nvidia};
use explorador::{Consulta, Explorador, Inventario, Sonda};
use gpu::*;
use nvml_wrapper::Nvml;
use selector::{Capacidad, Carga, Clase, Cobertura, Destino, Estado, Politica, Recurso};
use serde_json::{json, Value};
use std::{
    collections::BTreeMap,
    fs,
    path::Path,
    sync::{mpsc, Arc},
    thread,
    time::{Duration, Instant},
};
use sv_ensayo_gpu_kaggle::{
    casos,
    instrumentacion::{self, sha, Monitor},
    referencia, validar, Solicitud, R,
};

const MODOS: [&str; 5] = ["cpu", "gpu0", "gpu1", "automatico_gpu", "automatico"];
const VIGENCIA: u64 = 30_000;
fn destino(id: &str) -> Destino {
    Destino {
        servidor: "kaggle-dos-t4".into(),
        dispositivo: id.into(),
        adaptador_revision: sha(include_bytes!("main.rs")),
    }
}
fn carga(s: &Solicitud) -> Carga {
    Carga {
        contrato: s.operacion.clone(),
        revision: sha(PTX.as_bytes()),
        perfil: "i32-exacto-sesion-inicializada/v1".into(),
        dimensiones: vec![s.filas as usize, s.interior as usize, s.columnas as usize],
    }
}
fn solicitud(s: &Solicitud, modo: &str) -> selector::Solicitud {
    selector::Solicitud {
        id: format!("{}-{modo}", s.id),
        carga: carga(s),
        memoria_adicional_bytes: validar(s).expect("Caso fijo válido"),
        margen_bytes: MARGEN,
        residencia_obligatoria: None,
    }
}
fn politica(modo: &str, ids: &[String]) -> R<Politica> {
    let permitidos: Vec<String> = match modo {
        "cpu" => vec!["cpu-anfitrion".into()],
        "gpu0" => vec![ids[0].clone()],
        "gpu1" => vec![ids[1].clone()],
        "automatico_gpu" => ids.to_vec(),
        "automatico" => std::iter::once("cpu-anfitrion".into())
            .chain(ids.iter().cloned())
            .collect(),
        _ => return Err("Modo desconocido".into()),
    };
    Ok(Politica {
        revision: format!("dos-t4/{modo}/v1"),
        destinos_permitidos: permitidos.iter().map(|s| destino(s)).collect(),
        preferencia: vec![Clase::Cpu, Clase::Gpu],
        clase_obligatoria: None,
        vigencia_ms: VIGENCIA,
        comparar_estimaciones: true,
    })
}
fn decision(d: &selector::Decision) -> Value {
    json!({"solicitud":d.solicitud,"politica_revision":d.politica_revision,"destino":d.destino.dispositivo,"clase":format!("{:?}",d.clase),"criterio":format!("{:?}",d.criterio),"evidencia":d.evidencia_capacidad,"observado_ms":d.observado_ms,"decidida_ms":d.decidida_ms,"descartes":d.descartes.iter().map(|x|json!({"destino":x.destino.dispositivo,"motivo":format!("{:?}",x.motivo)})).collect::<Vec<_>>()})
}
fn inventario(e: &Explorador) -> R<Inventario> {
    e.explorar(&[&Cpu, &Nvidia])
}
fn comprobar_inventario(i: &Value, ids: &[String], inicial: Option<&Value>) -> R<()> {
    let qs = i["consultas"].as_array().ok_or("Consultas ausentes")?;
    for (fuente, cantidad, clase) in [("cpu-sistema", 1, "Cpu"), ("nvidia-nvml", 2, "Gpu")] {
        let q = qs
            .iter()
            .find(|q| q["fuente"] == fuente)
            .ok_or("Fuente ausente")?;
        let os = q["observaciones"]
            .as_array()
            .ok_or("Observaciones ausentes")?;
        if q["estado"] != "Completa" || os.len() != cantidad {
            return Err("Inventario físico incompleto".into());
        }
        if os
            .iter()
            .map(|o| o["id"].as_str().unwrap_or(""))
            .collect::<std::collections::BTreeSet<_>>()
            .len()
            != cantidad
        {
            return Err("Identidad duplicada".into());
        }
        for o in os {
            let id = o["id"].as_str().ok_or("Identidad ausente")?;
            if o["clase"] != clase
                || o["acceso"] != "Consultable"
                || (fuente == "nvidia-nvml"
                    && (!ids.contains(&id.to_owned())
                        || !o["nombre"].as_str().unwrap_or("").contains("T4")))
            {
                return Err("Identidad o clase discordante".into());
            }
            if o["memoria_libre_bytes"].as_u64().is_none() {
                return Err("Memoria no observable".into());
            }
            if let Some(prev) = inicial {
                let old = prev["consultas"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .flat_map(|q| q["observaciones"].as_array().unwrap())
                    .find(|x| x["id"] == id)
                    .ok_or("Identidad nueva")?;
                for k in ["nombre", "clase", "interfaz", "memoria_total_bytes"] {
                    if o[k] != old[k] {
                        return Err("Identidad cambiada".into());
                    }
                }
            }
        }
    }
    Ok(())
}
fn observar_ambas(n: &Nvml, ids: &[String]) -> R<Vec<Value>> {
    ids.iter().map(|id| gpu_sample(n, id)).collect()
}
fn operacion(
    dir: &Path,
    s: &Solicitud,
    id: &str,
    fase: &str,
    dest: &str,
    gpus: &[Gpu],
    n: &Nvml,
    ids: &[String],
    mon: &Monitor,
) -> R<Value> {
    mon.healthy()?;
    let cb = cpu_sample()?;
    let gb = observar_ambas(n, ids)?;
    mon.event(
        "inicio_operacion",
        json!({"id":id,"caso":s.id,"destino":dest,"fase":fase}),
    )?;
    let (out, times) = if dest == "cpu-anfitrion" {
        if cpu_free() < validar(s)? + MARGEN {
            return Err("Memoria CPU insuficiente".into());
        }
        let t = Instant::now();
        let out = cpu_calc(s)?;
        (
            out,
            json!({"total_us":micros(t.elapsed()),"cuda_ms":null,"lanzamientos_cuda":0}),
        )
    } else {
        gpus.iter()
            .find(|g| g.id == dest)
            .ok_or("GPU elegida no cargada")?
            .calculate(s)?
    };
    let ca = cpu_sample()?;
    let ga = observar_ambas(n, ids)?;
    if out != referencia(s)? {
        return Err(format!("Resultado discordante: {id}"));
    }
    let v = json!({"id":id,"caso":s.id,"fase":fase,"destino":dest,"uuid_contexto_cuda":if dest=="cpu-anfitrion"{None}else{Some(dest)},"tiempos":times,"salida":out,"cpu_antes":cb,"cpu_despues":ca,"gpu_antes":gb,"gpu_despues":ga});
    save(dir, &format!("{id}.json"), &v)?;
    mon.event("fin_operacion",json!({"id":id,"destino":dest,"archivo":format!("{id}.json"),"sha256":sha(&fs::read(dir.join(format!("{id}.json"))).map_err(err)?)}))?;
    Ok(v)
}
struct RetiradaLogica<'a>(&'a str);
impl Sonda for RetiradaLogica<'_> {
    fn consultar(&self) -> Consulta {
        let mut c = Nvidia.consultar();
        c.observaciones.retain(|o| o.id != self.0);
        c
    }
}
fn ejecutar(dir: &Path, mon: &Arc<Monitor>) -> R<Value> {
    let e = Explorador::nuevo();
    let inicial = inventario(&e)?;
    let ids: Vec<_> = inicial
        .consultas()
        .iter()
        .filter(|q| q.fuente == "nvidia-nvml")
        .flat_map(|q| q.observaciones.iter().map(|o| o.id.clone()))
        .collect();
    let ini = serde_json::to_value(&inicial).map_err(err)?;
    if ids.len() != 2 || ids[0] == ids[1] {
        return Err("Se requieren exactamente dos GPU distintas".into());
    }
    comprobar_inventario(&ini, &ids, None)?;
    save(dir, "INVENTARIO-INICIAL.json", &ini)?;
    let n = Arc::new(Nvml::init().map_err(err)?);
    let (tx, rx) = mpsc::channel();
    let nn = n.clone();
    let mm = mon.clone();
    let ii = ids.clone();
    let observador = thread::spawn(move || -> R<()> {
        loop {
            for id in &ii {
                match gpu_sample(&nn, id) {
                    Ok(v) => mm.event("muestra_gpu", v)?,
                    Err(e) => mm.event("fallo_medicion_gpu", json!({"uuid":id,"error":e}))?,
                }
            }
            match rx.recv_timeout(Duration::from_millis(100)) {
                Ok(()) | Err(mpsc::RecvTimeoutError::Disconnected) => break,
                Err(mpsc::RecvTimeoutError::Timeout) => {}
            }
        }
        Ok(())
    });
    let r = (|| -> R<Value> {
        if CudaContext::device_count().map_err(err)? != 2 {
            return Err("Cantidad CUDA y NVML discordante".into());
        }
        let t = Instant::now();
        let mut gpus = Vec::new();
        let mut identidad = Vec::new();
        for idx in 0..2 {
            let ctx = CudaContext::new(idx).map_err(err)?;
            let id = uuid(&ctx)?;
            if !ids.contains(&id) || gpus.iter().any(|g: &Gpu| g.id == id) {
                return Err("UUID CUDA discordante".into());
            }
            if ctx.compute_capability().map_err(err)? != (7, 5) {
                return Err("Capacidad CUDA distinta de T4".into());
            }
            let modulo = ctx.load_module(Ptx::from_src(PTX)).map_err(err)?;
            let funcion = modulo.load_function("producto_i32").map_err(err)?;
            identidad.push(json!({"indice_cuda":idx,"uuid":id,"nombre":ctx.name().map_err(err)?,"capacidad":[7,5]}));
            gpus.push(Gpu {
                context: ctx.clone(),
                stream: ctx.default_stream(),
                function: funcion,
                id,
            });
        }
        save(
            dir,
            "IDENTIDAD.json",
            &json!({"gpu":identidad,"ids":ids,"inicializacion_us":micros(t.elapsed()),"pid":std::process::id(),"ptx_sha256":sha(PTX.as_bytes()),"selector_sha256":sha(SELECTOR.as_bytes()),"explorador_sha256":sha(include_bytes!("../../explorador-tensorial-sv/src/lib.rs")),"enlace_sha256":sha(include_bytes!("../../explorador-tensorial-sv/src/enlace.rs")),"ejecutable_sha256":sha(&fs::read(std::env::current_exe().map_err(err)?).map_err(err)?),"controlador":n.sys_driver_version().map_err(err)?,"cuda_controlador":n.sys_cuda_driver_version().map_err(err)?}),
        )?;
        let destinos: Vec<_> = std::iter::once("cpu-anfitrion".to_owned())
            .chain(ids.iter().cloned())
            .collect();
        for s in casos() {
            save(dir, &format!("{}-entrada.json", s.id), &s)?;
            let mut medidas: BTreeMap<String, Vec<u64>> = BTreeMap::new();
            for ronda in 0..5 {
                for paso in 0..3 {
                    let d = &destinos[(ronda + paso) % 3];
                    let pos = destinos.iter().position(|x| x == d).unwrap();
                    let id = format!("{}-contraste-{ronda}-{pos}", s.id);
                    let op = operacion(dir, &s, &id, "contraste", d, &gpus, &n, &ids, mon)?;
                    medidas
                        .entry(d.clone())
                        .or_default()
                        .push(op["tiempos"]["total_us"].as_u64().ok_or("Tiempo ausente")?);
                }
            }
            let medianas: BTreeMap<_, _> = medidas
                .iter()
                .map(|(id, vs)| Ok((id.clone(), median(vs)?)))
                .collect::<R<_>>()?;
            let cal = json!({"caso":s.id,"medidas_us":medidas,"medianas_us":medianas,"alcance":"Recorrido de cálculo en sesión inicializada; transferencias y sincronización incluidas en GPU. Observación, inicialización y cotejo separados."});
            let evidencia = sha(&serde_json::to_vec(&cal).map_err(err)?);
            save(dir, &format!("{}-calibracion.json", s.id), &cal)?;
            let i = inventario(&e)?;
            let mut caps: Vec<CapacidadRecibida> = Vec::new();
            for id in &destinos {
                caps.push(
                    e.recibir_capacidad(
                        &i,
                        EvidenciaAdaptador {
                            fuente: if id == "cpu-anfitrion" {
                                "cpu-sistema"
                            } else {
                                "nvidia-nvml"
                            }
                            .into(),
                            identidad: id.clone(),
                            destino: destino(id),
                            capacidad: Capacidad {
                                carga: carga(&s),
                                cobertura: Cobertura::Completa,
                                evidencia: evidencia.clone(),
                                estimacion_total_us: Some(medianas[id]),
                            },
                            contrastada_ms: e.ahora_ms(),
                            vigencia_ms: 300_000,
                        },
                    )?,
                );
            }
            for modo in MODOS {
                let i = inventario(&e)?;
                let iv = serde_json::to_value(&i).map_err(err)?;
                comprobar_inventario(&iv, &ids, Some(&ini))?;
                let sel = e.seleccionar(&i, &caps, solicitud(&s, modo), politica(modo, &ids)?)?;
                let previa = decision(sel.decision());
                let resultado=e.ejecutar_revalidado_con_inventario(&[&Cpu,&Nvidia],&caps,sel,|d,actual|{
                    let av=serde_json::to_value(actual).map_err(err)?;comprobar_inventario(&av,&ids,Some(&ini))?;
                    let op=operacion(dir,&s,&format!("{}-{modo}",s.id),"seleccion",&d.destino.dispositivo,&gpus,&n,&ids,mon)?;
                    Ok(json!({"modo":modo,"caso":s.id,"inventario":iv,"decision_previa":previa,"revalidacion":av,"decision":decision(d),"operacion":op["id"]}))
                })?;
                save(dir, &format!("{}-{modo}-decision.json", s.id), &resultado)?;
                mon.event("decision", resultado)?;
            }
            for (k, id) in ids.iter().enumerate() {
                let modo = if k == 0 { "gpu0" } else { "gpu1" };
                let i = inventario(&e)?;
                let sel = e.seleccionar(&i, &caps, solicitud(&s, modo), politica(modo, &ids)?)?;
                let retirada = RetiradaLogica(id);
                let mut invocado = false;
                let rechazo = e
                    .ejecutar_revalidado(&[&Cpu, &retirada], &caps, sel, |_| {
                        invocado = true;
                        Ok(())
                    })
                    .err()
                    .ok_or("Retirada lógica admitida")?;
                if invocado || rechazo != "Dispositivo no observado" {
                    return Err("Control de revalidación discordante".into());
                }
                let control = json!({"caso":s.id,"destino":id,"transformacion_logica":"Retirada de una observación tras consulta real; no avería física","ejecucion_invocada":invocado,"rechazo":rechazo});
                save(dir, &format!("{}-retirada-{k}.json", s.id), &control)?;
                mon.event("rechazo_revalidacion", control)?;
            }
        }
        Ok(
            json!({"operaciones":120,"decisiones":30,"rechazos_revalidacion":12,"ids":ids,"inferencia":false,"ejecucion_distribuida":false}),
        )
    })();
    let _ = tx.send(());
    observador.join().map_err(|_| "Observador interrumpido")??;
    r
}

fn manifest(dir: &Path) -> R<Value> {
    let mut vs = Vec::new();
    for x in fs::read_dir(dir).map_err(err)? {
        let x = x.map_err(err)?;
        let name = x.file_name().into_string().map_err(|_| "Nombre no UTF8")?;
        if name == "MANIFIESTO.json" {
            continue;
        }
        if !x.file_type().map_err(err)?.is_file() {
            return Err("Archivo no regular".into());
        }
        let b = fs::read(x.path()).map_err(err)?;
        vs.push(json!({"archivo":name,"bytes":b.len(),"sha256":sha(&b)}));
    }
    vs.sort_by_key(|v| v["archivo"].as_str().unwrap().to_owned());
    Ok(json!(vs))
}
fn recursos_guardados(s: &Solicitud, i: &Value, cal: &Value, evidencia: &str) -> R<Vec<Recurso>> {
    i["consultas"]
        .as_array()
        .ok_or("Consultas ausentes")?
        .iter()
        .flat_map(|q| q["observaciones"].as_array().unwrap())
        .map(|o| {
            let id = o["id"].as_str().ok_or("Id ausente")?;
            Ok(Recurso {
                destino: destino(id),
                clase: if id == "cpu-anfitrion" {
                    Clase::Cpu
                } else {
                    Clase::Gpu
                },
                estado: Estado::Comprobado,
                observado_ms: i["observado_ms"].as_u64().ok_or("Instante ausente")?,
                memoria_disponible_bytes: o["memoria_libre_bytes"].as_u64(),
                disponible: true,
                capacidades: vec![Capacidad {
                    carga: carga(s),
                    cobertura: Cobertura::Completa,
                    evidencia: evidencia.into(),
                    estimacion_total_us: cal["medianas_us"][id].as_u64(),
                }],
            })
        })
        .collect()
}
fn cotejar_operacion(
    dir: &Path,
    s: &Solicitud,
    id: &str,
    destino: &str,
    ids: &[String],
    traza: &[Value],
) -> R<Value> {
    let p = dir.join(format!("{id}.json"));
    let op: Value = read(&p)?;
    if op["id"] != id
        || op["caso"] != s.id
        || op["destino"] != destino
        || op["salida"] != json!(referencia(s)?)
    {
        return Err("Resultado o destino discordante".into());
    }
    if op["tiempos"]["total_us"].as_u64().is_none() {
        return Err("Tiempo ausente".into());
    }
    let cpu = destino == "cpu-anfitrion";
    if op["tiempos"]["lanzamientos_cuda"] != json!(if cpu { 0 } else { 1 })
        || (cpu && !op["uuid_contexto_cuda"].is_null())
        || (!cpu
            && (op["uuid_contexto_cuda"] != destino || op["tiempos"]["cuda_ms"].as_f64().is_none()))
    {
        return Err("Atribución CUDA discordante".into());
    }
    for campo in ["gpu_antes", "gpu_despues"] {
        let vs = op[campo].as_array().ok_or("Muestras ausentes")?;
        if vs.len() != 2 {
            return Err("Falta muestra de GPU".into());
        }
        for (k, id) in ids.iter().enumerate() {
            if vs[k]["uuid"] != *id
                || vs[k]["memoria"]["valor"].is_null()
                || vs[k]["utilizacion"]["valor"].is_null()
            {
                return Err("Telemetría GPU incompleta".into());
            }
        }
    }
    if op["cpu_despues"]["cpu_acumulada_ms"]
        .as_u64()
        .ok_or("CPU ausente")?
        < op["cpu_antes"]["cpu_acumulada_ms"]
            .as_u64()
            .ok_or("CPU ausente")?
    {
        return Err("Contador CPU regresivo".into());
    }
    let inicios: Vec<_> = traza
        .iter()
        .filter(|r| r["tipo"] == "inicio_operacion" && r["datos"]["id"] == id)
        .collect();
    let fines: Vec<_> = traza
        .iter()
        .filter(|r| r["tipo"] == "fin_operacion" && r["datos"]["id"] == id)
        .collect();
    if inicios.len() != 1
        || fines.len() != 1
        || inicios[0]["datos"]["destino"] != destino
        || fines[0]["datos"]["sha256"] != sha(&fs::read(p).map_err(err)?)
    {
        return Err("Traza y operación discordantes".into());
    }
    Ok(op)
}
fn verificar(dir: &Path) -> R<Value> {
    if read::<Value>(dir.join("MANIFIESTO.json"))? != manifest(dir)? {
        return Err("Manifiesto discordante".into());
    }
    let tele = instrumentacion::verify(&dir.join("telemetria.jsonl"))?;
    let traza = instrumentacion::records(&dir.join("telemetria.jsonl"))?;
    let report: Value = read(dir.join("RESULTADO.json"))?;
    if !report["error"].is_null() {
        return Ok(json!({"conforme":false,"resultado":report,"telemetria":tele}));
    }
    let identidad: Value = read(dir.join("IDENTIDAD.json"))?;
    let ids: Vec<String> = serde_json::from_value(identidad["ids"].clone()).map_err(err)?;
    if ids.len() != 2
        || ids[0] == ids[1]
        || identidad["selector_sha256"] != sha(SELECTOR.as_bytes())
        || identidad["ptx_sha256"] != sha(PTX.as_bytes())
        || identidad["explorador_sha256"]
            != sha(include_bytes!("../../explorador-tensorial-sv/src/lib.rs"))
        || identidad["enlace_sha256"]
            != sha(include_bytes!(
                "../../explorador-tensorial-sv/src/enlace.rs"
            ))
    {
        return Err("Identidad o fuentes discordantes".into());
    }
    let inicial: Value = read(dir.join("INVENTARIO-INICIAL.json"))?;
    comprobar_inventario(&inicial, &ids, None)?;
    let destinos: Vec<_> = std::iter::once("cpu-anfitrion".to_owned())
        .chain(ids.iter().cloned())
        .collect();
    let mut conteos: BTreeMap<String, usize> = BTreeMap::new();
    let mut decisiones = Vec::new();
    for s in casos() {
        if read::<Value>(dir.join(format!("{}-entrada.json", s.id)))?
            != serde_json::to_value(&s).map_err(err)?
        {
            return Err("Entrada modificada".into());
        }
        let cal: Value = read(dir.join(format!("{}-calibracion.json", s.id)))?;
        let evidencia = sha(&serde_json::to_vec(&cal).map_err(err)?);
        for (k, d) in destinos.iter().enumerate() {
            let mut tiempos = Vec::new();
            for ronda in 0..5 {
                let op = cotejar_operacion(
                    dir,
                    &s,
                    &format!("{}-contraste-{ronda}-{k}", s.id),
                    d,
                    &ids,
                    &traza,
                )?;
                tiempos.push(op["tiempos"]["total_us"].as_u64().unwrap());
                *conteos.entry(d.clone()).or_default() += 1;
            }
            if cal["medidas_us"][d] != json!(tiempos) || cal["medianas_us"][d] != median(&tiempos)?
            {
                return Err("Calibración discordante".into());
            }
        }
        for modo in MODOS {
            let v: Value = read(dir.join(format!("{}-{modo}-decision.json", s.id)))?;
            for (inv, dec) in [
                ("inventario", "decision_previa"),
                ("revalidacion", "decision"),
            ] {
                comprobar_inventario(&v[inv], &ids, Some(&inicial))?;
                let r = recursos_guardados(&s, &v[inv], &cal, &evidencia)?;
                let d = selector::seleccionar(
                    &solicitud(&s, modo),
                    &politica(modo, &ids)?,
                    &r,
                    v[dec]["decidida_ms"]
                        .as_u64()
                        .ok_or("Instante de decisión ausente")?,
                )
                .map_err(err_debug)?;
                if decision(&d) != v[dec] {
                    return Err("Decisión no reproducible".into());
                }
            }
            if v["decision_previa"]["destino"] != v["decision"]["destino"] {
                return Err("Sustitución tras revalidar".into());
            }
            let d = v["decision"]["destino"].as_str().unwrap();
            let op = cotejar_operacion(dir, &s, &format!("{}-{modo}", s.id), d, &ids, &traza)?;
            if v["operacion"] != op["id"]
                || traza
                    .iter()
                    .filter(|r| r["tipo"] == "decision" && r["datos"] == v)
                    .count()
                    != 1
            {
                return Err("Decisión y traza discordantes".into());
            }
            *conteos.entry(d.into()).or_default() += 1;
            decisiones.push(
                json!({"caso":s.id,"modo":modo,"destino":d,"total_us":op["tiempos"]["total_us"]}),
            );
        }
        for (k, id) in ids.iter().enumerate() {
            let v: Value = read(dir.join(format!("{}-retirada-{k}.json", s.id)))?;
            if v["destino"] != *id
                || v["ejecucion_invocada"] != false
                || v["rechazo"] != "Dispositivo no observado"
                || traza
                    .iter()
                    .filter(|r| r["tipo"] == "rechazo_revalidacion" && r["datos"] == v)
                    .count()
                    != 1
            {
                return Err("Rechazo no acreditado".into());
            }
        }
    }
    let fallos = traza
        .iter()
        .filter(|r| r["tipo"] == "fallo_medicion_gpu" || r["tipo"] == "fallo_medicion")
        .count();
    let mut muestras = Vec::new();
    for id in &ids {
        let vs: Vec<_> = traza
            .iter()
            .filter(|r| r["tipo"] == "muestra_gpu" && r["datos"]["uuid"] == *id)
            .collect();
        if vs.len() < 2 {
            return Err("Muestreo GPU insuficiente".into());
        }
        let energia = vs.last().unwrap()["datos"]["energia_mj"]["valor"]
            .as_u64()
            .and_then(|fin| fin.checked_sub(vs[0]["datos"]["energia_mj"]["valor"].as_u64()?));
        let gap = vs
            .windows(2)
            .map(|w| {
                w[1]["transcurrido_ms"].as_u64().unwrap()
                    - w[0]["transcurrido_ms"].as_u64().unwrap()
            })
            .max();
        let pid = vs
            .iter()
            .filter(|r| {
                r["datos"]["procesos_propios"]["valor"]
                    .as_array()
                    .is_some_and(|p| !p.is_empty())
            })
            .count();
        if pid == 0 {
            return Err("PID no observado en GPU".into());
        }
        muestras.push(json!({"uuid":id,"muestras":vs.len(),"muestras_pid":pid,"intervalo_maximo_ms":gap,"energia_global_delta_mj":energia,"potencia_max_mw":vs.iter().filter_map(|r|r["datos"]["potencia_mw"]["valor"].as_u64()).max(),"temperatura_max_c":vs.iter().filter_map(|r|r["datos"]["temperatura_c"]["valor"].as_u64()).max()}));
    }
    if traza
        .iter()
        .filter(|r| r["tipo"] == "inicio_operacion")
        .count()
        != 120
        || traza
            .iter()
            .filter(|r| r["tipo"] == "fin_operacion")
            .count()
            != 120
    {
        return Err("Operaciones adicionales o ausentes".into());
    }
    Ok(
        json!({"conforme":fallos==0,"operaciones_exactas":120,"decisiones_reproducidas":30,"rechazos_revalidacion":12,"operaciones_por_destino":conteos,"decisiones":decisiones,"gpu":muestras,"fallos_observacion":fallos,"telemetria_cpu":tele,"alcance":"CPU y ambas GPU por separado; sin inferencia, partición ni ejecución distribuida. Energía NVML global de cada dispositivo, no exclusiva del ensayo."}),
    )
}
fn err_debug(e: impl std::fmt::Debug) -> String {
    format!("{e:?}")
}
fn realizar(dir: &Path) -> R<Value> {
    fs::create_dir(dir).map_err(err)?;
    let mon = Arc::new(Monitor::start_bounded(dir, 355)?);
    mon.event("protocolo",json!({"casos":6,"contrastes_por_destino":5,"destinos":3,"decisiones_por_caso":5,"retiradas_logicas_por_caso":2,"seleccion":selector::NOMBRE}))?;
    let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| ejecutar(dir, &mon)))
        .map_err(|_| "Fallo de ejecución".into())
        .and_then(|v| v);
    let v = match r {
        Ok(v) => json!({"error":null,"resultado":v}),
        Err(e) => json!({"error":e,"resultado":null}),
    };
    mon.event("resultado", v.clone())?;
    Arc::try_unwrap(mon)
        .map_err(|_| "Observador abierto")?
        .finish()?;
    save(dir, "RESULTADO.json", &v)?;
    save(dir, "MANIFIESTO.json", &manifest(dir)?)?;
    let cotejo = verificar(dir);
    let path = dir.with_extension("tar.gz");
    let f = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&path)
        .map_err(err)?;
    let mut a = tar::Builder::new(flate2::write::GzEncoder::new(
        f,
        flate2::Compression::default(),
    ));
    a.append_dir_all("evidencias", dir).map_err(err)?;
    a.into_inner()
        .map_err(err)?
        .finish()
        .map_err(err)?
        .sync_all()
        .map_err(err)?;
    println!(
        "Archivo: {} SHA-256 {}",
        path.display(),
        sha(&fs::read(&path).map_err(err)?)
    );
    cotejo
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let r = match args.get(1).map(String::as_str) {
        Some("verificar") if args.len() == 3 => verificar(Path::new(&args[2])),
        Some("calcular") if args.len() == 3 => realizar(Path::new(&args[2])),
        Some("ejecutar") if args.len() == 4 => {
            let exe = std::env::current_exe().unwrap();
            if sha(&fs::read(&exe).unwrap()) != args[3] {
                eprintln!("Huella discordante; sin ejecución");
                std::process::exit(3);
            }
            let mut hijo = std::process::Command::new(exe)
                .arg("calcular")
                .arg(&args[2])
                .spawn()
                .unwrap();
            let t = Instant::now();
            loop {
                if let Some(s) = hijo.try_wait().unwrap() {
                    std::process::exit(s.code().unwrap_or(1));
                }
                if t.elapsed() > Duration::from_secs(360) {
                    let _ = hijo.kill();
                    let _ = hijo.wait();
                    std::process::exit(124);
                }
                thread::sleep(Duration::from_millis(100));
            }
        }
        _ => Err("Uso: ejecutar DIRECTORIO SHA256 | verificar DIRECTORIO".into()),
    };
    match r {
        Ok(v) => {
            println!("{}", serde_json::to_string_pretty(&v).unwrap());
            if v["conforme"] == false {
                std::process::exit(1);
            }
        }
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(1);
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn calculo_cpu_y_mediana() {
        for s in casos() {
            assert_eq!(cpu_calc(&s).unwrap(), referencia(&s).unwrap());
        }
        assert_eq!(median(&[7, 3, 9, 1, 5]).unwrap(), 5);
    }
    #[test]
    fn destinos_fisicos_distintos() {
        let ids = vec!["GPU-a".into(), "GPU-b".into()];
        assert_eq!(
            politica("gpu0", &ids).unwrap().destinos_permitidos,
            vec![destino("GPU-a")]
        );
        assert_eq!(
            politica("gpu1", &ids).unwrap().destinos_permitidos,
            vec![destino("GPU-b")]
        );
        assert_eq!(
            politica("automatico", &ids)
                .unwrap()
                .destinos_permitidos
                .len(),
            3
        );
    }
    struct Fija(Consulta);
    impl Sonda for Fija {
        fn consultar(&self) -> Consulta {
            self.0.clone()
        }
    }
    fn fuentes() -> (Fija, Fija) {
        let mut c = Consulta::nueva("cpu-sistema");
        let mut g = Consulta::nueva("nvidia-nvml");
        for (id, clase) in [
            ("cpu-anfitrion", explorador::Clase::Cpu),
            ("GPU-a", explorador::Clase::Gpu),
            ("GPU-b", explorador::Clase::Gpu),
        ] {
            let o = explorador::Observacion {
                id: id.into(),
                clase,
                nombre: format!("Simulación T4 {id}"),
                acceso: explorador::Acceso::Consultable,
                memoria_total_bytes: Some(1_000_000_000),
                memoria_libre_bytes: Some(900_000_000),
                interfaz: "simulada".into(),
            };
            if id == "cpu-anfitrion" {
                c.observaciones.push(o);
            } else {
                g.observaciones.push(o);
            }
        }
        (Fija(c), Fija(g))
    }
    #[test]
    fn seleccion_por_identidad_y_revalidacion_de_dos_gpu() {
        let (c, mut g) = fuentes();
        let e = Explorador::nuevo();
        let i = e.explorar(&[&c, &g]).unwrap();
        let s = &casos()[0];
        let ids = vec!["GPU-a".into(), "GPU-b".into()];
        let mut cs = Vec::new();
        for (id, fuente, t) in [
            ("cpu-anfitrion", "cpu-sistema", 90),
            ("GPU-a", "nvidia-nvml", 50),
            ("GPU-b", "nvidia-nvml", 10),
        ] {
            cs.push(
                e.recibir_capacidad(
                    &i,
                    EvidenciaAdaptador {
                        fuente: fuente.into(),
                        identidad: id.into(),
                        destino: destino(id),
                        capacidad: Capacidad {
                            carga: carga(s),
                            cobertura: Cobertura::Completa,
                            evidencia: "simulada-no-fisica".into(),
                            estimacion_total_us: Some(t),
                        },
                        contrastada_ms: e.ahora_ms(),
                        vigencia_ms: VIGENCIA,
                    },
                )
                .unwrap(),
            );
        }
        let sel = e
            .seleccionar(
                &i,
                &cs,
                solicitud(s, "automatico_gpu"),
                politica("automatico_gpu", &ids).unwrap(),
            )
            .unwrap();
        assert_eq!(sel.decision().destino.dispositivo, "GPU-b");
        g.0.observaciones.reverse();
        let d = e
            .ejecutar_revalidado(&[&c, &g], &cs, sel, |d| Ok(d.destino.dispositivo.clone()))
            .unwrap();
        assert_eq!(d, "GPU-b");
        let sel = e
            .seleccionar(
                &i,
                &cs,
                solicitud(s, "gpu0"),
                politica("gpu0", &ids).unwrap(),
            )
            .unwrap();
        assert_eq!(sel.decision().destino.dispositivo, "GPU-a");
        g.0.observaciones.retain(|o| o.id != "GPU-a");
        let mut llamado = false;
        assert!(e
            .ejecutar_revalidado(&[&c, &g], &cs, sel, |_| {
                llamado = true;
                Ok(())
            })
            .is_err());
        assert!(!llamado);
    }
    #[test]
    fn auditor_rechaza_identidad_repetida_y_cambio_de_controlador() {
        let (c, g) = fuentes();
        let e = Explorador::nuevo();
        let i = serde_json::to_value(e.explorar(&[&c, &g]).unwrap()).unwrap();
        let ids = vec!["GPU-a".into(), "GPU-b".into()];
        comprobar_inventario(&i, &ids, None).unwrap();
        let mut alterada = i.clone();
        alterada["consultas"][1]["observaciones"][1]["id"] = json!("GPU-a");
        assert!(comprobar_inventario(&alterada, &ids, None).is_err());
        let mut alterada = i.clone();
        alterada["consultas"][1]["observaciones"][0]["interfaz"] = json!("controlador-otro");
        assert!(comprobar_inventario(&alterada, &ids, Some(&i)).is_err());
    }
}
