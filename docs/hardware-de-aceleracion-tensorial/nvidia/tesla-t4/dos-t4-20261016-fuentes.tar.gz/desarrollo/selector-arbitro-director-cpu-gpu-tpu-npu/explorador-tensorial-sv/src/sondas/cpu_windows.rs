//! Denominación publicada por Windows en el registro de hardware, sólo lectura.
use super::nombre_cpu;
use std::ptr;
use windows_sys::Win32::{
    Foundation::{ERROR_NO_MORE_ITEMS, ERROR_SUCCESS},
    System::Registry::*,
};
struct Clave(HKEY);
impl Drop for Clave {
    fn drop(&mut self) {
        // SAFETY: clave abierta por este módulo, liberada una sola vez.
        unsafe {
            RegCloseKey(self.0);
        }
    }
}
fn texto(bytes: &[u16]) -> Result<String, String> {
    let fin = bytes
        .iter()
        .position(|x| *x == 0)
        .ok_or("ProcessorNameString sin terminador")?;
    let texto = String::from_utf16(&bytes[..fin]).map_err(|e| e.to_string())?;
    let texto = texto.trim();
    if texto.is_empty() {
        return Err("ProcessorNameString vacío".into());
    }
    Ok(texto.into())
}
pub fn denominacion() -> Result<String, String> {
    let ruta: Vec<u16> = "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\0"
        .encode_utf16()
        .collect();
    let valor: Vec<u16> = "ProcessorNameString\0".encode_utf16().collect();
    let mut clave = ptr::null_mut();
    // SAFETY: ruta fija del registro de hardware, únicamente con permisos de lectura.
    let estado =
        unsafe { RegOpenKeyExW(HKEY_LOCAL_MACHINE, ruta.as_ptr(), 0, KEY_READ, &mut clave) };
    if estado != ERROR_SUCCESS {
        return Err(format!(
            "Registro de identidad CPU no consultable: {estado}"
        ));
    }
    let clave = Clave(clave);
    let mut nombres = Vec::new();
    for indice in 0..65_536 {
        let mut subclave = [0u16; 256];
        let mut n = subclave.len() as u32;
        // SAFETY: clave abierta; longitud en unidades UTF-16 y búfer válido.
        let estado = unsafe {
            RegEnumKeyExW(
                clave.0,
                indice,
                subclave.as_mut_ptr(),
                &mut n,
                ptr::null(),
                ptr::null_mut(),
                ptr::null_mut(),
                ptr::null_mut(),
            )
        };
        if estado == ERROR_NO_MORE_ITEMS {
            return nombre_cpu(nombres).ok_or("Registro de CPU sin denominaciones".into());
        }
        if estado != ERROR_SUCCESS || n as usize >= subclave.len() {
            return Err(format!("Enumeración incompleta del registro CPU: {estado}"));
        }
        subclave[n as usize] = 0;
        let mut buffer = [0u16; 1024];
        let mut bytes = std::mem::size_of_val(&buffer) as u32;
        // SAFETY: sólo REG_SZ de la subclave observada; tamaño expresado en bytes.
        let estado = unsafe {
            RegGetValueW(
                clave.0,
                subclave.as_ptr(),
                valor.as_ptr(),
                RRF_RT_REG_SZ,
                ptr::null_mut(),
                buffer.as_mut_ptr().cast(),
                &mut bytes,
            )
        };
        if estado != ERROR_SUCCESS
            || bytes % 2 != 0
            || bytes as usize > std::mem::size_of_val(&buffer)
        {
            return Err(format!(
                "Denominación CPU incompleta en subclave {indice}: {estado}"
            ));
        }
        nombres.push(texto(&buffer[..bytes as usize / 2])?);
    }
    Err("Registro CPU excede el límite de enumeración".into())
}
#[cfg(test)]
mod pruebas {
    use super::*;
    #[test]
    #[ignore = "Consulta material del registro de hardware del equipo de ensayo"]
    fn lectura_material_del_registro_cpu() {
        let nombre = denominacion().expect("Denominación CPU no recibida del registro de hardware");
        assert!(!nombre.trim().is_empty());
        println!("Denominación observada en registro de hardware: {nombre}");
    }
    #[test]
    fn no_admite_denominaciones_truncadas_vacias_o_invalidas() {
        assert!(texto(&[65]).is_err());
        assert!(texto(&[32, 0]).is_err());
        assert!(texto(&[0xd800, 0]).is_err());
        assert_eq!(texto(&[65, 0]).unwrap(), "A");
    }
}
