//! Inventario DXCore de sólo consulta. No crea gráficos de cálculo ni ejecuta modelos.
use super::*;
use ::windows::{
    core::{Interface, GUID, HRESULT},
    Win32::{Foundation::LUID, Graphics::DXCore::*},
};
use std::{ffi::c_void, ptr};
use windows_sys::Win32::{
    Foundation::{FreeLibrary, HMODULE},
    System::LibraryLoader::{GetProcAddress, LoadLibraryExW, LOAD_LIBRARY_SEARCH_SYSTEM32},
};

// Atributos de tipo de hardware documentados por Microsoft, independientes de Direct3D.
// https://learn.microsoft.com/windows/win32/dxcore/dxcore-adapter-attribute-guids
// windows 0.57 contiene las interfaces COM; estos GUID posteriores no figuran en esa edición.
const TIPOS: [(GUID, Clase, &str); 4] = [
    (
        GUID::from_u128(0xb69eb219_3ded_4464_979f_a00bd4687006),
        Clase::Gpu,
        "GPU",
    ),
    (
        GUID::from_u128(0xd46140c4_add7_451b_9e56_06fe8c3b58ed),
        Clase::Npu,
        "NPU",
    ),
    (
        GUID::from_u128(0xe0b195da_58ef_4a22_90f1_1f28169cab8d),
        Clase::AceleradorSinClasificar,
        "ComputeAccelerator",
    ),
    (
        GUID::from_u128(0x66bdb96a_050b_44c7_a4fd_d144ce0ab443),
        Clase::AceleradorSinClasificar,
        "MediaAccelerator",
    ),
];
const FUENTE: &str = "windows-dxcore";

struct Biblioteca(HMODULE);
impl Drop for Biblioteca {
    fn drop(&mut self) {
        // SAFETY: handle adquirido por LoadLibraryExW; todos los objetos COM ya se liberaron.
        unsafe {
            FreeLibrary(self.0);
        }
    }
}
impl Biblioteca {
    fn abrir() -> Result<Self, String> {
        let nombre: Vec<u16> = "dxcore.dll\0".encode_utf16().collect();
        // SAFETY: nombre terminado en cero; sólo carga la biblioteca del sistema operativo.
        let h = unsafe {
            LoadLibraryExW(
                nombre.as_ptr(),
                ptr::null_mut(),
                LOAD_LIBRARY_SEARCH_SYSTEM32,
            )
        };
        if h.is_null() {
            Err(format!(
                "DXCore no disponible: {}",
                std::io::Error::last_os_error()
            ))
        } else {
            Ok(Self(h))
        }
    }
    fn fabrica(&self) -> Result<IDXCoreAdapterFactory, String> {
        // SAFETY: biblioteca abierta y nombre ASCII terminado en cero.
        let simbolo = unsafe { GetProcAddress(self.0, b"DXCoreCreateAdapterFactory\0".as_ptr()) }
            .ok_or("DXCoreCreateAdapterFactory no disponible")?;
        type Crear = unsafe extern "system" fn(*const GUID, *mut *mut c_void) -> HRESULT;
        // SAFETY: firma publicada en dxcore.h para el símbolo exacto del sistema.
        let crear: Crear = unsafe { std::mem::transmute(simbolo) };
        let mut salida = ptr::null_mut();
        // SAFETY: IID de IDXCoreAdapterFactory y dirección válida del resultado.
        unsafe { crear(&IDXCoreAdapterFactory::IID, &mut salida) }
            .ok()
            .map_err(|e| e.to_string())?;
        if salida.is_null() {
            return Err("DXCore devolvió una fábrica nula".into());
        }
        // SAFETY: resultado satisfactorio con la interfaz solicitada; se adopta su referencia.
        Ok(unsafe { IDXCoreAdapterFactory::from_raw(salida) })
    }
}

fn clasificar(atributos: [bool; 4]) -> Result<usize, &'static str> {
    let mut presentes = atributos.iter().enumerate().filter(|(_, v)| **v);
    let primero = presentes
        .next()
        .ok_or("Tipo de hardware DXCore no declarado")?
        .0;
    if presentes.next().is_some() {
        return Err("Tipos de hardware DXCore contradictorios");
    }
    Ok(primero)
}

// SAFETY: cada invocación debe usar el tipo y tamaño publicados para esa propiedad;
// sólo se utiliza con u8, u64 y LUID, que admiten cualquier patrón de bits.
unsafe fn valor<T: Default + Copy>(
    a: &IDXCoreAdapter,
    p: DXCoreAdapterProperty,
) -> Result<T, String> {
    // SAFETY: objeto COM vivo; consulta sin argumentos de salida.
    if !unsafe { a.IsPropertySupported(p) } {
        return Err(format!("Propiedad DXCore {} no disponible", p.0));
    }
    // SAFETY: consulta del tamaño publicado por el controlador.
    let n = unsafe { a.GetPropertySize(p) }.map_err(|e| e.to_string())?;
    if n != std::mem::size_of::<T>() {
        return Err(format!("Tamaño discordante en propiedad DXCore {}", p.0));
    }
    let mut salida = T::default();
    // SAFETY: tamaño cotejado, resultado inicializado y alineado para el tipo requerido.
    unsafe { a.GetProperty(p, n, (&mut salida as *mut T).cast()) }.map_err(|e| e.to_string())?;
    Ok(salida)
}

fn descripcion(bytes: &[u8]) -> Result<String, String> {
    let fin = bytes
        .iter()
        .position(|b| *b == 0)
        .ok_or("Descripción DXCore sin terminador")?;
    let nombre = std::str::from_utf8(&bytes[..fin])
        .map_err(|e| e.to_string())?
        .trim();
    if nombre.is_empty() {
        return Err("Descripción DXCore vacía".into());
    }
    Ok(nombre.into())
}

fn observar(a: &IDXCoreAdapter, esperado: usize) -> Result<Option<Observacion>, String> {
    // SAFETY: todas las consultas se realizan sobre una interfaz COM recibida de DXCore.
    unsafe {
        if !a.IsValid() {
            return Err("Adaptador DXCore invalidado".into());
        }
        match valor::<u8>(a, IsHardware)? {
            0 => return Ok(None), // Un adaptador de software no acredita un dispositivo físico.
            1 => (),
            _ => return Err("IsHardware no contiene un booleano válido".into()),
        }
        let tipo = clasificar(TIPOS.map(|(guid, _, _)| a.IsAttributeSupported(&guid)))?;
        if tipo != esperado {
            return Err("Tipo DXCore discordante con su enumeración".into());
        }
        let luid = valor::<LUID>(a, InstanceLuid)?;
        let version = valor::<u64>(a, DriverVersion)?;
        let n = a
            .GetPropertySize(DriverDescription)
            .map_err(|e| e.to_string())?;
        if !(1..=65_536).contains(&n) {
            return Err("Tamaño de descripción DXCore no admitido".into());
        }
        let mut buffer = vec![0u8; n];
        a.GetProperty(DriverDescription, n, buffer.as_mut_ptr().cast())
            .map_err(|e| e.to_string())?;
        let nombre = descripcion(&buffer)?;
        if !a.IsValid() {
            return Err("Adaptador DXCore invalidado durante la consulta".into());
        }
        Ok(Some(Observacion {
            id: format!("luid-{:08x}-{:08x}", luid.HighPart as u32, luid.LowPart),
            clase: TIPOS[tipo].1,
            nombre,
            acceso: Acceso::Identificado,
            memoria_total_bytes: None,
            memoria_libre_bytes: None,
            interfaz: format!(
                "DXCore;tipo={};atributo={:?};controlador={}.{}.{}.{};identidad-local-al-arranque",
                TIPOS[tipo].2,
                TIPOS[tipo].0,
                version >> 48,
                (version >> 32) & 65535,
                (version >> 16) & 65535,
                version & 65535
            ),
        }))
    }
}

pub fn consultar() -> Consulta {
    // Declaración anterior a fábrica/listas: el módulo se libera al final, después de COM.
    let biblioteca = match Biblioteca::abrir() {
        Ok(b) => b,
        Err(e) => return Consulta::fallo(FUENTE, EstadoConsulta::NoDisponible, e),
    };
    let fabrica = match biblioteca.fabrica() {
        Ok(f) => f,
        Err(e) => return Consulta::fallo(FUENTE, EstadoConsulta::NoDisponible, e),
    };
    let mut c = Consulta::nueva(FUENTE);
    let mut ids = BTreeSet::new();
    for (tipo, (atributo, _, etiqueta)) in TIPOS.iter().enumerate() {
        // SAFETY: atributo público por tipo, sin exigir un entorno Direct3D.
        let lista: IDXCoreAdapterList = match unsafe { fabrica.CreateAdapterList(&[*atributo]) } {
            Ok(l) => l,
            Err(e) => {
                c.estado = EstadoConsulta::Parcial;
                c.incidencias
                    .push(format!("Enumeración DXCore {etiqueta}: {e}"));
                continue;
            }
        };
        // SAFETY: lista obtenida de la fábrica, válida hasta finalizar esta iteración.
        for n in 0..unsafe { lista.GetAdapterCount() } {
            let resultado = (|| {
                // SAFETY: índice dentro del número comunicado por la lista.
                let a: IDXCoreAdapter =
                    unsafe { lista.GetAdapter(n) }.map_err(|e| e.to_string())?;
                observar(&a, tipo)
            })();
            match resultado {
                Ok(Some(o)) if ids.insert(o.id.clone()) => c.observaciones.push(o),
                Ok(Some(_)) => {
                    c.estado = EstadoConsulta::Parcial;
                    c.incidencias
                        .push("Identidad DXCore repetida entre tipos de hardware".into());
                }
                Ok(None) => (),
                Err(e) => {
                    c.estado = EstadoConsulta::Parcial;
                    c.incidencias.push(format!("{etiqueta} {n}: {e}"));
                }
            }
        }
        // SAFETY: lista todavía viva; una enumeración caducada no acredita disponibilidad.
        if unsafe { lista.IsStale() } {
            c.estado = EstadoConsulta::Parcial;
            c.incidencias.push(format!(
                "Lista DXCore {etiqueta} caducada durante la consulta"
            ));
        }
    }
    c
}

#[cfg(test)]
mod pruebas {
    use super::*;
    #[test]
    fn no_clasifica_npu_por_ausencia_ni_por_atributos_contradictorios() {
        assert!(clasificar([false; 4]).is_err());
        assert!(clasificar([true, true, false, false]).is_err());
        assert_eq!(
            TIPOS[clasificar([false, true, false, false]).unwrap()].1,
            Clase::Npu
        );
        assert_eq!(
            TIPOS[clasificar([false, false, true, false]).unwrap()].1,
            Clase::AceleradorSinClasificar
        );
    }
    #[test]
    fn descripcion_exige_utf8_no_vacio_y_terminacion() {
        assert!(descripcion(b"NPU").is_err());
        assert!(descripcion(b" \0").is_err());
        assert!(descripcion(&[255, 0]).is_err());
        assert_eq!(
            descripcion(b"Adaptador observado\0").unwrap(),
            "Adaptador observado"
        );
    }
}
