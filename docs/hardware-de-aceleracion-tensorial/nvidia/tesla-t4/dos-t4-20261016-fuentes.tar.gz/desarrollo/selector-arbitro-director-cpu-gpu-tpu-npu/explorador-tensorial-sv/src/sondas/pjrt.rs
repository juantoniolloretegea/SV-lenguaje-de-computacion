//! Consulta del mismo cliente PJRT abierto por el adaptador de ejecución.
//! No carga bibliotecas indicadas por el solicitante ni inicia un modelo.
use super::*;

pub struct Cliente<'a>(pub &'a ::pjrt::Client);

// Capacidad restante comunicada por el asignador; no mide memoria física libre
// ni reserva espacio. La ausencia de estadísticas no se sustituye por un cero.
fn disponible(limite: Option<i64>, utilizado: i64) -> Result<Option<u64>, String> {
    if utilizado < 0 {
        return Err("Memoria utilizada negativa en PJRT".into());
    }
    limite.map(|limite| {
        limite.checked_sub(utilizado)
            .and_then(|resto| u64::try_from(resto).ok())
            .ok_or_else(|| "Estadísticas de memoria PJRT discordantes".into())
    }).transpose()
}
impl ConsultaTpu for Cliente<'_> {
    fn plataforma(&self) -> Result<String, String> {
        self.0
            .platform_name()
            .map(|s| s.into_owned())
            .map_err(|e| e.to_string())
    }
    fn dispositivos(&self) -> Result<Vec<Observacion>, String> {
        let version = self.0.platform_version().map_err(|e| e.to_string())?;
        self.0
            .addressable_devices()
            .map_err(|e| e.to_string())?
            .into_iter()
            .map(|d| {
                let desc = d.description().map_err(|e| e.to_string())?;
                let id = desc.id().map_err(|e| e.to_string())?;
                let nombre = desc.kind().map_err(|e| e.to_string())?.to_string();
                let local = d.local_hardware_id().map_err(|e| e.to_string())?;
                let memoria = d.memory_stats().ok();
                let disponible = memoria.map(|m| disponible(m.bytes_limit, m.bytes_in_use))
                    .transpose()?.flatten();
                Ok(Observacion {
                    id: format!("pjrt-tpu-{id}"),
                    clase: Clase::Tpu,
                    nombre,
                    acceso: Acceso::Consultable,
                    memoria_total_bytes: None,
                    memoria_libre_bytes: disponible,
                    interfaz: format!("PJRT;plataforma={version};dispositivo_local={local};memoria_disponible=limite_asignador-memoria_en_uso;sin_reserva"),
                })
            })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::disponible;
    #[test]
    fn limite_no_equivale_a_memoria_fisica_ni_ausencia_a_cero() {
        assert_eq!(disponible(Some(100), 30).unwrap(), Some(70));
        assert_eq!(disponible(None, 30).unwrap(), None);
        assert_eq!(disponible(Some(100), 100).unwrap(), Some(0));
        assert!(disponible(Some(100), 101).is_err());
        assert!(disponible(Some(-1), 0).is_err());
        assert!(disponible(Some(100), -1).is_err());
    }
}
