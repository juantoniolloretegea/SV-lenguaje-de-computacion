#![forbid(unsafe_code)]
use netstat2::{get_sockets_info, AddressFamilyFlags, ProtocolFlags, ProtocolSocketInfo};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs::{self, File, OpenOptions}, io::Write, path::{Path, PathBuf}, sync::{Arc, Mutex, mpsc}, thread::{self, JoinHandle}, time::{Duration, Instant, SystemTime, UNIX_EPOCH}};
use sysinfo::{Pid, ProcessRefreshKind, ProcessesToUpdate, System};
pub type Result<T> = std::result::Result<T, String>;
pub fn sha(b: &[u8]) -> String { format!("{:x}", Sha256::digest(b)) }
pub fn utc_ms() -> u128 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() }
fn err(e: impl std::fmt::Display) -> String {e.to_string()}
fn new_file(p: &Path) -> Result<File> {OpenOptions::new().write(true).create_new(true).open(p).map_err(err)}
fn store(p: &Path, v: &Value) -> Result<()> {let mut f=new_file(p)?; f.write_all(&serde_json::to_vec_pretty(v).map_err(err)?).and_then(|_| f.sync_all()).map_err(err)}

// Solo se conserva el proceso inscrito. Ni argumentos, ni entorno, ni usuarios.
pub struct Sampler { system: System, pid: Pid, identity: u64, count: u64 }
impl Sampler {
    pub fn own() -> Result<Self> {
        Self::for_pid(std::process::id())
    }
    pub fn for_pid(pid:u32) -> Result<Self> {
        let mut s=Self {system:System::new(),pid:Pid::from_u32(pid),identity:0,count:0};
        s.refresh();
        s.identity=s.system.process(s.pid).ok_or("Proceso propio no observable")?.start_time();
        if s.identity==0 {return Err("Inicio del proceso no observable".into());} Ok(s)
    }
    fn refresh(&mut self) {self.system.refresh_processes_specifics(ProcessesToUpdate::Some(&[self.pid]),true,ProcessRefreshKind::nothing().without_tasks().with_cpu().with_memory().with_disk_usage());}
    pub fn sample(&mut self) -> Result<Value> {
        let started=Instant::now(); self.refresh();
        let p=self.system.process(self.pid).ok_or("Proceso ausente o inaccesible")?;
        if p.start_time()!=self.identity {return Err("Identidad de proceso discordante; posible reutilización de PID".into());}
        let io=p.disk_usage();
        // Sólo cantidades e identidad del espacio de red del proceso inscrito.
        // No se leen destinos de descriptores, contenido de archivos ni entornos.
        let count_dir=|name:&str|->Option<usize>{
            if !cfg!(target_os="linux"){return None;}
            fs::read_dir(format!("/proc/{}/{name}",self.pid.as_u32())).ok()
                .and_then(|rows|rows.collect::<std::io::Result<Vec<_>>>().ok()).map(|v|v.len())
        };
        let threads=count_dir("task");let descriptors=count_dir("fd");
        let net_space=if cfg!(target_os="linux"){
            fs::read_link(format!("/proc/{}/ns/net",self.pid.as_u32())).ok().map(|v|v.to_string_lossy().into_owned())
        }else{None};
        let process=json!({"pid":p.pid().as_u32(),"ppid":p.parent().map(|v|v.as_u32()),"inicio_unix_s":self.identity,
            "nombre":p.name().to_string_lossy(),"cpu_porcentaje_nucleo":if self.count==0 {None}else{Some(p.cpu_usage())},
            "cpu_acumulada_ms":p.accumulated_cpu_time(),"rss_bytes":p.memory(),"virtual_bytes":p.virtual_memory(),
            "io_lectura_acumulada_bytes":io.total_read_bytes,"io_escritura_acumulada_bytes":io.total_written_bytes,
            "estado":p.status().to_string(),"hilos_so":threads,"handles_so":null,
            "descriptores_abiertos_linux":descriptors,"espacio_red_linux":net_space,
            "limite_observacion_adicional":"Conteos /proc del proceso inscrito en Linux; pueden incluir la propia observación. No se inventarían handles Windows ni recursos internos del proveedor; campos no accesibles permanecen null",
            "io_alcance":"E/S del proceso según sistema operativo; no equivale a tráfico TCP ni exclusivamente disco"});
        let sockets=get_sockets_info(AddressFamilyFlags::IPV4|AddressFamilyFlags::IPV6,ProtocolFlags::TCP|ProtocolFlags::UDP).map_err(err)?;
        let mut rows=Vec::new();
        for s in sockets.into_iter().filter(|s|s.associated_pids.contains(&self.pid.as_u32())) {
            let row=match s.protocol_socket_info {
                ProtocolSocketInfo::Tcp(t)=>json!({"protocolo":"TCP","local":format!("{}:{}",t.local_addr,t.local_port),"remoto":format!("{}:{}",t.remote_addr,t.remote_port),"puerto_local":t.local_port,"puerto_remoto":t.remote_port,"estado":format!("{:?}",t.state),"pid":self.pid.as_u32()}),
                ProtocolSocketInfo::Udp(u)=>json!({"protocolo":"UDP","local":format!("{}:{}",u.local_addr,u.local_port),"puerto_local":u.local_port,"estado":"sin conexión","pid":self.pid.as_u32()})};
            rows.push(row);
        }
        rows.sort_by_key(Value::to_string); self.count+=1;
        Ok(json!({"proceso":process,"conexiones":rows,"duracion_captura_us":started.elapsed().as_micros(),"estado_medicion":"observado"}))
    }
}

struct Ledger {file:File, seq:u64, previous:String, start:Instant, samples:u64, failures:u64, max_gap:u128, last_sample:Option<u128>}
impl Ledger {
    fn append(&mut self,kind:&str,data:Value)->Result<()> {
        let elapsed=self.start.elapsed().as_millis();
        let body=serde_json::to_string(&json!({"secuencia":self.seq,"utc_unix_ms":utc_ms(),"transcurrido_ms":elapsed,"tipo":kind,"datos":data})).map_err(err)?;
        let digest=sha(format!("{}\n{}",self.previous,body).as_bytes());
        let line=serde_json::to_vec(&json!({"anterior_sha256":self.previous,"cuerpo":body,"sha256":digest})).map_err(err)?;
        self.file.write_all(&line).and_then(|_|self.file.write_all(b"\n")).and_then(|_|self.file.flush()).map_err(err)?;
        self.previous=digest;self.seq+=1;
        if kind=="muestra" {self.samples+=1; if let Some(p)=self.last_sample {self.max_gap=self.max_gap.max(elapsed-p);}self.last_sample=Some(elapsed);}
        if kind=="fallo_medicion" {self.failures+=1;}
        Ok(())
    }
}
pub struct Monitor {ledger:Arc<Mutex<Ledger>>, stop:Option<mpsc::Sender<()>>, join:Option<JoinHandle<Result<()>>>, dir:PathBuf}
impl Monitor {
    pub fn start(dir:&Path)->Result<Self> {
        Self::start_bounded(dir, 180)
    }
    pub fn start_bounded(dir:&Path, seconds:u64)->Result<Self> {
        if !(1..=360).contains(&seconds) {return Err("Plazo de observación fuera de contrato".into());}
        fs::create_dir_all(dir).map_err(err)?;
        let mut sampler=Sampler::own()?; let initial=sampler.sample()?;
        let mut ledger=Ledger{file:new_file(&dir.join("telemetria.jsonl"))?,seq:0,previous:"0".repeat(64),start:Instant::now(),samples:0,failures:0,max_gap:0,last_sample:None};
        ledger.append("inicio",json!({"version":"sv-instrumentacion/0.1.0","pid":std::process::id(),"intervalo_objetivo_ms":250,"sistema":std::env::consts::OS,"arquitectura":std::env::consts::ARCH,"nucleos_logicos":thread::available_parallelism().map(|x|x.get()).ok(),"alcance":"únicamente proceso inscrito; tabla TCP/UDP filtrada por PID antes de conservar","fuentes":["sysinfo 0.39.6","netstat2 0.11.2","reloj monotónico Rust"],"sin_medicion":["recursos internos del proveedor","tiempo DNS y TLS separados","handles del SO; hilos, descriptores y espacio de red fuera de Linux o no accesibles","asignaciones del heap Rust","retransmisiones y RTT TCP"]}))?;
        ledger.append("muestra",initial)?;
        let ledger=Arc::new(Mutex::new(ledger));let shared=ledger.clone();let(tx,rx)=mpsc::channel();
        let join=thread::Builder::new().name("sv-observacion".into()).spawn(move||{
            let deadline=Instant::now()+Duration::from_secs(seconds);
            loop {
                match rx.recv_timeout(Duration::from_millis(250)) {Ok(())|Err(mpsc::RecvTimeoutError::Disconnected)=>break,Err(mpsc::RecvTimeoutError::Timeout)=>{}}
                let result=sampler.sample();let mut l=shared.lock().map_err(err)?;
                match result {Ok(v)=>l.append("muestra",v)?,Err(e)=>l.append("fallo_medicion",json!({"motivo":e}))?,}
                if Instant::now()>=deadline {l.append("fallo_medicion",json!({"motivo":"plazo máximo de observación alcanzado"}))?;break;}
            }
            Ok(())
        }).map_err(err)?;
        Ok(Self {ledger,stop:Some(tx),join:Some(join),dir:dir.to_owned()})
    }
    // Los datos proceden exclusivamente de campos permitidos; nunca cabeceras de autorización.
    pub fn event(&self,kind:&str,data:Value)->Result<()> {self.ledger.lock().map_err(err)?.append(kind,data)}
    pub fn healthy(&self)->Result<()> {let l=self.ledger.lock().map_err(err)?;if l.failures>0 || self.join.as_ref().is_some_and(|j|j.is_finished()) {Err("Instrumentación degradada".into())} else {Ok(())}}
    pub fn finish(mut self)->Result<Value> {
        self.stop.take().unwrap().send(()).map_err(err)?;
        self.join.take().unwrap().join().map_err(|_|"Fallo del hilo de observación")??;
        {let mut l=self.ledger.lock().map_err(err)?;l.append("cierre_observacion",json!({"estado":"concluida"}))?;l.file.sync_all().map_err(err)?;}
        let v=verify(&self.dir.join("telemetria.jsonl"))?;
        store(&self.dir.join("COTEJO-TELEMETRIA.json"),&v)?;Ok(v)
    }
}
impl Drop for Monitor {fn drop(&mut self){if let Some(tx)=self.stop.take(){let _=tx.send(());}if let Some(j)=self.join.take(){let _=j.join();}}}

pub fn records(path:&Path)->Result<Vec<Value>> {
    let bytes=fs::read(path).map_err(err)?; if !bytes.ends_with(b"\n"){return Err("Registro truncado".into());}
    let mut previous="0".repeat(64);let mut out=Vec::new();let mut last=0;
    for line in bytes.split(|b|*b==b'\n').filter(|b|!b.is_empty()) {
        let row:Value=serde_json::from_slice(line).map_err(err)?; let body=row["cuerpo"].as_str().ok_or("Falta cuerpo")?;
        let digest=sha(format!("{previous}\n{body}").as_bytes());
        if row["anterior_sha256"]!=previous || row["sha256"]!=digest {return Err("Cadena de integridad discordante".into());}
        let v:Value=serde_json::from_str(body).map_err(err)?;
        let t=v["transcurrido_ms"].as_u64().ok_or("Falta reloj monotónico")?;
        if v["secuencia"].as_u64()!=Some(out.len() as u64)||t<last {return Err("Secuencia o tiempo discordantes".into());}
        last=t;previous=digest;out.push(v);
    } Ok(out)
}
pub fn verify(path:&Path)->Result<Value> {
    let rows=records(path)?;
    if rows.first().map(|v|v["tipo"].as_str())!=Some(Some("inicio")) || rows.last().map(|v|v["tipo"].as_str())!=Some(Some("cierre_observacion")){return Err("Registro sin inicio/cierre".into());}
    let samples:Vec<_>=rows.iter().filter(|v|v["tipo"]=="muestra").collect();
    let fails=rows.iter().filter(|v|v["tipo"]=="fallo_medicion").count();
    let gap=samples.windows(2).map(|w|w[1]["transcurrido_ms"].as_u64().unwrap()-w[0]["transcurrido_ms"].as_u64().unwrap()).max();
    let bytes=fs::read(path).map_err(err)?;
    Ok(json!({"integridad":"conforme","registros":rows.len(),"muestras":samples.len(),"fallos_medicion":fails,"intervalo_maximo_ms":gap,"intervalo_objetivo_ms":250,"bytes":bytes.len(),"sha256":sha(&bytes),"plataforma_recibida":false,"precision":"cotejo de custodia local; no equivale a recepción integral del instrumento ni firma externa"}))
}
pub fn escape(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;")}

#[cfg(test)] mod tests {
    use super::*;use std::net::{TcpListener,TcpStream};
    #[test]fn proceso_y_tcp_reales(){let mut s=Sampler::own().unwrap();let listener=TcpListener::bind("127.0.0.1:0").unwrap();let port=listener.local_addr().unwrap().port();let c=TcpStream::connect(listener.local_addr().unwrap()).unwrap();let(peer,_)=listener.accept().unwrap();thread::sleep(Duration::from_millis(300));let v=s.sample().unwrap();assert_eq!(v["proceso"]["pid"],std::process::id());let sockets=v["conexiones"].as_array().unwrap();assert!(sockets.iter().any(|v|v["puerto_local"]==port && v["estado"]=="Listen"));assert!(sockets.iter().any(|v|v["puerto_remoto"]==port && v["estado"]=="Established"));drop(c);drop(peer);drop(listener);thread::sleep(Duration::from_millis(300));let v=s.sample().unwrap();assert!(!v["conexiones"].as_array().unwrap().iter().any(|v|v["puerto_local"]==port && v["estado"]=="Listen"));}
    #[test]fn identidad_no_reutilizable(){let mut s=Sampler::own().unwrap();s.identity+=1;assert!(s.sample().is_err());}
    #[test]fn escapar_html(){assert_eq!(escape("<script>&"),"&lt;script&gt;&amp;");}
    #[test]fn registro_tamper_y_truncado(){
        let root=Path::new(env!("CARGO_MANIFEST_DIR")).join("evidencia-pruebas").join(format!("{}-{}",std::process::id(),utc_ms()));fs::create_dir_all(&root).unwrap();
        let monitor=Monitor::start(&root).unwrap();monitor.event("prueba_local",json!({"inferencia":false})).unwrap();thread::sleep(Duration::from_millis(650));let v=monitor.finish().unwrap();assert!(v["muestras"].as_u64().unwrap()>=3);
        let path=root.join("telemetria.jsonl");let bytes=fs::read(&path).unwrap();let mut altered=bytes.clone();let pos=altered.iter().position(|b|*b==b'0').unwrap();altered[pos]=b'1';fs::write(root.join("alterado.jsonl"),altered).unwrap();assert!(verify(&root.join("alterado.jsonl")).is_err());fs::write(root.join("truncado.jsonl"),&bytes[..bytes.len()-1]).unwrap();assert!(verify(&root.join("truncado.jsonl")).is_err());
    }
}
