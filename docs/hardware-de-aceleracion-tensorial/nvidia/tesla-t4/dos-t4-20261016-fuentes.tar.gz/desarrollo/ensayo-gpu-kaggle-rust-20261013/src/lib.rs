#![forbid(unsafe_code)]
use serde::{Deserialize, Serialize};
pub mod instrumentacion;
pub mod estricto;
pub type R<T> = Result<T, String>;
pub const OPERACION: &str = "producto_matricial_i32/v1";
pub const MEMORIA_MAXIMA: u64 = 256 * 1024 * 1024;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Solicitud {
    pub id: String,
    pub operacion: String,
    pub filas: u32,
    pub interior: u32,
    pub columnas: u32,
    pub a: Vec<i32>,
    pub b: Vec<i32>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Dispositivo {
    pub indice: u32,
    pub uuid: String,
    pub nombre: String,
    pub memoria_libre: u64,
    pub capacidad_mayor: i32,
    pub capacidad_menor: i32,
}
pub fn leer(bytes: &[u8]) -> R<Solicitud> {
    if bytes.len() > 4 * 1024 * 1024 { return Err("solicitud_excesiva".into()); }
    let value = estricto::parse(bytes).map_err(|e|e.to_string())?;
    serde_json::from_value(value).map_err(|e|e.to_string())
}
pub fn validar(s: &Solicitud) -> R<u64> {
    if s.id.is_empty() || s.id.len()>64 || !s.id.bytes().all(|c|c.is_ascii_alphanumeric()||c==b'-') {return Err("identidad_invalida".into());}
    if s.operacion != OPERACION {return Err("operacion_no_permitida".into());}
    if [s.filas,s.interior,s.columnas].iter().any(|&n|n==0||n>512) {return Err("dimensiones_fuera_de_limite".into());}
    if s.a.len() != (s.filas*s.interior) as usize || s.b.len() != (s.interior*s.columnas) as usize {return Err("longitud_discordante".into());}
    if s.a.iter().chain(&s.b).any(|&v|!(-1024..=1024).contains(&v)) {return Err("magnitud_fuera_de_limite".into());}
    // Acumulacion maxima: 512 * 1024^2 = 536870912, representable en i32.
    let bytes = 4 * (s.a.len() as u64+s.b.len() as u64+s.filas as u64*s.columnas as u64);
    if bytes>MEMORIA_MAXIMA {return Err("presupuesto_memoria_excedido".into());} Ok(bytes)
}
pub fn seleccionar(s: &Solicitud, dispositivos: &[Dispositivo]) -> R<Dispositivo> {
    let bytes=validar(s)?;
    let mut aptos:Vec<_>=dispositivos.iter().filter(|d|d.capacidad_mayor>=7 && d.memoria_libre >= bytes+64*1024*1024).cloned().collect();
    aptos.sort_by_key(|d|d.indice);
    aptos.into_iter().next().ok_or_else(||"gpu_compatible_no_disponible; cpu_no_autorizada_como_sustitucion".into())
}
// Referencia independiente: acumulacion i64, acceso por iteradores; no selecciona recursos.
pub fn referencia(s: &Solicitud) -> R<Vec<i32>> {
    validar(s)?;
    let k=s.interior as usize;let n=s.columnas as usize;
    s.a.chunks_exact(k).flat_map(|row|(0..n).map(move|j|row.iter().enumerate().map(|(q,&a)|i64::from(a)*i64::from(s.b[q*n+j])).sum::<i64>()))
      .map(|v|i32::try_from(v).map_err(|_|"desbordamiento_referencia".into())).collect()
}
pub fn casos() -> Vec<Solicitud> {
    [("minimo",1,1,1),("ceros",16,16,16),("rectangular",31,47,65),("signos",127,65,33),("limites",3,512,5),("carga",257,129,257)]
    .into_iter().map(|(id,m,k,n)| {
        let gen=|len:u32, salt:i32| (0..len).map(|i|if id=="ceros"{0}else if id=="limites"{if i%2==0 {1024}else{-1024}}else{((i as i32*17+salt)%15)-7}).collect();
        Solicitud{id:id.into(),operacion:OPERACION.into(),filas:m,interior:k,columnas:n,a:gen(m*k,3),b:gen(k*n,11)}
    }).collect()
}
#[cfg(test)] mod tests {
 use super::*;
 fn gpu(i:u32,mem:u64,cap:i32)->Dispositivo{Dispositivo{indice:i,uuid:format!("GPU-{i}"),nombre:"simulado".into(),memoria_libre:mem,capacidad_mayor:cap,capacidad_menor:5}}
 #[test] fn seleccion_real_del_contrato(){let s=&casos()[0];let d=seleccionar(s,&[gpu(1,u64::MAX,7),gpu(0,0,7)]).unwrap();assert_eq!(d.indice,1);assert!(seleccionar(s,&[]).is_err());assert!(seleccionar(s,&[gpu(0,0,7)]).is_err());assert!(seleccionar(s,&[gpu(0,u64::MAX,6)]).is_err());}
 #[test] fn prioridad_indice_estable(){assert_eq!(seleccionar(&casos()[0],&[gpu(1,u64::MAX,7),gpu(0,u64::MAX,7)]).unwrap().indice,0);}
 #[test] fn referencia_conocida(){let s=Solicitud{id:"manual".into(),operacion:OPERACION.into(),filas:2,interior:3,columnas:2,a:vec![1,2,3,-1,0,2],b:vec![2,1,0,-1,3,4]};assert_eq!(referencia(&s).unwrap(),vec![11,11,4,7]);}
 #[test] fn rechazos_antes_del_dispositivo(){let mut s=casos()[0].clone();s.operacion="ejecutar_codigo".into();assert!(seleccionar(&s,&[gpu(0,u64::MAX,7)]).is_err());s.operacion=OPERACION.into();s.filas=0;assert!(validar(&s).is_err());s.filas=513;assert!(validar(&s).is_err());s.filas=1;s.a.clear();assert!(validar(&s).is_err());s.a=vec![1025];assert!(validar(&s).is_err());s.a=vec![i32::MIN];assert!(validar(&s).is_err());}
 #[test] fn json_ambiguo_y_ampliado(){let b=serde_json::to_string(&casos()[0]).unwrap();let dup=b.replacen('{',"{\"id\":\"otro\",",1);assert!(leer(dup.as_bytes()).is_err());let extra=b.replacen('{',"{\"codigo\":\"no\",",1);assert!(leer(extra.as_bytes()).is_err());assert!(leer(format!("{b} true").as_bytes()).is_err());}
 #[test] fn cotas_y_exactitud(){for s in casos(){assert!(validar(&s).unwrap()<=MEMORIA_MAXIMA);let out=referencia(&s).unwrap();assert_eq!(out.len(),(s.filas*s.columnas)as usize);if s.id=="ceros" {assert!(out.iter().all(|&x|x==0));}}}
}
