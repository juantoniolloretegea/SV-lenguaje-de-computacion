#![no_std]
#![feature(abi_ptx, stdarch_nvptx)]
use core::arch::nvptx::{_block_dim_x,_block_idx_x,_thread_idx_x};
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
/// Seguridad: el anfitrion valida dimensiones, cotas de valores y longitudes, y
/// mantiene tres asignaciones CUDA disjuntas hasta sincronizar el dispositivo.
#[no_mangle]
pub unsafe extern "ptx-kernel" fn producto_i32(a:*const i32,b:*const i32,c:*mut i32,m:u32,k:u32,n:u32) {
    let p=(_block_idx_x()*_block_dim_x()+_thread_idx_x()) as u32;
    if p<m*n {
        let i=p/n;let j=p%n;let mut acc=0i32;let mut q=0u32;
        while q<k {acc+=*a.add((i*k+q)as usize) * *b.add((q*n+j)as usize);q+=1;}
        *c.add(p as usize)=acc;
    }
}
