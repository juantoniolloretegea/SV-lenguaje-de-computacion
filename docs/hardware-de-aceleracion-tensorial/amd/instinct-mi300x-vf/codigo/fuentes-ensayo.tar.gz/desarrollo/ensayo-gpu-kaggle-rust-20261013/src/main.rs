use cudarc::{driver::{CudaContext, LaunchConfig, PushKernelArg, sys}, nvrtc::Ptx};
use nvml_wrapper::{Nvml, enums::device::UsedGpuMemory, enum_wrappers::device::TemperatureSensor};
use serde_json::{json, Value};
use std::{fs::{self, OpenOptions}, io::Write, path::Path, sync::{Arc,mpsc}, thread, time::{Duration,Instant}};
use sv_ensayo_gpu_kaggle::{*,instrumentacion::{self, Monitor, sha, utc_ms}};
const PTX:&str=include_str!("../gpu/calculo.ptx");
fn err(e:impl std::fmt::Display)->String {e.to_string()}
fn put(dir:&Path,name:&str,v:&Value)->R<()> {
 let mut f=OpenOptions::new().write(true).create_new(true).open(dir.join(name)).map_err(err)?;
 f.write_all(&serde_json::to_vec_pretty(v).map_err(err)?).and_then(|_|f.sync_all()).map_err(err)
}
fn observed<T:serde::Serialize,E:std::fmt::Display>(r:Result<T,E>)->Value {
 match r {Ok(v)=>json!({"valor":v,"error":null}),Err(e)=>json!({"valor":null,"error":e.to_string()})}
}
fn gpu_sample(n:&Nvml,uuid:&str)->R<Value>{
 let d=n.device_by_uuid(uuid).map_err(err)?;
 let start=Instant::now();
 let mem=observed(d.memory_info().map(|v|json!({"total_bytes":v.total,"libres_bytes":v.free,"usados_bytes":v.used})));
 let util=observed(d.utilization_rates().map(|v|json!({"gpu_porcentaje":v.gpu,"memoria_porcentaje":v.memory})));
 // NVML puede comunicar PID del anfitrión. No se atribuyen otros procesos al ensayo.
 let proc=observed(d.running_compute_processes().map(|v|v.into_iter().filter(|p|p.pid==std::process::id()).map(|p|json!({"pid":p.pid,"memoria_bytes":match p.used_gpu_memory {UsedGpuMemory::Used(b)=>Some(b),UsedGpuMemory::Unavailable=>None}})).collect::<Vec<_>>()));
 Ok(json!({"uuid":uuid,"pid_buscado":std::process::id(),"memoria":mem,"utilizacion":util,"proceso_propio":proc,
 "potencia_mw":observed(d.power_usage()),"energia_acumulada_mj":observed(d.total_energy_consumption()),
 "temperatura_c":observed(d.temperature(TemperatureSensor::Gpu)),"captura_us":start.elapsed().as_micros(),
 "alcance":"Memoria, utilización, potencia y energía son del dispositivo completo; no se atribuyen exclusivamente a este proceso. La ausencia del PID puede deberse al espacio de procesos del contenedor."}))
}
fn uuid(ctx:&CudaContext)->R<String>{
 let h=ctx.uuid().map_err(err)?.bytes.iter().map(|b|format!("{:02x}",*b as u8)).collect::<String>();
 Ok(format!("GPU-{}-{}-{}-{}-{}",&h[..8],&h[8..12],&h[12..16],&h[16..20],&h[20..]))
}
fn negatives()->R<Value>{
 let s=casos().remove(0);
 let d=Dispositivo{indice:0,uuid:"simulado".into(),nombre:"simulado".into(),memoria_libre:u64::MAX,capacidad_mayor:7,capacidad_menor:5};
 let mut bad=s.clone();bad.operacion="ejecutar_codigo".into();
 let mut low=d.clone();low.memoria_libre=0;
 let mut old=d.clone();old.capacidad_mayor=6;
 let checks=[("operacion_no_permitida",seleccionar(&bad,&[d]).is_err()),("ausencia_gpu_simulada",seleccionar(&s,&[]).is_err()),("memoria_insuficiente_simulada",seleccionar(&s,&[low]).is_err()),("incompatibilidad_simulada",seleccionar(&s,&[old]).is_err())];
 if checks.iter().any(|(_,v)|!*v){return Err("rechazo_previsto_no_cumplido".into());}
 Ok(json!(checks))
}
fn execute(dir:&Path, mon:&Arc<Monitor>)->R<Value>{
 let global=Instant::now();
 let negatives=negatives()?;put(dir,"rechazos.json",&negatives)?;mon.event("rechazos",negatives)?;
 let n=Arc::new(Nvml::init().map_err(err)?);
 let mut contexts=Vec::new();let mut devices=Vec::new();
 for i in 0..CudaContext::device_count().map_err(err)? {
  let c=CudaContext::new(i as usize).map_err(err)?;let id=uuid(&c)?;
  let nd=n.device_by_uuid(id.as_str()).map_err(err)?;
  if nd.uuid().map_err(err)?!=id {return Err("identidad_cuda_nvml_discordante".into());}
  let cap=c.compute_capability().map_err(err)?;
  devices.push(Dispositivo{indice:i as u32,uuid:id,nombre:c.name().map_err(err)?,memoria_libre:c.mem_get_info().map_err(err)?.0 as u64,capacidad_mayor:cap.0,capacidad_menor:cap.1});contexts.push(c);
 }
 let selected=seleccionar(&casos()[5],&devices)?;
 let ctx=contexts[selected.indice as usize].clone();
 let identity=json!({"dispositivos_cuda":devices,"seleccionado":selected,"controlador":observed(n.sys_driver_version()),"cuda_controlador":observed(n.sys_cuda_driver_version()),"inicializacion_us":global.elapsed().as_micros(),"ptx_sha256":sha(PTX.as_bytes()),"ejecutable_sha256":sha(&fs::read(std::env::current_exe().map_err(err)?).map_err(err)?),"rust_gpu":"1.101.0-nightly 080cc2714 2026-10-11; nvptx64-nvidia-cuda; sm_70; PTX Rust","pid":std::process::id()});
 put(dir,"identidad.json",&identity)?;mon.event("identidad_gpu",identity)?;
 let (tx,rx)=mpsc::channel();let ng=n.clone();let mg=mon.clone();let idg=selected.uuid.clone();
 let observer=thread::spawn(move||->R<()> {
  loop {
   match gpu_sample(&ng,&idg){Ok(v)=>mg.event("muestra_gpu",v)?,Err(e)=>mg.event("fallo_medicion_gpu",json!({"motivo":e}))?,}
   match rx.recv_timeout(Duration::from_millis(100)){Ok(())|Err(mpsc::RecvTimeoutError::Disconnected)=>break,Err(mpsc::RecvTimeoutError::Timeout)=>{}}
  } Ok(())
 });
 let computation=(||->R<Value>{
  let t=Instant::now();let module=ctx.load_module(Ptx::from_src(PTX)).map_err(err)?;
  let function=module.load_function("producto_i32").map_err(err)?;let stream=ctx.default_stream();
  mon.event("modulo_cargado",json!({"duracion_us":t.elapsed().as_micros(),"compilacion_nvrtc":false}))?;
  let mut reports=Vec::new();
  for source in casos(){
   if global.elapsed()>Duration::from_secs(40){return Err("plazo_calculo_agotado".into());}mon.healthy()?;
   let serialized=serde_json::to_vec(&source).map_err(err)?;let t=Instant::now();let s=leer(&serialized)?;
   let bytes=validar(&s)?;let admission=t.elapsed().as_micros();
   put(dir,&format!("{}-solicitud.json",s.id),&json!(s))?;
   let t=Instant::now();let reference=referencia(&s)?;let reference_us=t.elapsed().as_micros();
   put(dir,&format!("{}-referencia.json",s.id),&json!(reference))?;
   mon.event("inicio_caso",json!({"id":s.id,"uuid":selected.uuid,"bytes_matrices":bytes}))?;
   let whole=Instant::now();let t=Instant::now();
   let a=stream.clone_htod(&s.a).map_err(err)?;let b=stream.clone_htod(&s.b).map_err(err)?;
   let mut c=stream.alloc_zeros::<i32>((s.filas*s.columnas)as usize).map_err(err)?;
   stream.synchronize().map_err(err)?;let upload=t.elapsed().as_micros();
   let start=stream.record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT)).map_err(err)?;
   let t=Instant::now();
   // Las dimensiones, las magnitudes y las longitudes están verificadas. Las tres
   // asignaciones son distintas, permanecen vivas y se sincronizan antes de leer.
   unsafe {stream.launch_builder(&function).arg(&a).arg(&b).arg(&mut c).arg(&s.filas).arg(&s.interior).arg(&s.columnas).launch(LaunchConfig::for_num_elems(s.filas*s.columnas)).map_err(err)?;}
   let end=stream.record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT)).map_err(err)?;
   end.synchronize().map_err(err)?;let kernel_wall=t.elapsed().as_micros();let kernel_ms=start.elapsed_ms(&end).map_err(err)?;
   let t=Instant::now();let result=stream.clone_dtoh(&c).map_err(err)?;stream.synchronize().map_err(err)?;let download=t.elapsed().as_micros();let whole_us=whole.elapsed().as_micros();
   let t=Instant::now();let equal=result==reference;let comparison=t.elapsed().as_micros();
   put(dir,&format!("{}-gpu.json",s.id),&json!(result))?;
   if !equal {return Err(format!("resultado_discordante_{}",s.id));}
   // Repeticiones prefijadas para observar recursos. Se distinguen de la primera
   // ejecución y se acotan por 250 ms o 1000 repeticiones, lo que ocurra antes.
   let warm=Instant::now();let mut repeated=Vec::new();
   while warm.elapsed()<Duration::from_millis(250) && repeated.len()<1000 {
    let x=stream.record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT)).map_err(err)?;
    unsafe {stream.launch_builder(&function).arg(&a).arg(&b).arg(&mut c).arg(&s.filas).arg(&s.interior).arg(&s.columnas).launch(LaunchConfig::for_num_elems(s.filas*s.columnas)).map_err(err)?;}
    let y=stream.record_event(Some(sys::CUevent_flags::CU_EVENT_DEFAULT)).map_err(err)?;y.synchronize().map_err(err)?;
    repeated.push(x.elapsed_ms(&y).map_err(err)?);
   }
   let warm_wall=warm.elapsed().as_micros();
   let result_warm=stream.clone_dtoh(&c).map_err(err)?;stream.synchronize().map_err(err)?;
   put(dir,&format!("{}-gpu-repetido.json",s.id),&json!(result_warm))?;
   if result_warm!=reference {return Err(format!("resultado_repetido_discordante_{}",s.id));}
   let r=json!({"id":s.id,"uuid":selected.uuid,"igualdad_exacta":true,"elementos":reference.len(),"admisión_us":admission,"referencia_cpu_us":reference_us,"asignacion_y_envio_us":upload,"calculo_cuda_ms":kernel_ms,"calculo_sincronizado_us":kernel_wall,"recuperacion_us":download,"gpu_total_primera_us":whole_us,"contraste_us":comparison,"bytes_entrada":4*(s.a.len()+s.b.len()),"bytes_salida":4*reference.len(),"repeticiones_cuda_ms":repeated,"repeticiones_total_us":warm_wall,"contraste_repetido":true});
   mon.event("fin_caso",r.clone())?;reports.push(r);
  }
  Ok(json!({"casos":reports,"calculo":"seis_casos_exactos","duracion_us":global.elapsed().as_micros(),"inferencia":false,"integracion_productiva_arbitro_director":false}))
 })();
 let _=tx.send(());let observed=observer.join().map_err(|_|"hilo_gpu_interrumpido".to_string())?;
 observed?;computation
}
fn manifest(dir:&Path)->R<Value>{
 let mut rows=Vec::new();
 for entry in fs::read_dir(dir).map_err(err)?{let entry=entry.map_err(err)?;let name=entry.file_name().into_string().map_err(|_|"nombre_no_utf8")?;
  if name=="MANIFIESTO.json" {continue;}if !entry.file_type().map_err(err)?.is_file(){return Err("subdirectorio_no_previsto".into());}
  let b=fs::read(entry.path()).map_err(err)?;rows.push(json!({"archivo":name,"bytes":b.len(),"sha256":sha(&b)}));
 } rows.sort_by_key(|v|v["archivo"].as_str().unwrap().to_owned());Ok(json!(rows))
}
fn verify(dir:&Path)->R<Value>{
 let m:Value=serde_json::from_slice(&fs::read(dir.join("MANIFIESTO.json")).map_err(err)?).map_err(err)?;
 if manifest(dir)?!=m {return Err("manifiesto_discordante".into());}
 let rows=instrumentacion::records(&dir.join("telemetria.jsonl"))?;
 let log=instrumentacion::verify(&dir.join("telemetria.jsonl"))?;
 let report:Value=serde_json::from_slice(&fs::read(dir.join("RESULTADO.json")).map_err(err)?).map_err(err)?;
 if report["error"]!=Value::Null{return Ok(json!({"integridad":"conforme","calculo":"no_concluido","informe":report,"telemetria":log}));}
 let identity:Value=serde_json::from_slice(&fs::read(dir.join("identidad.json")).map_err(err)?).map_err(err)?;
 let selected=&identity["seleccionado"]["uuid"];
 let samples:Vec<_>=rows.iter().filter(|r|r["tipo"]=="muestra_gpu").collect();
 if samples.is_empty() || samples.iter().any(|r|&r["datos"]["uuid"]!=selected){return Err("identidad_observacion_ausente_o_discordante".into());}
 let mut complete=0;
 for s in casos(){
  let actual=leer(&fs::read(dir.join(format!("{}-solicitud.json",s.id))).map_err(err)?)?;
  if serde_json::to_value(&actual).map_err(err)?!=json!(s){return Err("entrada_modificada".into());}
  let reference=referencia(&actual)?;
  for kind in ["referencia","gpu","gpu-repetido"]{let out:Vec<i32>=serde_json::from_slice(&fs::read(dir.join(format!("{}-{kind}.json",s.id))).map_err(err)?).map_err(err)?;if out!=reference{return Err("cotejo_numerico_discordante".into());}}
  let end:Vec<_>=rows.iter().filter(|r|r["tipo"]=="fin_caso" && r["datos"]["id"]==s.id).collect();
  if end.len()!=1 || &end[0]["datos"]["uuid"]!=selected || end[0]["datos"]["calculo_cuda_ms"].as_f64().is_none(){return Err("prueba_gpu_incompleta".into());}complete+=1;
 }
 let fails=rows.iter().filter(|r|r["tipo"]=="fallo_medicion"||r["tipo"]=="fallo_medicion_gpu").count();
 let missing=samples.iter().filter(|r|r["datos"]["memoria"]["valor"].is_null()||r["datos"]["utilizacion"]["valor"].is_null()).count();
 let process_samples=samples.iter().filter(|r|r["datos"]["proceso_propio"]["valor"].as_array().is_some_and(|p|!p.is_empty())).count();
 let gap=samples.windows(2).filter_map(|v|Some(v[1]["transcurrido_ms"].as_u64()?-v[0]["transcurrido_ms"].as_u64()?)).max();
 Ok(json!({"integridad":"conforme","casos_exactos":complete,"muestras_gpu":samples.len(),"intervalo_maximo_gpu_ms":gap,"fallos_observacion":fails,"muestras_sin_medidas_gpu_basicas":missing,"muestras_pid_propio_gpu":process_samples,"telemetria":log,"conformidad_calculo":complete==6,"conformidad_observacion_basica":fails==0 && missing==0 && process_samples>0,"alcance":"Adaptador experimental y cálculo; no acredita conexión productiva del Árbitro-Director ni solicitudes reales de una IA."}))
}
fn run(dir:&Path)->R<Value>{
 fs::create_dir(dir).map_err(err)?;
 let mon=Arc::new(Monitor::start_bounded(dir,55)?);
 mon.event("protocolo",json!({"inicio_unix_ms":utc_ms(),"operacion":OPERACION,"casos":6,"repeticiones_maximas":1000,"repeticiones_plazo_ms":250,"inferencia":false,"cpu_sustitutiva":false}))?;
 let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||execute(dir,&mon))).map_err(|_|"fallo_no_recuperable_del_controlador".to_string()).and_then(|v|v);
 let report=match result {Ok(v)=>json!({"error":null,"resultado":v}),Err(e)=>json!({"error":e,"resultado":null})};
 mon.event("resultado",report.clone())?;
 Arc::try_unwrap(mon).map_err(|_|"observador_no_cerrado")?.finish()?;
 put(dir,"RESULTADO.json",&report)?;put(dir,"MANIFIESTO.json",&manifest(dir)?)?;
 let check=verify(dir)?;
 let destination=dir.with_extension("tar.gz");
 let file=OpenOptions::new().create_new(true).write(true).open(&destination).map_err(err)?;
 let zip=flate2::write::GzEncoder::new(file,flate2::Compression::default());
 let mut archive=tar::Builder::new(zip);archive.append_dir_all("evidencias",dir).map_err(err)?;
 archive.into_inner().map_err(err)?.finish().map_err(err)?.sync_all().map_err(err)?;
 println!("Archivo: {} · SHA-256 {}",destination.display(),sha(&fs::read(&destination).map_err(err)?));
 Ok(check)
}

#[cfg(test)] mod verification_tests {
 use super::*;
 #[test] fn adversarial_verificacion_artefactos(){
  let dir=Path::new(env!("CARGO_MANIFEST_DIR")).join("evidencia-pruebas").join(format!("verificador-{}-{}",std::process::id(),utc_ms()));fs::create_dir_all(&dir).unwrap();
  let mon=Monitor::start(&dir).unwrap();
  let id="GPU-simulado-solo-prueba-local";
  put(&dir,"identidad.json",&json!({"seleccionado":{"uuid":id},"simulacion":true})).unwrap();
  for s in casos(){let reference=referencia(&s).unwrap();put(&dir,&format!("{}-solicitud.json",s.id),&json!(s)).unwrap();
   for kind in ["referencia","gpu","gpu-repetido"]{put(&dir,&format!("{}-{kind}.json",s.id),&json!(reference)).unwrap();}
   mon.event("fin_caso",json!({"id":s.id,"uuid":id,"calculo_cuda_ms":0.1,"simulacion":true})).unwrap();
  }
  mon.event("muestra_gpu",json!({"uuid":id,"memoria":{"valor":{}},"utilizacion":{"valor":{}},"proceso_propio":{"valor":[{"pid":std::process::id()}]},"simulacion":true})).unwrap();mon.finish().unwrap();
  put(&dir,"RESULTADO.json",&json!({"error":null,"simulacion":true})).unwrap();put(&dir,"MANIFIESTO.json",&manifest(&dir).unwrap()).unwrap();
  assert_eq!(verify(&dir).unwrap()["casos_exactos"],6);
  let file=dir.join("minimo-gpu.json");let original=fs::read(&file).unwrap();fs::write(&file,b"[99]").unwrap();
  assert_eq!(verify(&dir).unwrap_err(),"manifiesto_discordante");
  fs::write(dir.join("MANIFIESTO.json"),serde_json::to_vec(&manifest(&dir).unwrap()).unwrap()).unwrap();
  assert_eq!(verify(&dir).unwrap_err(),"cotejo_numerico_discordante");
  fs::write(file,original).unwrap();
  fs::write(dir.join("identidad.json"),br#"{"seleccionado":{"uuid":"GPU-otra"}}"#).unwrap();
  fs::write(dir.join("MANIFIESTO.json"),serde_json::to_vec(&manifest(&dir).unwrap()).unwrap()).unwrap();
  assert_eq!(verify(&dir).unwrap_err(),"identidad_observacion_ausente_o_discordante");
 }
}
fn main(){
 let args:Vec<_>=std::env::args().collect();
 let result=match args.get(1).map(String::as_str){
  Some("verificar") if args.len()==3=>verify(Path::new(&args[2])),
  Some("ejecutar") if args.len()==4=>{
   // Supervisor Rust: un proceso de cálculo, sin reintentos y con plazo total.
   let started=Instant::now();let exe=std::env::current_exe().unwrap();
   if sha(&fs::read(&exe).unwrap())!=args[3] {eprintln!("Huella del ejecutable discordante. Cálculo no iniciado.");std::process::exit(3);}
   let mut child=std::process::Command::new(exe).arg("calcular").arg(&args[2]).spawn().unwrap();
   loop {match child.try_wait(){Ok(Some(status))=>{std::process::exit(status.code().unwrap_or(1));},Err(e)=>{eprintln!("{e}");std::process::exit(1);},_=>{}}
    if started.elapsed()>Duration::from_secs(60){let _=child.kill();let _=child.wait();eprintln!("Plazo de 60 s agotado; no conforme.");std::process::exit(124);}thread::sleep(Duration::from_millis(100));
   }
  },
  Some("calcular") if args.len()==3=>run(Path::new(&args[2])),
  _=>Err("Uso: sv-ensayo-gpu-kaggle ejecutar DIRECTORIO SHA256_EJECUTABLE | verificar DIRECTORIO".into())
 };
 match result {Ok(v)=>{println!("{}",serde_json::to_string_pretty(&v).unwrap());if v["calculo"]=="no_concluido"{std::process::exit(2);}},Err(e)=>{eprintln!("Error conservado: {e}");std::process::exit(1);}}
}
