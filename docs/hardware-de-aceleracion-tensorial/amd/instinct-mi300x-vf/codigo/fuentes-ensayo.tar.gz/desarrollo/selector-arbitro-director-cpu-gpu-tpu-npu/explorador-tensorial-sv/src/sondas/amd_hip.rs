//! Consulta del controlador HIP. No acredita compatibilidad de una operación.
//! Puede inicializar el contexto HIP para leer memoria; no lanza cálculos.
use crate::{Acceso, Clase, Consulta, EstadoConsulta, Observacion, Sonda};
use cubecl_hip_sys as hip;
use serde::Serialize;
use std::{mem::MaybeUninit, os::raw::c_char};

pub const FUENTE: &str = "amd-hip";

#[derive(Clone, Debug, Serialize)]
pub struct DispositivoHip {
    pub indice: i32,
    pub uuid: String,
    pub nombre: String,
    pub arquitectura: String,
    pub pci: String,
    pub ancho_grupo: i32,
    pub integrada: bool,
    pub memoria_total_bytes: u64,
    pub memoria_libre_bytes: u64,
    pub version_runtime: i32,
}
impl DispositivoHip {
    pub fn observacion(&self) -> Result<Observacion, String> {
        if self.uuid.len() != 32
            || !self.uuid.bytes().all(|b| b.is_ascii_hexdigit())
            || self.uuid.bytes().all(|b| b == b'0')
            || self.nombre.trim().is_empty()
            || !self.arquitectura.starts_with("gfx")
            || self.arquitectura.len() < 6
            || !matches!(self.ancho_grupo, 32 | 64)
            || self.memoria_total_bytes == 0
            || self.memoria_libre_bytes > self.memoria_total_bytes
            || self.version_runtime <= 0
        {
            return Err("HIP devolvió una identidad, arquitectura o memoria incompleta".into());
        }
        let pci = normalizar_pci(&self.pci)?;
        Ok(Observacion {
            id: format!("amd-{}", self.uuid),
            clase: Clase::Gpu,
            nombre: self.nombre.clone(),
            acceso: Acceso::Consultable,
            memoria_total_bytes: Some(self.memoria_total_bytes),
            memoria_libre_bytes: Some(self.memoria_libre_bytes),
            interfaz: format!(
                "HIP;version={};PCI={pci};arquitectura={};grupo={};integrada={}",
                self.version_runtime, self.arquitectura, self.ancho_grupo, self.integrada
            ),
        })
    }
}

pub fn normalizar_pci(s: &str) -> Result<String, String> {
    let v: Vec<_> = s.split([':', '.']).collect();
    if v.len() != 4
        || v.iter()
            .any(|s| s.is_empty() || !s.bytes().all(|b| b.is_ascii_hexdigit()))
    {
        return Err("Dirección PCI no válida".into());
    }
    let p: Vec<u32> = v
        .iter()
        .map(|x| u32::from_str_radix(x, 16).map_err(|_| "PCI fuera de límites".to_owned()))
        .collect::<Result<_, _>>()?;
    if p[0] > 0xffff || p[1] > 0xff || p[2] > 0x1f || p[3] > 7 {
        return Err("Dirección PCI fuera de límites".into());
    }
    Ok(format!("{:04x}:{:02x}:{:02x}.{}", p[0], p[1], p[2], p[3]))
}

fn cadena(v: &[c_char]) -> Result<String, String> {
    let n = v
        .iter()
        .position(|&c| c == 0)
        .ok_or("Texto HIP sin terminación")?;
    String::from_utf8(v[..n].iter().map(|&v| v as u8).collect()).map_err(|e| e.to_string())
}
fn estado(c: hip::hipError_t, operacion: &str) -> Result<(), String> {
    if c == hip::HIP_SUCCESS {
        Ok(())
    } else {
        Err(format!("{operacion}: error HIP {c}"))
    }
}

pub fn dispositivos() -> Result<Vec<DispositivoHip>, String> {
    if !hip::is_available() {
        return Err("Bibliotecas HIP no consultables; no se acredita una GPU AMD".into());
    }
    // Los enlaces dinámicos pueden rechazar una ABI sin el símbolo requerido.
    std::panic::catch_unwind(consultar_runtime)
        .map_err(|_| "Interfaz HIP incompleta o incompatible".to_owned())?
}

fn consultar_runtime() -> Result<Vec<DispositivoHip>, String> {
    let mut cantidad = 0;
    let mut version = 0;
    let mut anterior = 0;
    // SAFETY: argumentos escribibles, de los tipos y tamaños declarados por HIP.
    unsafe {
        estado(hip::hipGetDeviceCount(&mut cantidad), "hipGetDeviceCount")?;
        estado(
            hip::hipRuntimeGetVersion(&mut version),
            "hipRuntimeGetVersion",
        )?;
        if cantidad == 0 {
            return Ok(vec![]);
        }
        estado(hip::hipGetDevice(&mut anterior), "hipGetDevice")?;
    }
    if !(1..=64).contains(&cantidad) {
        return Err("Cantidad de GPU fuera de límites".into());
    }
    let consulta = (|| {
        let mut salida = Vec::new();
        for indice in 0..cantidad {
            let mut props = MaybeUninit::uninit();
            let mut pci = [0 as c_char; 32];
            let (mut libre, mut total) = (0usize, 0usize);
            // SAFETY: estructura R0600 y buffers de capacidad conocida. Sólo se
            // leen tras comprobar el resultado de cada llamada del controlador.
            let props = unsafe {
                estado(
                    hip::hipGetDevicePropertiesR0600(props.as_mut_ptr(), indice),
                    "hipGetDevicePropertiesR0600",
                )?;
                estado(
                    hip::hipDeviceGetPCIBusId(pci.as_mut_ptr(), pci.len() as i32, indice),
                    "hipDeviceGetPCIBusId",
                )?;
                estado(hip::hipSetDevice(indice), "hipSetDevice")?;
                estado(hip::hipMemGetInfo(&mut libre, &mut total), "hipMemGetInfo")?;
                props.assume_init()
            };
            let d = DispositivoHip {
                indice,
                uuid: props
                    .uuid
                    .bytes
                    .iter()
                    .map(|b| format!("{:02x}", *b as u8))
                    .collect(),
                nombre: cadena(&props.name)?,
                arquitectura: cadena(&props.gcnArchName)?,
                pci: normalizar_pci(&cadena(&pci)?)?,
                ancho_grupo: props.warpSize,
                integrada: props.integrated != 0,
                memoria_total_bytes: total as u64,
                memoria_libre_bytes: libre as u64,
                version_runtime: version,
            };
            d.observacion()?;
            salida.push(d);
        }
        Ok(salida)
    })();
    // SAFETY: restaura el dispositivo previamente consultado en el mismo hilo.
    unsafe {
        estado(
            hip::hipSetDevice(anterior),
            "Restauración de dispositivo HIP",
        )?;
    }
    consulta
}

pub struct AmdHip;
impl Sonda for AmdHip {
    fn consultar(&self) -> Consulta {
        match dispositivos().and_then(|ds| {
            ds.iter()
                .map(DispositivoHip::observacion)
                .collect::<Result<Vec<_>, _>>()
        }) {
            Ok(observaciones) => Consulta {
                observaciones,
                ..Consulta::nueva(FUENTE)
            },
            Err(e) => Consulta::fallo(FUENTE, EstadoConsulta::NoDisponible, e),
        }
    }
}

#[cfg(test)]
mod pruebas {
    use super::*;
    fn simulado(arquitectura: &str) -> DispositivoHip {
        DispositivoHip {
            indice: 0,
            uuid: "1234567890abcdef1234567890abcdef".into(),
            nombre: "Dispositivo simulado".into(),
            arquitectura: arquitectura.into(),
            pci: "00000000:41:00.0".into(),
            ancho_grupo: 64,
            integrada: false,
            memoria_total_bytes: 1024,
            memoria_libre_bytes: 512,
            version_runtime: 10010000,
        }
    }
    #[test]
    fn arquitecturas_no_intercambiables() {
        let cdna = simulado("gfx942:sramecc+:xnack-").observacion().unwrap();
        let mut rdna = simulado("gfx1151");
        rdna.ancho_grupo = 32;
        rdna.integrada = true;
        assert_ne!(
            cdna.huella_identidad(),
            rdna.observacion().unwrap().huella_identidad()
        );
    }
    #[test]
    fn mismo_modelo_distintos_dispositivos() {
        let a = simulado("gfx942");
        let mut b = a.clone();
        b.uuid = "fedcba0987654321fedcba0987654321".into();
        b.pci = "0000:42:00.0".into();
        assert_ne!(a.observacion().unwrap().id, b.observacion().unwrap().id);
    }
    #[test]
    fn memoria_variable_no_altera_identidad() {
        let a = simulado("gfx942");
        let mut b = a.clone();
        b.memoria_libre_bytes = 0;
        assert_eq!(
            a.observacion().unwrap().huella_identidad(),
            b.observacion().unwrap().huella_identidad()
        );
        b.memoria_libre_bytes = 1025;
        assert!(b.observacion().is_err());
    }
    #[test]
    fn identidad_incompleta_no_admitida() {
        let mut d = simulado("gfx942");
        d.uuid = "0".repeat(32);
        assert!(d.observacion().is_err());
        d = simulado("desconocida");
        assert!(d.observacion().is_err());
        d = simulado("gfx942");
        d.ancho_grupo = 0;
        assert!(d.observacion().is_err());
    }
    #[test]
    fn pci_y_texto_se_acotan() {
        assert_eq!(normalizar_pci("00000000:0A:00.0").unwrap(), "0000:0a:00.0");
        for p in ["../41:00.0", "0000:aa:ff.9", "0000:100:00.0", "0000::00.0"] {
            assert!(normalizar_pci(p).is_err());
        }
        assert!(cadena(&[65 as c_char; 8]).is_err());
        assert_eq!(cadena(&[65 as c_char, 0]).unwrap(), "A");
    }
}
