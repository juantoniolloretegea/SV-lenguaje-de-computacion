mod calculo;
mod medicion;
use calculo::Gpu;
use cubecl::config::{CubeClRuntimeConfig, RuntimeConfig};
use explorador::{
    Explorador, Inventario,
    enlace::EvidenciaAdaptador,
    sondas::{
        Cpu, Sistema,
        amd_hip::{self, AmdHip},
    },
};
use selector::{Capacidad, Carga, Clase, Cobertura, Destino, Politica};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    fs::{self, OpenOptions},
    io::Write,
    path::Path,
    time::Instant,
};
use sv_ensayo_gpu_kaggle::{R, Solicitud, casos, referencia, validar};

const VIGENCIA: u64 = 30_000;
const MARGEN: u64 = 64 * 1024 * 1024;
fn sha(b: &[u8]) -> String {
    format!("{:x}", Sha256::digest(b))
}
fn err(e: impl std::fmt::Display) -> String {
    e.to_string()
}
fn guardar(dir: &Path, nombre: &str, v: &Value) -> R<()> {
    let mut f = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(dir.join(nombre))
        .map_err(err)?;
    f.write_all(&serde_json::to_vec_pretty(v).map_err(err)?)
        .and_then(|_| f.sync_all())
        .map_err(err)
}
fn destino(id: &str) -> Destino {
    Destino {
        servidor: "sv-ensayo-amd".into(),
        dispositivo: id.into(),
        adaptador_revision: sha(include_bytes!("calculo.rs")),
    }
}
fn carga(s: &Solicitud) -> Carga {
    Carga {
        contrato: s.operacion.clone(),
        revision: sha(include_bytes!("calculo.rs")),
        perfil: "i32-exacto-sesion-inicializada/v1".into(),
        dimensiones: vec![s.filas as usize, s.interior as usize, s.columnas as usize],
    }
}
fn solicitud(s: &Solicitud, modo: &str) -> selector::Solicitud {
    selector::Solicitud {
        id: format!("{}-{modo}", s.id),
        carga: carga(s),
        memoria_adicional_bytes: validar(s).unwrap(),
        margen_bytes: MARGEN,
        residencia_obligatoria: None,
    }
}
fn politica(modo: &str, gpu: &str) -> Politica {
    let ids = match modo {
        "cpu" => vec!["cpu-anfitrion"],
        "gpu" => vec![gpu],
        _ => vec!["cpu-anfitrion", gpu],
    };
    Politica {
        revision: format!("amd-{modo}/v1"),
        destinos_permitidos: ids.into_iter().map(destino).collect(),
        preferencia: vec![Clase::Cpu, Clase::Gpu],
        clase_obligatoria: None,
        vigencia_ms: VIGENCIA,
        comparar_estimaciones: true,
    }
}
fn inventario(e: &Explorador) -> R<Inventario> {
    e.explorar(&[&Cpu, &AmdHip, &Sistema])
}
fn mediana(v: &mut [u64]) -> u64 {
    v.sort_unstable();
    v[v.len() / 2]
}

fn operacion(dir: &Path, id: &str, s: &Solicitud, g: &Gpu, gpu: bool) -> R<Value> {
    let registro = medicion::Muestreo::iniciar(&g.dispositivo.pci)?;
    let antes = medicion::cpu()?;
    let lanzamientos = g.contador();
    let inicio = Instant::now();
    let (salida, tiempos) = if gpu {
        g.calcular(s)?
    } else {
        let salida = calculo::cpu(s)?;
        (
            salida,
            json!({"total_us":inicio.elapsed().as_micros() as u64,"gpu_eventos_ns":null,"lanzamientos_gpu":0}),
        )
    };
    let despues = medicion::cpu()?;
    let muestras = registro.terminar()?;
    if salida != referencia(s)? {
        return Err(format!("Discordancia numérica en {id}"));
    }
    let cantidad = g.contador() - lanzamientos;
    if cantidad != usize::from(gpu) {
        return Err("Desvío del número de operaciones GPU".into());
    }
    let valor = json!({"id":id,"caso":s.id,"destino":if gpu {g.dispositivo.observacion()?.id} else {"cpu-anfitrion".into()},
        "entrada":s,"salida":salida,"exactitud":true,"tiempos":tiempos,
        "cpu_antes":antes,"cpu_despues":despues,"muestreo":muestras,"lanzamientos_gpu_observados":cantidad});
    guardar(dir, &format!("{id}.json"), &valor)?;
    Ok(valor)
}

fn ejecutar(dir: &Path) -> R<Value> {
    let e = Explorador::nuevo();
    let inicial = inventario(&e)?;
    guardar(
        dir,
        "INVENTARIO-INICIAL.json",
        &serde_json::to_value(&inicial).map_err(err)?,
    )?;
    let ds = amd_hip::dispositivos()?;
    if ds.len() != 1
        || !ds[0].nombre.contains("MI300X")
        || ds[0].arquitectura.split(':').next() != Some("gfx942")
        || ds[0].integrada
    {
        return Err(
            "El protocolo exige una MI300X gfx942 discreta; no se sustituye por otro dispositivo"
                .into(),
        );
    }
    let identidad = ds[0].observacion()?.id;
    let pci = &ds[0].pci;
    let sys = inicial
        .consultas()
        .iter()
        .find(|c| c.fuente == "linux-pci")
        .ok_or("Inventario PCI ausente")?;
    let observado = sys
        .observaciones
        .iter()
        .find(|o| &o.id == pci)
        .ok_or("HIP no se corresponde con dispositivo PCI observado")?;
    if !observado.nombre.starts_with("PCI 1002:") {
        return Err("Fabricante PCI no corresponde a AMD".into());
    }
    guardar(
        dir,
        "DISPOSITIVO.json",
        &serde_json::to_value(&ds[0]).map_err(err)?,
    )?;
    let inicio_contexto = Instant::now();
    let g = Gpu::nueva(ds[0].clone())?;
    let contexto_us = inicio_contexto.elapsed().as_micros();
    let mut decisiones = Vec::new();
    let mut rechazos = Vec::new();
    let mut total_lanzamientos = 0;
    for s in casos() {
        // La primera ejecución incluye compilación y no determina rendimiento estable.
        operacion(dir, &format!("{}-primera-gpu", s.id), &s, &g, true)?;
        total_lanzamientos += 1;
        let mut tc = Vec::new();
        let mut tg = Vec::new();
        for repeticion in 0..5 {
            for gpu in if repeticion % 2 == 0 {
                [false, true]
            } else {
                [true, false]
            } {
                let v = operacion(
                    dir,
                    &format!(
                        "{}-calibracion-{}-{repeticion}",
                        s.id,
                        if gpu { "gpu" } else { "cpu" }
                    ),
                    &s,
                    &g,
                    gpu,
                )?;
                if gpu {
                    tg.push(v["tiempos"]["total_us"].as_u64().unwrap());
                    total_lanzamientos += 1;
                } else {
                    tc.push(v["tiempos"]["total_us"].as_u64().unwrap());
                }
            }
        }
        let (mc, mg) = (mediana(&mut tc), mediana(&mut tg));
        let i = inventario(&e)?;
        let mut capacidades = Vec::new();
        for (id, fuente, tiempo) in [
            ("cpu-anfitrion", "cpu-sistema", mc),
            (identidad.as_str(), amd_hip::FUENTE, mg),
        ] {
            capacidades.push(e.recibir_capacidad(
                &i,
                EvidenciaAdaptador {
                    fuente: fuente.into(),
                    identidad: id.into(),
                    destino: destino(id),
                    capacidad: Capacidad {
                        carga: carga(&s),
                        cobertura: Cobertura::Completa,
                        evidencia: format!("{};cinco-resultados-exactos;mediana-us={tiempo}", s.id),
                        estimacion_total_us: Some(tiempo),
                    },
                    contrastada_ms: e.ahora_ms(),
                    vigencia_ms: VIGENCIA,
                },
            )?);
        }
        for modo in ["cpu", "gpu", "automatico"] {
            let i = inventario(&e)?;
            let seleccion = e.seleccionar(
                &i,
                &capacidades,
                solicitud(&s, modo),
                politica(modo, &identidad),
            )?;
            let elegido = seleccion.decision().destino.dispositivo.clone();
            let esperado = match modo {
                "cpu" => "cpu-anfitrion",
                "gpu" => identidad.as_str(),
                _ => {
                    if mg < mc {
                        identidad.as_str()
                    } else {
                        "cpu-anfitrion"
                    }
                }
            };
            if elegido != esperado {
                return Err("Selector discordante con política y medidas".into());
            }
            let v = e.ejecutar_revalidado_con_inventario(&[&Cpu,&AmdHip,&Sistema],&capacidades,seleccion,|d,actual| {
                guardar(dir,&format!("{}-{modo}-inventario.json",s.id),&serde_json::to_value(actual).map_err(err)?)?;
                let v = operacion(dir,&format!("{}-{modo}",s.id),&s,&g,d.clase==Clase::Gpu)?;
                Ok(json!({"caso":s.id,"modo":modo,"destino":d.destino.dispositivo,"criterio":format!("{:?}",d.criterio),
                    "estimacion_cpu_us":mc,"estimacion_gpu_us":mg,"medicion_us":v["tiempos"]["total_us"]}))
            })?;
            total_lanzamientos += usize::from(elegido == identidad);
            decisiones.push(v);
        }
        let i = inventario(&e)?;
        let mut p = politica("gpu", &identidad);
        p.destinos_permitidos = vec![destino("inexistente")];
        let rechazo = e
            .seleccionar(&i, &capacidades, solicitud(&s, "negativo"), p)
            .err()
            .ok_or("Aceptó destino inexistente")?;
        rechazos.push(json!({"caso":s.id,"control":"destino_inexistente","motivo":rechazo}));
        let mut s_grande = solicitud(&s, "memoria");
        s_grande.memoria_adicional_bytes = u64::MAX;
        let rechazo = e
            .seleccionar(&i, &capacidades, s_grande, politica("gpu", &identidad))
            .err()
            .ok_or("Aceptó memoria imposible")?;
        rechazos.push(json!({"caso":s.id,"control":"memoria_imposible","motivo":rechazo}));
    }
    if total_lanzamientos != g.contador() {
        return Err("Lanzamientos sin atribución".into());
    }
    guardar(dir, "DECISIONES.json", &json!(decisiones))?;
    guardar(dir, "RECHAZOS.json", &json!(rechazos))?;
    let mut operaciones = 0;
    let mut telemetrias_incompletas = 0;
    for entrada in fs::read_dir(dir).map_err(err)? {
        let p = entrada.map_err(err)?.path();
        if p.extension().is_some_and(|x| x == "json") {
            let v: Value = serde_json::from_slice(&fs::read(p).map_err(err)?).map_err(err)?;
            if let Some(m) = v.get("muestreo") {
                operaciones += 1;
                telemetrias_incompletas += usize::from(m["completa"] != true);
            }
        }
    }
    if operaciones != 84 {
        return Err("Registro de operaciones incompleto".into());
    }
    let fuentes = fs::read_to_string(dir.join("COMPILACION.log")).map_err(err)?;
    if !fuentes.contains("amdgpu_kernel") || !fuentes.contains("amdgcn") {
        return Err("No se conservó representación LLVM AMDGPU verificable".into());
    }
    guardar(
        dir,
        "BIBLIOTECAS.json",
        &json!({"mapas":fs::read_to_string("/proc/self/maps").map_err(err)?}),
    )?;
    Ok(
        json!({"estado":if telemetrias_incompletas==0 {"conforme"} else {"telemetria_parcial"},
        "calculo_conforme":true,"seleccion_conforme":true,"operaciones":operaciones,
        "operaciones_con_telemetria_incompleta":telemetrias_incompletas,
        "alcance":"Seis operaciones matriciales; no acredita inferencia de modelo ni otra arquitectura",
        "casos":6,"decisiones":18,"rechazos":12,"lanzamientos_gpu":g.contador(),"contexto_inicial_us":contexto_us,
        "compilacion":"Rust-CubeCL-LLVM-AMDGPU","codigo_sha256":sha(include_bytes!("calculo.rs")),
        "selector_sha256":sha(include_bytes!("../../src/lib.rs")),"compilacion_log_sha256":sha(fuentes.as_bytes())}),
    )
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let resultado = match args.get(1).map(String::as_str) {
        Some("--inspeccionar") if args.len() == 2 => inventario(&Explorador::nuevo())
            .map(|i| println!("{}", serde_json::to_string_pretty(&i).unwrap())),
        Some("--ejecutar") if args.len() == 3 => preparar_y_ejecutar(Path::new(&args[2])),
        _ => Err("Uso: --inspeccionar | --ejecutar DIRECTORIO_NUEVO".into()),
    };
    if let Err(e) = resultado {
        eprintln!("{e}");
        std::process::exit(1);
    }
}
fn preparar_y_ejecutar(dir: &Path) -> R<()> {
    fs::create_dir(dir).map_err(err)?;
    let dir = fs::canonicalize(dir).map_err(err)?;
    let mut config = CubeClRuntimeConfig::default();
    config.environment.path = cubecl::config::cache::CacheConfig::Directory(dir.join("cache"));
    config.compilation.logger.level = cubecl::config::compilation::CompilationLogLevel::Full;
    config.compilation.logger.file = Some(dir.join("COMPILACION.log"));
    CubeClRuntimeConfig::set(config);
    let resultado = std::panic::catch_unwind(|| ejecutar(&dir))
        .unwrap_or_else(|_| Err("El motor rechazó la ejecución; sin sustitución por CPU".into()));
    let resumen = match &resultado {
        Ok(v) => v.clone(),
        Err(e) => json!({"estado":"incompleto","error":e}),
    };
    guardar(&dir, "RESULTADO.json", &resumen)?;
    let mut ficheros = Vec::new();
    for entrada in fs::read_dir(&dir).map_err(err)? {
        let e = entrada.map_err(err)?;
        if e.file_type().map_err(err)?.is_file() {
            let b = fs::read(e.path()).map_err(err)?;
            ficheros.push(
                json!({"archivo":e.file_name().to_string_lossy(),"bytes":b.len(),"sha256":sha(&b)}),
            );
        }
    }
    guardar(
        &dir,
        "INTEGRIDAD.json",
        &json!({"ficheros":ficheros,"cache_excluida":true}),
    )?;
    println!("{}", serde_json::to_string_pretty(&resumen).unwrap());
    resultado.map(|_| ())
}
