use serde_json::{Value, json};
use std::{
    fs,
    sync::mpsc,
    thread,
    time::{Duration, Instant},
};
use sv_ensayo_gpu_kaggle::R;
pub fn cpu() -> R<Value> {
    let mut sys = sysinfo::System::new();
    let pid = sysinfo::Pid::from_u32(std::process::id());
    sys.refresh_processes_specifics(
        sysinfo::ProcessesToUpdate::Some(&[pid]),
        true,
        sysinfo::ProcessRefreshKind::nothing()
            .without_tasks()
            .with_cpu()
            .with_memory(),
    );
    let p = sys.process(pid).ok_or("CPU no observable")?;
    Ok(
        json!({"pid":pid.as_u32(),"inicio_unix_s":p.start_time(),"cpu_acumulada_ms":p.accumulated_cpu_time(),
        "rss_bytes":p.memory(),"alcance":"Proceso completo, incluido control y observación; resolución del sistema operativo"}),
    )
}
fn lectura(path: String) -> Value {
    match fs::read_to_string(&path)
        .map_err(|e| e.to_string())
        .and_then(|s| s.trim().parse::<u64>().map_err(|e| e.to_string()))
    {
        Ok(v) => json!({"valor":v,"fuente":path,"error":null}),
        Err(e) => json!({"valor":null,"fuente":path,"error":e}),
    }
}
fn muestra(pci: &str, origen: Instant) -> Value {
    json!({"instante_us":origen.elapsed().as_micros() as u64,
        "cpu":cpu().map_or_else(|e|json!({"error":e}),|v|v),
        "gpu_ocupacion_porcentaje":lectura(format!("/sys/bus/pci/devices/{pci}/gpu_busy_percent")),
        "gpu_memoria_usada_bytes":lectura(format!("/sys/bus/pci/devices/{pci}/mem_info_vram_used")),
        "alcance_gpu":"Dispositivo completo; no atribuye consumo ajeno a la operación"})
}
pub struct Muestreo {
    fin: mpsc::Sender<()>,
    hilo: Option<thread::JoinHandle<Vec<Value>>>,
}
impl Muestreo {
    pub fn iniciar(pci: &str) -> R<Self> {
        let pci = explorador::sondas::amd_hip::normalizar_pci(pci)?;
        let (fin, rx) = mpsc::channel();
        let (listo, inicio) = mpsc::channel();
        let hilo = thread::spawn(move || {
            let origen = Instant::now();
            let mut v = vec![muestra(&pci, origen)];
            let _ = listo.send(());
            loop {
                match rx.recv_timeout(Duration::from_millis(25)) {
                    Err(mpsc::RecvTimeoutError::Timeout) => v.push(muestra(&pci, origen)),
                    _ => {
                        v.push(muestra(&pci, origen));
                        break;
                    }
                }
            }
            v
        });
        inicio.recv().map_err(|e| e.to_string())?;
        Ok(Self {
            fin,
            hilo: Some(hilo),
        })
    }
    pub fn terminar(mut self) -> R<Value> {
        let _ = self.fin.send(());
        let v = self
            .hilo
            .take()
            .unwrap()
            .join()
            .map_err(|_| "Muestreo interrumpido")?;
        let max = v
            .windows(2)
            .map(|p| p[1]["instante_us"].as_u64().unwrap() - p[0]["instante_us"].as_u64().unwrap())
            .max();
        let completa = v.iter().all(|m| {
            m["cpu"]["cpu_acumulada_ms"].is_u64()
                && m["gpu_ocupacion_porcentaje"]["valor"].is_u64()
                && m["gpu_memoria_usada_bytes"]["valor"].is_u64()
        });
        Ok(json!({"completa":completa,"intervalo_objetivo_us":25000,
            "intervalo_maximo_observado_us":max,"muestras":v}))
    }
}
impl Drop for Muestreo {
    fn drop(&mut self) {
        let _ = self.fin.send(());
        if let Some(h) = self.hilo.take() {
            let _ = h.join();
        }
    }
}
