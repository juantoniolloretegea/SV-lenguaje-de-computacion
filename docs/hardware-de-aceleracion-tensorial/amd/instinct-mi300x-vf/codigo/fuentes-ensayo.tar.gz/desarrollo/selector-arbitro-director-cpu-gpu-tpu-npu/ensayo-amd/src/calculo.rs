use cubecl::{Device, device::AmdDevice, prelude::*};
use cubecl_hip::compiler::HipBackend;
use explorador::sondas::amd_hip::{DispositivoHip, dispositivos};
use serde_json::{Value, json};
use std::{
    sync::{Arc, Mutex},
    time::Instant,
};
use sv_ensayo_gpu_kaggle::{R, Solicitud, validar};

/// Operación íntegramente descrita en Rust; sin generación de HIP C++.
#[cube(launch)]
fn producto(a: &[i32], b: &[i32], c: &mut [i32], m: u32, k: u32, n: u32) {
    let pos = ABSOLUTE_POS;
    if pos < (m * n) as usize {
        let fila = pos / n as usize;
        let columna = pos % n as usize;
        let mut suma = 0i32;
        for q in 0..k as usize {
            suma += a[fila * k as usize + q] * b[q * n as usize + columna];
        }
        c[pos] = suma;
    }
}

#[derive(Default)]
pub struct Lanzamientos(pub Mutex<Vec<String>>);
impl cubecl::logging::LaunchObserver for Lanzamientos {
    fn launched(&self, nombre: &'static str) {
        self.0
            .lock()
            .expect("Registro de lanzamientos")
            .push(nombre.into());
    }
}

pub struct Gpu {
    pub dispositivo: DispositivoHip,
    client: Client,
    pub lanzamientos: Arc<Lanzamientos>,
    _observador: cubecl::logging::LaunchObservation,
}
impl Gpu {
    pub fn nueva(dispositivo: DispositivoHip) -> R<Self> {
        if HipBackend::default() != HipBackend::Llvm {
            return Err("Modalidad HIP C++ rechazada; se exige LLVM".into());
        }
        let client = Device::Hip(AmdDevice::new(dispositivo.indice as usize)).client();
        let identidad = &client.properties().identity;
        let pci = identidad
            .physical
            .as_ref()
            .and_then(|p| p.pci_address.as_ref())
            .ok_or("CubeCL no proporciona identidad PCI")?
            .to_string();
        if explorador::sondas::amd_hip::normalizar_pci(&pci)? != dispositivo.pci
            || identidad.name != dispositivo.nombre
            || identidad.fingerprint != format!("hip-kernel_{}", dispositivo.arquitectura)
        {
            return Err("Discrepancia entre Explorador y contexto de cálculo".into());
        }
        let lanzamientos = Arc::new(Lanzamientos::default());
        let observador = cubecl::logging::LaunchObservation::new(lanzamientos.clone());
        Ok(Self {
            dispositivo,
            client,
            lanzamientos,
            _observador: observador,
        })
    }
    pub fn contador(&self) -> usize {
        self.lanzamientos.0.lock().unwrap().len()
    }
    pub fn revalidar(&self) -> R<()> {
        let ds = dispositivos()?;
        let d = ds
            .iter()
            .find(|d| d.indice == self.dispositivo.indice)
            .ok_or("GPU retirada")?;
        if d.observacion()?.huella_identidad() != self.dispositivo.observacion()?.huella_identidad()
        {
            return Err("Identidad GPU modificada".into());
        }
        Ok(())
    }
    pub fn calcular(&self, s: &Solicitud) -> R<(Vec<i32>, Value)> {
        let inicio = Instant::now();
        validar(s)?;
        self.revalidar()?;
        let revalidacion_us = inicio.elapsed().as_micros() as u64;
        let reloj_entrada = Instant::now();
        let antes = self.contador();
        let client = &self.client;
        let a = client.create_from_slice(i32::as_bytes(&s.a));
        let b = client.create_from_slice(i32::as_bytes(&s.b));
        let len = (s.filas * s.columnas) as usize;
        let c = client.empty(len * 4);
        cubecl::future::reader::read_sync(client.sync())
            .map_err(|e| format!("Sincronización de entrada: {e:?}"))?;
        let entrada_us = reloj_entrada.elapsed().as_micros() as u64;
        let reloj_calculo = Instant::now();
        let ventana = client
            .profile_start()
            .map_err(|e| format!("Inicio de medición GPU: {e:?}"))?;
        // SAFETY: validar limita dimensiones, tamaños y acumulación; los buffers
        // tienen exactamente las longitudes declaradas. Cada hilo escribe un índice.
        unsafe {
            producto::launch(
                client,
                CubeCount::Static((len as u32).div_ceil(256), 1, 1),
                CubeDim::new_1d(256),
                BufferArg::from_raw_parts(a, s.a.len()),
                BufferArg::from_raw_parts(b, s.b.len()),
                BufferArg::from_raw_parts(c.clone(), len),
                s.filas,
                s.interior,
                s.columnas,
            );
        }
        let medicion = client
            .profile_end(ventana)
            .map_err(|e| format!("Fin de medición GPU: {e:?}"))?;
        let metodo = medicion.timing_method().to_string();
        if metodo != "device" {
            return Err("No se obtuvo temporización del dispositivo".into());
        }
        let ticks = cubecl::future::reader::read_sync(medicion.resolve())
            .ok_or("Duración GPU no observada")?;
        let gpu_ns = ticks.duration().as_nanos() as u64;
        let calculo_sincronizado_us = reloj_calculo.elapsed().as_micros() as u64;
        let reloj_salida = Instant::now();
        let bytes = client
            .read_one(c)
            .map_err(|e| format!("Recuperación del resultado: {e:?}"))?;
        let out = i32::from_bytes(&bytes).to_vec();
        let salida_us = reloj_salida.elapsed().as_micros() as u64;
        let total_us = inicio.elapsed().as_micros() as u64;
        if self.contador() != antes + 1 {
            return Err("Número de lanzamientos GPU discordante".into());
        }
        let nombre = self.lanzamientos.0.lock().unwrap().last().cloned();
        Ok((
            out,
            json!({"total_us":total_us,"revalidacion_us":revalidacion_us,"preparacion_y_transferencia_us":entrada_us,
            "calculo_y_espera_anfitrion_us":calculo_sincronizado_us,"recuperacion_us":salida_us,
            "gpu_eventos_ns":gpu_ns,"metodo_gpu":metodo,"lanzamientos_gpu":1,
            "funcion":nombre,"uuid":self.dispositivo.uuid,"pci":self.dispositivo.pci,
            "arquitectura":self.dispositivo.arquitectura,"compilacion":"LLVM-AMDGPU"}),
        ))
    }
}

pub fn cpu(s: &Solicitud) -> R<Vec<i32>> {
    validar(s)?;
    let (m, k, n) = (s.filas as usize, s.interior as usize, s.columnas as usize);
    let mut c = vec![0; m * n];
    for i in 0..m {
        for q in 0..k {
            for j in 0..n {
                c[i * n + j] += s.a[i * k + q] * s.b[q * n + j];
            }
        }
    }
    Ok(c)
}

#[cfg(test)]
mod pruebas {
    #[test]
    fn seis_casos_cpu_con_referencia_independiente() {
        for s in sv_ensayo_gpu_kaggle::casos() {
            assert_eq!(
                super::cpu(&s).unwrap(),
                sv_ensayo_gpu_kaggle::referencia(&s).unwrap()
            );
        }
    }
    #[test]
    fn modalidad_cpp_no_habilitada() {
        assert_eq!(super::HipBackend::default(), super::HipBackend::Llvm);
    }
}
