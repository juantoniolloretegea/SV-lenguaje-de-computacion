//! Cotejo posterior de la copia recuperada. No consulta un dispositivo.
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
type R<T> = Result<T, String>;
fn comprobar_cobertura(ops: &[Value], rechazos: &[Value]) -> R<()> {
    let casos = [
        ("minimo", [1, 1, 1]),
        ("rectangular", [2, 3, 2]),
        ("signos", [31, 47, 65]),
        ("ceros", [16, 16, 16]),
    ];
    if ops.len() != casos.len() || rechazos.len() != casos.len() * 3 {
        return Err("Cobertura incompleta".into());
    }
    for (caso, dimensiones) in casos {
        let correspondientes: Vec<_> = ops.iter().filter(|o| o["caso"] == caso).collect();
        if correspondientes.len() != 1 || correspondientes[0]["dimensiones"] != json!(dimensiones) {
            return Err(format!("Caso ausente, repetido o discordante: {caso}"));
        }
        for clase in ["Gpu", "Tpu", "Npu"] {
            if rechazos.iter().filter(|r| r["caso"] == caso && r["clase"] == clase).count() != 1 {
                return Err(format!("Rechazo ausente o repetido: {caso}/{clase}"));
            }
        }
    }
    Ok(())
}
fn sha(b: &[u8]) -> String {
    format!("{:x}", Sha256::digest(b))
}
fn cargar(p: &Path) -> R<Value> {
    serde_json::from_slice(&fs::read(p).map_err(|e| e.to_string())?).map_err(|e| e.to_string())
}
fn comprobar(dir: &Path, ejecutable: &Path) -> R<Value> {
    let integridad = cargar(&dir.join("INTEGRIDAD.json"))?;
    let entradas = integridad["archivos"]
        .as_array()
        .ok_or("Manifiesto sin archivos")?;
    let esperados = [
        "INVENTARIO-INICIAL.json",
        "IDENTIDAD-ANDROID.json",
        "INVENTARIO-FINAL.json",
        "RESULTADOS.json",
    ];
    if entradas.len() != esperados.len() {
        return Err("Manifiesto incompleto".into());
    }
    for nombre in esperados {
        let coincidencias: Vec<_> = entradas
            .iter()
            .filter(|v| v["archivo"].as_str() == Some(nombre))
            .collect();
        if coincidencias.len() != 1 {
            return Err("Entrada ausente o repetida".into());
        }
        let v = coincidencias[0];
        let bytes = fs::read(dir.join(nombre)).map_err(|e| e.to_string())?;
        if v["bytes"].as_u64() != Some(bytes.len() as u64)
            || v["sha256"].as_str() != Some(sha(&bytes).as_str())
        {
            return Err(format!("Identidad discordante: {nombre}"));
        }
    }
    let identidad_android=cargar(&dir.join("IDENTIDAD-ANDROID.json"))?;
    let binario=fs::read(ejecutable).map_err(|e|e.to_string())?;
    if identidad_android["ejecutable_sha256"].as_str()!=Some(sha(&binario).as_str()) {
        return Err("El ejecutable físico no corresponde al archivo preparado".into());
    }
    let resultados = cargar(&dir.join("RESULTADOS.json"))?;
    for nombre in [
        "gpu_calculo_probado",
        "npu_calculo_probado",
        "modelo_ia_ejecutado",
    ] {
        if resultados[nombre].as_bool() != Some(false) {
            return Err(format!("Alcance discordante: {nombre}"));
        }
    }
    let ops = resultados["operaciones_cpu"]
        .as_array()
        .ok_or("Sin operaciones")?;
    if ops.len() != 4 {
        return Err("Cantidad de operaciones incorrecta".into());
    }
    for op in ops {
        let dims = op["dimensiones"].as_array().ok_or("Sin dimensiones")?;
        if dims.len() != 3 {
            return Err("Dimensiones incorrectas".into());
        }
        let mut d = [0usize; 3];
        for (j, v) in dims.iter().enumerate() {
            d[j] = v
                .as_u64()
                .filter(|n| (1..=512).contains(n))
                .ok_or("Dimensión fuera de límite")? as usize;
        }
        let [m, k, n] = d;
        let leer = |campo: &str| -> R<Vec<i64>> {
            op[campo]
                .as_array()
                .ok_or("Falta vector")?
                .iter()
                .map(|v| v.as_i64().ok_or("Valor no entero".into()))
                .collect()
        };
        let a = leer("entrada_a")?;
        let b = leer("entrada_b")?;
        let salida = leer("salida")?;
        let referencia = leer("referencia")?;
        if a.len() != m * k
            || b.len() != k * n
            || salida.len() != m * n
            || referencia.len() != m * n
        {
            return Err("Longitudes discordantes".into());
        }
        if a.iter().chain(&b).any(|v| !(-1024..=1024).contains(v)) {
            return Err("Entrada fuera de límite".into());
        }
        let mut calculada = Vec::new();
        for fila in a.chunks_exact(k) {
            for col in 0..n {
                calculada.push(
                    fila.iter()
                        .zip(b.iter().skip(col).step_by(n))
                        .map(|(x, y)| x * y)
                        .sum::<i64>(),
                );
            }
        }
        if calculada != salida || calculada != referencia || op["exacto"].as_bool() != Some(true) {
            return Err("Cálculo discordante".into());
        }
        let t = &op["telemetria"];
        for campo in [
            "tiempo_calculo_anfitrion_ns",
            "cpu_usuario_us",
            "cpu_sistema_us",
        ] {
            if t[campo].as_u64().is_none() {
                return Err(format!("Medición ausente: {campo}"));
            }
        }
        for campo in [
            "llamadas_propias_calculo_gpu",
            "llamadas_propias_calculo_npu",
        ] {
            if t[campo].as_u64() != Some(0) {
                return Err("Lanzamiento no previsto".into());
            }
        }
        if !t["gpu_tiempo_dispositivo_ns"].is_null() || !t["npu_tiempo_dispositivo_ns"].is_null() {
            return Err("Tiempo de acelerador sin ejecución".into());
        }
    }
    let rechazos = resultados["rechazos_sin_ejecucion"]
        .as_array()
        .ok_or("Sin rechazos")?;
    comprobar_cobertura(ops, rechazos)?;
    if rechazos.len() != 12
        || rechazos.iter().any(|r| {
            r["calculo_ejecutado"].as_bool() != Some(false) || r["rechazo"].as_str().is_none()
        })
    {
        return Err("Rechazos incompletos".into());
    }
    let inicial = cargar(&dir.join("INVENTARIO-INICIAL.json"))?;
    let final_i = cargar(&dir.join("INVENTARIO-FINAL.json"))?;
    let identidad = |inv: &Value| -> R<Vec<Value>> {
        let mut identidad = Vec::new();
        for consulta in inv["consultas"].as_array().ok_or("Consultas ausentes")? {
            for o in consulta["observaciones"]
                .as_array()
                .ok_or("Observaciones ausentes")?
            {
                identidad.push(json!({"fuente":consulta["fuente"],"id":o["id"],"clase":o["clase"],"nombre":o["nombre"],"interfaz":o["interfaz"]}));
            }
        }
        Ok(identidad)
    };
    let identidad_inicial = identidad(&inicial)?;
    if identidad_inicial != identidad(&final_i)? {
        return Err("Identidad modificada durante la ejecución".into());
    }
    for op in ops {
        if identidad(&op["telemetria"]["inventario_revalidado"])?!=identidad_inicial {
            return Err("Identidad discordante en una revalidación".into());
        }
    }
    Ok(
        json!({"cotejo":"conforme","archivos":4,"operaciones_cpu_exactas":ops.len(),"rechazos":rechazos.len(),"identidad_estable":true,"dispositivos_observados":identidad_inicial,
        "alcance":"Verificación local de integridad y resultados; no es atestación externa ni prueba de cálculo GPU/NPU"}),
    )
}
fn main() -> R<()> {
    let a: Vec<_> = std::env::args().collect();
    if a.len() != 3 {
        return Err("Uso: cotejar_android DIRECTORIO EJECUTABLE_ENVIADO".into());
    }
    println!(
        "{}",
        serde_json::to_string_pretty(&comprobar(Path::new(&a[1]),Path::new(&a[2]))?).unwrap()
    );
    Ok(())
}

#[cfg(test)]
mod pruebas {
    use super::*;
    fn cobertura() -> (Vec<Value>, Vec<Value>) {
        let casos = [("minimo",[1,1,1]),("rectangular",[2,3,2]),("signos",[31,47,65]),("ceros",[16,16,16])];
        let ops = casos.iter().map(|(c,d)|json!({"caso":c,"dimensiones":d})).collect();
        let rechazos = casos.iter().flat_map(|(c,_)| ["Gpu","Tpu","Npu"].map(|clase|json!({"caso":c,"clase":clase}))).collect();
        (ops,rechazos)
    }
    #[test]
    fn casos_duplicados_no_sustituyen_cobertura() {
        let (mut ops, rechazos) = cobertura();
        assert!(comprobar_cobertura(&ops,&rechazos).is_ok());
        ops[3]=ops[0].clone();
        assert!(comprobar_cobertura(&ops,&rechazos).is_err());
    }
    #[test]
    fn clase_repetida_no_sustituye_otro_acelerador() {
        let (ops,mut rechazos) = cobertura();
        rechazos[2]=rechazos[1].clone();
        assert!(comprobar_cobertura(&ops,&rechazos).is_err());
    }
}
