use crate::Clase;

/// NNAPI identifica un acelerador dedicado, pero no distingue NPU de DSP.
/// Su nombre comercial no sustituye una identificación de arquitectura.
pub fn clase_nnapi(tipo: i32) -> Clase {
    match tipo {
        2 => Clase::Cpu,
        3 => Clase::Gpu,
        _ => Clase::AceleradorSinClasificar,
    }
}

pub fn memoria(texto: &str, clave: &str) -> Option<u64> {
    let linea = texto
        .lines()
        .find(|l| l.split_whitespace().next() == Some(clave))?;
    let mut campos = linea.split_whitespace().skip(1);
    let valor = campos.next()?.parse::<u64>().ok()?;
    if campos.next()? != "kB" || campos.next().is_some() {
        return None;
    }
    valor.checked_mul(1024)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn acelerador_generico_no_se_convierte_en_npu() {
        for tipo in [-1, 0, 1, 4, 99] {
            assert_eq!(clase_nnapi(tipo), Clase::AceleradorSinClasificar);
        }
        assert_eq!(clase_nnapi(2), Clase::Cpu);
        assert_eq!(clase_nnapi(3), Clase::Gpu);
    }
    #[test]
    fn memoria_exige_unidad_y_rechaza_desbordamiento() {
        assert_eq!(
            memoria("MemTotal: 100 kB\nMemAvailable: 25 kB", "MemAvailable:"),
            Some(25600)
        );
        for t in [
            "MemTotal: 10 MB",
            "MemTotal: -1 kB",
            "MemTotal: 18446744073709551615 kB",
            "MemTotal: 10 kB extra",
        ] {
            assert_eq!(memoria(t, "MemTotal:"), None);
        }
        assert_eq!(memoria("MemTotal: 100 kB", "MemAvailable:"), None);
    }
}
