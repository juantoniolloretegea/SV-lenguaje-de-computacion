//! Comprobación física Android: reconocimiento, cálculo CPU y cierre de destinos
//! sin capacidad contrastada. No contiene un motor de cálculo GPU ni NPU.
#[cfg(any(target_os = "android", test))]
#[path = "soporte_android/calculo.rs"]
mod calculo;
#[cfg(target_os = "android")]
mod ensayo {
    use super::calculo::{calcular,referencia};
    use explorador_tensorial_sv::{
        enlace::EvidenciaAdaptador,
        sondas::{android, Cpu},
        Explorador,
    };
    use selector::{Capacidad, Carga, Clase, Cobertura, Destino, Politica, Solicitud};
    use serde_json::{json, Value};
    use sha2::{Digest, Sha256};
    use std::{
        fs::{self, OpenOptions},
        io::Write,
        path::Path,
        time::Instant,
    };
    type R<T> = Result<T, String>;
    fn sha(b: &[u8]) -> String {
        format!("{:x}", Sha256::digest(b))
    }
    fn guardar(dir: &Path, nombre: &str, v: &Value) -> R<()> {
        let mut f = OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(dir.join(nombre))
            .map_err(|e| e.to_string())?;
        f.write_all(&serde_json::to_vec_pretty(v).map_err(|e| e.to_string())?)
            .and_then(|_| f.sync_all())
            .map_err(|e| e.to_string())
    }
    fn tiempos_cpu() -> R<(u64, u64)> {
        let mut r = std::mem::MaybeUninit::<libc::rusage>::uninit();
        // SAFETY: salida dimensionada por libc y comprobada antes de su lectura.
        if unsafe { libc::getrusage(libc::RUSAGE_SELF, r.as_mut_ptr()) } != 0 {
            return Err(std::io::Error::last_os_error().to_string());
        }
        let r = unsafe { r.assume_init() };
        let us = |t: libc::timeval| -> R<u64> {
            let s = u64::try_from(t.tv_sec).map_err(|e| e.to_string())?;
            let u = u64::try_from(t.tv_usec).map_err(|e| e.to_string())?;
            s.checked_mul(1_000_000)
                .and_then(|v| v.checked_add(u))
                .ok_or("Tiempo desbordado".into())
        };
        Ok((us(r.ru_utime)?, us(r.ru_stime)?))
    }
    fn memoria_proceso() -> Value {
        match fs::read_to_string("/proc/self/status") {
            Ok(t) => json!(t
                .lines()
                .filter(|l| ["VmRSS:", "VmHWM:", "Threads:"]
                    .iter()
                    .any(|p| l.starts_with(p)))
                .collect::<Vec<_>>()),
            Err(e) => json!({"no_observable":e.to_string()}),
        }
    }
    fn destino() -> Destino {
        Destino {
            servidor: "sv-ensayo-android".into(),
            dispositivo: "cpu-anfitrion".into(),
            adaptador_revision: sha(include_bytes!("soporte_android/calculo.rs")),
        }
    }
    pub fn ejecutar() -> R<()> {
        let args: Vec<_> = std::env::args().collect();
        if args.len() != 2 {
            return Err("Uso: ensayo_android DIRECTORIO_NUEVO".into());
        }
        let dir = Path::new(&args[1]);
        fs::create_dir(dir).map_err(|e| e.to_string())?;
        let e = Explorador::nuevo();
        let sondas: &[&dyn explorador_tensorial_sv::Sonda] =
            &[&Cpu, &android::Vulkan, &android::Neuronal];
        let inv = e.explorar(sondas)?;
        guardar(
            dir,
            "INVENTARIO-INICIAL.json",
            &serde_json::to_value(&inv).map_err(|e| e.to_string())?,
        )?;
        guardar(
            dir,
            "IDENTIDAD-ANDROID.json",
            &json!({"propiedades":android::propiedades(),"arquitectura":std::env::consts::ARCH,
            "sistema":std::env::consts::OS,"version_fuente":sha(include_bytes!("ensayo_android.rs")),
            "calculo_fuente":sha(include_bytes!("soporte_android/calculo.rs")),
            "ejecutable_sha256":sha(&fs::read(std::env::current_exe().map_err(|e|e.to_string())?).map_err(|e|e.to_string())?),
            "alcance":"Reconocimiento por interfaces del sistema; CPU Rust; GPU y NPU sin cálculo en este ensayo"}),
        )?;
        let mut operaciones = Vec::new();
        let mut rechazos = Vec::new();
        for (nombre, m, k, n) in [
            ("minimo", 1, 1, 1),
            ("rectangular", 2, 3, 2),
            ("signos", 31, 47, 65),
            ("ceros", 16, 16, 16),
        ] {
            let gen = |len: usize, sal: i32| {
                (0..len)
                    .map(|i| {
                        if nombre == "ceros" {
                            0
                        } else {
                            ((i as i32 * 17 + sal) % 15) - 7
                        }
                    })
                    .collect::<Vec<_>>()
            };
            let a = gen(m * k, 3);
            let b = gen(k * n, 11);
            let esperada = referencia(&a, &b, m, k, n)?;
            let inicio = Instant::now();
            let contraste = calcular(&a, &b, m, k, n)?;
            let duracion = inicio.elapsed().as_micros() as u64;
            if contraste != esperada {
                return Err("Contraste CPU discordante".into());
            }
            let carga = Carga {
                contrato: "producto_matricial_i32/v1".into(),
                revision: sha(include_bytes!("soporte_android/calculo.rs")),
                perfil: "i32-exacto-android/v1".into(),
                dimensiones: vec![m, k, n],
            };
            let i = e.explorar(sondas)?;
            let capacidad = e.recibir_capacidad(
                &i,
                EvidenciaAdaptador {
                    fuente: "cpu-sistema".into(),
                    identidad: "cpu-anfitrion".into(),
                    destino: destino(),
                    capacidad: Capacidad {
                        carga: carga.clone(),
                        cobertura: Cobertura::Completa,
                        evidencia: sha(&serde_json::to_vec(&contraste).unwrap()),
                        estimacion_total_us: Some(duracion),
                    },
                    contrastada_ms: e.ahora_ms(),
                    vigencia_ms: 30000,
                },
            )?;
            let cs = [capacidad];
            let solicitud = Solicitud {
                id: nombre.into(),
                carga,
                memoria_adicional_bytes: 4 * (a.len() + b.len() + esperada.len()) as u64,
                margen_bytes: 1024 * 1024,
                residencia_obligatoria: None,
            };
            for modo in [Clase::Cpu, Clase::Gpu, Clase::Tpu, Clase::Npu] {
                let p = Politica {
                    revision: "android-comprobacion/v1".into(),
                    destinos_permitidos: vec![destino()],
                    preferencia: vec![Clase::Cpu, Clase::Gpu, Clase::Tpu, Clase::Npu],
                    clase_obligatoria: Some(modo),
                    vigencia_ms: 30000,
                    comparar_estimaciones: false,
                };
                let seleccion = e.seleccionar(&i, &cs, solicitud.clone(), p);
                if modo != Clase::Cpu {
                    match seleccion {Err(error)=>rechazos.push(json!({"caso":nombre,"clase":format!("{modo:?}"),"rechazo":error,"calculo_ejecutado":false})),
                        Ok(_)=>return Err("El Selector admitió un acelerador no contrastado".into())}
                    continue;
                }
                let seleccion = seleccion?;
                let decision = format!("{:?}", seleccion.decision());
                {
                    let repeticion = 0;
                    let (resultado,medicion)=e.ejecutar_revalidado_con_inventario(sondas,&cs,seleccion,|d,actual| {
                        if d.destino!=destino()||d.clase!=Clase::Cpu{return Err("Destino CPU discordante".into())}
                        let memoria_antes=memoria_proceso();let antes=tiempos_cpu()?;let reloj=Instant::now();
                        let out=calcular(&a,&b,m,k,n)?;
                        let completo=reloj.elapsed().as_nanos() as u64;let despues=tiempos_cpu()?;
                        Ok((out,json!({"inventario_revalidado":actual,"tiempo_calculo_anfitrion_ns":completo,
                            "cpu_usuario_us":despues.0.checked_sub(antes.0),"cpu_sistema_us":despues.1.checked_sub(antes.1),
                            "fuente_cpu":"getrusage/RUSAGE_SELF; resolución microsegundos",
                            "gpu_tiempo_dispositivo_ns":null,"npu_tiempo_dispositivo_ns":null,
                            "llamadas_propias_calculo_gpu":0,"llamadas_propias_calculo_npu":0,
                            "ocupacion_global_gpu_npu":"no medida; cero llamadas propias no implica dispositivo inactivo",
                            "memoria_antes":memoria_antes,"memoria_despues":memoria_proceso()})))
                    })?;
                    if resultado != esperada {
                        return Err("Resultado ejecutado distinto de la referencia".into());
                    }
                    operaciones.push(json!({"caso":nombre,"repeticion":repeticion,"dimensiones":[m,k,n],"entrada_a":a,"entrada_b":b,
                        "salida":resultado,"referencia":esperada,"exacto":true,"decision":decision,"telemetria":medicion}));
                }
            }
        }
        let final_i = e.explorar(sondas)?;
        guardar(
            dir,
            "INVENTARIO-FINAL.json",
            &serde_json::to_value(final_i).unwrap(),
        )?;
        guardar(
            dir,
            "RESULTADOS.json",
            &json!({"operaciones_cpu":operaciones,"rechazos_sin_ejecucion":rechazos,
            "gpu_calculo_probado":false,"npu_calculo_probado":false,"modelo_ia_ejecutado":false,
            "alcance":"Identificación Android y CPU; no acredita capacidad GPU/NPU ni semántica del SV"}),
        )?;
        let mut huellas = Vec::new();
        for nombre in [
            "INVENTARIO-INICIAL.json",
            "IDENTIDAD-ANDROID.json",
            "INVENTARIO-FINAL.json",
            "RESULTADOS.json",
        ] {
            let b = fs::read(dir.join(nombre)).map_err(|e| e.to_string())?;
            huellas.push(json!({"archivo":nombre,"bytes":b.len(),"sha256":sha(&b)}));
        }
        guardar(dir, "INTEGRIDAD.json", &json!({"archivos":huellas}))?;
        println!(
            "{}",
            json!({"resultado":"completo","directorio":dir,"operaciones_cpu_exactas":4,"rechazos":12})
        );
        Ok(())
    }
}
#[cfg(target_os = "android")]
fn main() -> Result<(), String> {
    ensayo::ejecutar()
}
#[cfg(not(target_os = "android"))]
fn main() {
    eprintln!("Este ensayo físico requiere Android; no se simula el dispositivo.");
    std::process::exit(2);
}
