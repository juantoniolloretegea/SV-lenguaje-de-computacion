//! Producto entero acotado y referencia independiente para el ensayo Android.
fn validar(a:&[i32],b:&[i32],m:usize,k:usize,n:usize)->Result<(),String>{
    if [m,k,n].iter().any(|&x|x==0||x>512){return Err("Dimensiones fuera de límite".into())}
    if a.len()!=m*k||b.len()!=k*n{return Err("Longitudes discordantes".into())}
    if a.iter().chain(b).any(|v|!(-1024..=1024).contains(v)){return Err("Magnitud fuera de límite".into())} Ok(())
}
pub fn calcular(a:&[i32],b:&[i32],m:usize,k:usize,n:usize)->Result<Vec<i32>,String>{
    validar(a,b,m,k,n)?;
    let mut c=vec![0;m*n];
    for i in 0..m {for q in 0..k {for j in 0..n {c[i*n+j]+=a[i*k+q]*b[q*n+j];}}} Ok(c)
}
pub fn referencia(a:&[i32],b:&[i32],m:usize,k:usize,n:usize)->Result<Vec<i32>,String>{
    validar(a,b,m,k,n)?;
    a.chunks_exact(k).flat_map(|fila|(0..n).map(move|j|fila.iter().enumerate()
        .map(|(q,&v)|i64::from(v)*i64::from(b[q*n+j])).sum::<i64>()))
        .map(|v|i32::try_from(v).map_err(|e|e.to_string())).collect()
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]fn resultado_conocido(){
        let a=[1,2,3,-1,0,2];let b=[2,1,0,-1,3,4];
        assert_eq!(calcular(&a,&b,2,3,2).unwrap(),vec![11,11,4,7]);
        assert_eq!(referencia(&a,&b,2,3,2).unwrap(),vec![11,11,4,7]);
    }
    #[test]fn dimensiones_y_magnitud_no_permitidas(){
        assert!(calcular(&[1],&[1],0,1,1).is_err());
        assert!(calcular(&[1],&[1],usize::MAX,1,1).is_err());
        assert!(calcular(&[1025],&[1],1,1,1).is_err());
        assert!(calcular(&[],&[1],1,1,1).is_err());
    }
    #[test]fn extremo_representable_y_referencia(){
        let a=vec![1024;512];let b=vec![-1024;512];
        let valor=calcular(&a,&b,1,512,1).unwrap();
        assert_eq!(valor,vec![-536870912]);assert_eq!(valor,referencia(&a,&b,1,512,1).unwrap());
    }
}
