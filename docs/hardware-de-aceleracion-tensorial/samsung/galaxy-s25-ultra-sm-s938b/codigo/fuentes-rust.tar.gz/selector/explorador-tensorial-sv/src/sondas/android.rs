//! Consultas Android ARM64. Las interfaces consultadas no acreditan cálculo.
use super::android_datos::{clase_nnapi, memoria};
use crate::*;
use ash::{vk, Entry};
use std::{
    collections::BTreeMap,
    ffi::{c_char, c_void, CStr, CString},
};

unsafe extern "C" {
    fn __system_property_get(name: *const c_char, value: *mut c_char) -> i32;
}

pub fn propiedad(nombre: &str) -> Result<String, String> {
    let nombre = CString::new(nombre).map_err(|e| e.to_string())?;
    // Android PROP_VALUE_MAX = 92; esta función sólo consulta propiedades ro.*
    let mut valor = [0 as c_char; 92];
    // SAFETY: nombre terminado en cero; capacidad conforme al ABI público.
    let n = unsafe { __system_property_get(nombre.as_ptr(), valor.as_mut_ptr()) };
    if n <= 0 || n as usize >= valor.len() {
        return Err("Propiedad ausente o longitud inválida".into());
    }
    let bytes: Vec<_> = valor[..n as usize].iter().map(|&b| b as u8).collect();
    String::from_utf8(bytes).map_err(|e| e.to_string())
}

pub fn propiedades() -> BTreeMap<String, Result<String, String>> {
    [
        "ro.product.manufacturer",
        "ro.product.model",
        "ro.product.device",
        "ro.soc.manufacturer",
        "ro.soc.model",
        "ro.board.platform",
        "ro.hardware",
        "ro.product.cpu.abi",
        "ro.build.version.release",
        "ro.build.version.sdk",
    ]
    .into_iter()
    .map(|n| (n.into(), propiedad(n)))
    .collect()
}

pub fn cpu() -> Consulta {
    let mut c = Consulta::nueva("cpu-sistema");
    let modelo = propiedad("ro.soc.model");
    let nombre = match modelo {
        Ok(v) => format!("CPU del SoC {v}"),
        Err(e) => {
            c.estado = EstadoConsulta::Parcial;
            c.incidencias.push(e);
            "CPU Android; modelo no observable".into()
        }
    };
    let mem = std::fs::read_to_string("/proc/meminfo");
    let (total, libre) = match mem {
        Ok(t) => (memoria(&t, "MemTotal:"), memoria(&t, "MemAvailable:")),
        Err(e) => {
            c.incidencias.push(format!("Memoria: {e}"));
            (None, None)
        }
    };
    if total.is_none() || libre.is_none() {
        c.estado = EstadoConsulta::Parcial;
    }
    let presentes = std::fs::read_to_string("/sys/devices/system/cpu/present")
        .map(|s| s.trim().to_owned())
        .unwrap_or_else(|_| "no observable".into());
    c.observaciones.push(Observacion {
        id: "cpu-anfitrion".into(),
        clase: Clase::Cpu,
        nombre,
        acceso: Acceso::Consultable,
        memoria_total_bytes: total,
        memoria_libre_bytes: libre,
        interfaz: format!(
            "Android;ro.soc.model;cpu_presentes={presentes};ABI={}",
            std::env::consts::ARCH
        ),
    });
    c
}

pub struct Vulkan;
impl Sonda for Vulkan {
    fn consultar(&self) -> Consulta {
        match vulkan() {
            Ok(c) => c,
            Err(e) => Consulta::fallo("android-vulkan", EstadoConsulta::NoDisponible, e),
        }
    }
}

fn vulkan() -> Result<Consulta, String> {
    // SAFETY: cargador del sistema Android; los símbolos se conservan hasta
    // destruir la instancia. No se instala ni se ejecuta código de terceros.
    let entry = unsafe { Entry::load_from("libvulkan.so") }.map_err(|e| e.to_string())?;
    let app = vk::ApplicationInfo::default().api_version(vk::API_VERSION_1_1);
    let info = vk::InstanceCreateInfo::default().application_info(&app);
    let instance = unsafe { entry.create_instance(&info, None) }
        .map_err(|e| format!("Instancia Vulkan: {e:?}"))?;
    let resultado = (|| {
        let ds = unsafe { instance.enumerate_physical_devices() }
            .map_err(|e| format!("Enumeración Vulkan: {e:?}"))?;
        let mut c = Consulta::nueva("android-vulkan");
        for (indice, d) in ds.into_iter().enumerate() {
            let mut ident = vk::PhysicalDeviceIDProperties::default();
            let mut p = vk::PhysicalDeviceProperties2::default().push_next(&mut ident);
            unsafe { instance.get_physical_device_properties2(d, &mut p) };
            let p = p.properties;
            let nombre = unsafe { CStr::from_ptr(p.device_name.as_ptr()) }
                .to_str()
                .map_err(|e| e.to_string())?
                .to_owned();
            let uuid = ident
                .device_uuid
                .iter()
                .map(|b| format!("{b:02x}"))
                .collect::<String>();
            let mem = unsafe { instance.get_physical_device_memory_properties(d) };
            let total = mem.memory_heaps[..mem.memory_heap_count as usize]
                .iter()
                .filter(|m| m.flags.contains(vk::MemoryHeapFlags::DEVICE_LOCAL))
                .map(|m| m.size)
                .sum::<u64>();
            let clase = match p.device_type {
                vk::PhysicalDeviceType::INTEGRATED_GPU
                | vk::PhysicalDeviceType::DISCRETE_GPU
                | vk::PhysicalDeviceType::VIRTUAL_GPU => Clase::Gpu,
                vk::PhysicalDeviceType::CPU => Clase::Cpu,
                _ => Clase::AceleradorSinClasificar,
            };
            // El tamaño del heap no es memoria libre. No se inventa disponibilidad.
            c.observaciones.push(Observacion {
                id:format!("vulkan-{uuid}-{indice}"),clase,nombre,acceso:Acceso::Consultable,
                memoria_total_bytes:Some(total),memoria_libre_bytes:None,
                interfaz:format!("Vulkan;vendor={:x};device={:x};driver={};api={};tipo={:?};UUID={uuid};indice={indice}",p.vendor_id,p.device_id,p.driver_version,p.api_version,p.device_type),
            });
        }
        Ok(c)
    })();
    unsafe { instance.destroy_instance(None) };
    resultado
}

pub struct Neuronal;
impl Sonda for Neuronal {
    fn consultar(&self) -> Consulta {
        match neural() {
            Ok(c) => c,
            Err(e) => Consulta::fallo("android-nnapi", EstadoConsulta::NoDisponible, e),
        }
    }
}

fn neural() -> Result<Consulta, String> {
    type Cuenta = unsafe extern "C" fn(*mut u32) -> i32;
    type Obtener = unsafe extern "C" fn(u32, *mut *mut c_void) -> i32;
    type Texto = unsafe extern "C" fn(*const c_void, *mut *const c_char) -> i32;
    type Tipo = unsafe extern "C" fn(*const c_void, *mut i32) -> i32;
    type Nivel = unsafe extern "C" fn(*const c_void, *mut i64) -> i32;
    fn ok(r: i32) -> Result<(), String> {
        if r == 0 {
            Ok(())
        } else {
            Err(format!("NNAPI código {r}"))
        }
    }
    // SAFETY: ABI público del NDK. Biblioteca viva durante todas las consultas;
    // punteros comprobados y salidas inicializadas. Ninguna función de cálculo.
    unsafe {
        let lib = libloading::Library::new("libneuralnetworks.so").map_err(|e| e.to_string())?;
        let cuenta: libloading::Symbol<Cuenta> = lib
            .get(b"ANeuralNetworks_getDeviceCount\0")
            .map_err(|e| e.to_string())?;
        let obtener: libloading::Symbol<Obtener> = lib
            .get(b"ANeuralNetworks_getDevice\0")
            .map_err(|e| e.to_string())?;
        let nombre: libloading::Symbol<Texto> = lib
            .get(b"ANeuralNetworksDevice_getName\0")
            .map_err(|e| e.to_string())?;
        let version: libloading::Symbol<Texto> = lib
            .get(b"ANeuralNetworksDevice_getVersion\0")
            .map_err(|e| e.to_string())?;
        let tipo: libloading::Symbol<Tipo> = lib
            .get(b"ANeuralNetworksDevice_getType\0")
            .map_err(|e| e.to_string())?;
        let nivel: libloading::Symbol<Nivel> = lib
            .get(b"ANeuralNetworksDevice_getFeatureLevel\0")
            .map_err(|e| e.to_string())?;
        let mut n = 0;
        ok(cuenta(&mut n))?;
        if n > 256 {
            return Err("Número NNAPI fuera de límite".into());
        }
        let mut c = Consulta::nueva("android-nnapi");
        for i in 0..n {
            let resultado: Result<Observacion, String> = (|| {
                let mut d = std::ptr::null_mut();
                ok(obtener(i, &mut d))?;
                if d.is_null() {
                    return Err("Dispositivo NNAPI nulo".into());
                }
                let mut nom = std::ptr::null();
                let mut ver = std::ptr::null();
                let mut t = 0;
                let mut f = 0;
                ok(nombre(d, &mut nom))?;
                ok(version(d, &mut ver))?;
                ok(tipo(d, &mut t))?;
                ok(nivel(d, &mut f))?;
                if nom.is_null() || ver.is_null() {
                    return Err("Identidad NNAPI nula".into());
                }
                let nom = CStr::from_ptr(nom)
                    .to_str()
                    .map_err(|e| e.to_string())?
                    .to_owned();
                let ver = CStr::from_ptr(ver).to_str().map_err(|e| e.to_string())?;
                Ok(Observacion {
                    id: format!("nnapi-{i}-{nom}"),
                    clase: clase_nnapi(t),
                    nombre: nom,
                    acceso: Acceso::Consultable,
                    memoria_total_bytes: None,
                    memoria_libre_bytes: None,
                    interfaz: format!(
                        "NNAPI;tipo={t};version={ver};nivel={f};consulta_sin_ejecucion"
                    ),
                })
            })();
            match resultado {
                Ok(o) => c.observaciones.push(o),
                Err(e) => {
                    c.estado = EstadoConsulta::Parcial;
                    c.incidencias.push(format!("Dispositivo {i}: {e}"));
                }
            }
        }
        Ok(c)
    }
}
