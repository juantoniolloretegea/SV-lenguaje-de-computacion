//! Lecturas de sólo consulta. No instalan controladores ni ejecutan modelos.
use crate::*;
#[cfg(feature = "hip")]
pub mod amd_hip;
#[cfg(target_os = "android")]
pub mod android;
#[cfg(any(target_os = "android", test))]
mod android_datos;
#[cfg(any(not(target_os = "android"), test))]
fn nombre_cpu(marcas: impl IntoIterator<Item = String>) -> Option<String> {
    let marcas: BTreeSet<_> = marcas
        .into_iter()
        .map(|marca| marca.trim().to_owned())
        .filter(|marca| !marca.is_empty())
        .collect();
    (!marcas.is_empty()).then(|| marcas.into_iter().collect::<Vec<_>>().join("; "))
}
#[cfg(test)]
mod pruebas_denominacion_cpu {
    use super::nombre_cpu;
    #[test]
    fn denominaciones_vacias_no_acreditan_un_modelo() {
        assert_eq!(nombre_cpu(vec![String::new(); 12]), None);
        assert_eq!(nombre_cpu(vec![" \t ".into()]), None);
    }
    #[test]
    fn conserva_solo_denominaciones_observadas() {
        assert_eq!(
            nombre_cpu(vec![
                " ".into(),
                "Procesador A".into(),
                "Procesador A".into()
            ]),
            Some("Procesador A".into())
        );
    }
}
pub struct Cpu;
impl Sonda for Cpu {
    fn consultar(&self) -> Consulta {
        #[cfg(target_os = "android")]
        {
            android::cpu()
        }
        #[cfg(not(target_os = "android"))]
        {
            let mut s = sysinfo::System::new();
            s.refresh_cpu_list(sysinfo::CpuRefreshKind::new());
            s.refresh_memory();
            let mut c = Consulta::nueva("cpu-sistema");
            if s.cpus().is_empty() {
                return Consulta::fallo(
                    "cpu-sistema",
                    EstadoConsulta::NoDisponible,
                    "CPU no observable".into(),
                );
            }
            let mut identidad = nombre_cpu(s.cpus().iter().map(|p| p.brand().to_string()));
            let mut fuente_nombre = "sysinfo";
            #[cfg(windows)]
            if identidad.is_none() {
                match cpu_windows::denominacion() {
                    Ok(nombre) => {
                        identidad = Some(nombre);
                        fuente_nombre = "RegistroHardware/ProcessorNameString";
                    }
                    Err(error) => c.incidencias.push(error),
                }
            }
            let nombre = identidad
            .unwrap_or_else(|| {
                c.estado = EstadoConsulta::Parcial;
                c.incidencias.push(
                    "La biblioteca no proporciona la denominación de la CPU; su modelo físico no queda identificado".into(),
                );
                "CPU anfitriona; denominación no observable".into()
            });
            c.observaciones.push(Observacion {
                id: "cpu-anfitrion".into(),
                clase: Clase::Cpu,
                nombre,
                acceso: Acceso::Consultable,
                memoria_total_bytes: Some(s.total_memory()),
                memoria_libre_bytes: Some(s.available_memory()),
                interfaz: format!(
                    "sysinfo/0.32.1;{};denominacion={fuente_nombre};hilos={}",
                    std::env::consts::OS,
                    std::thread::available_parallelism()
                        .map(|n| n.get())
                        .unwrap_or(0)
                ),
            });
            c
        }
    }
}

pub struct Nvidia;
impl Sonda for Nvidia {
    fn consultar(&self) -> Consulta {
        let mut c = Consulta::nueva("nvidia-nvml");
        let nv = match nvml_wrapper::Nvml::init() {
            Ok(v) => v,
            Err(e) => {
                return Consulta::fallo(
                    &c.fuente,
                    EstadoConsulta::NoDisponible,
                    format!("NVML no consultable: {e}"),
                )
            }
        };
        let cantidad = match nv.device_count() {
            Ok(n) => n,
            Err(e) => {
                return Consulta::fallo(
                    &c.fuente,
                    EstadoConsulta::NoDisponible,
                    format!("Enumeración NVML: {e}"),
                )
            }
        };
        let version = nv
            .sys_driver_version()
            .unwrap_or_else(|_| "version-no-consultable".into());
        for n in 0..cantidad {
            let consultar = || -> Result<Observacion, nvml_wrapper::error::NvmlError> {
                let d = nv.device_by_index(n)?;
                let m = d.memory_info()?;
                Ok(Observacion {
                    id: d.uuid()?,
                    clase: Clase::Gpu,
                    nombre: d.name()?,
                    acceso: Acceso::Consultable,
                    memoria_total_bytes: Some(m.total),
                    memoria_libre_bytes: Some(m.free),
                    interfaz: format!("NVML;controlador={version};PCI={}", d.pci_info()?.bus_id),
                })
            };
            match consultar() {
                Ok(o) => c.observaciones.push(o),
                Err(e) => {
                    c.estado = EstadoConsulta::Parcial;
                    c.incidencias.push(format!("Dispositivo {n}: {e}"));
                }
            }
        }
        c
    }
}

/// Inventario del sistema operativo, distinto de la consulta del motor de cálculo.
pub struct Sistema;
impl Sonda for Sistema {
    fn consultar(&self) -> Consulta {
        #[cfg(windows)]
        {
            windows::consultar()
        }
        #[cfg(target_os = "linux")]
        {
            linux::consultar()
        }
        #[cfg(not(any(windows, target_os = "linux")))]
        {
            Consulta::fallo(
                "sistema",
                EstadoConsulta::NoAplicable,
                "Sistema sin realización de inventario".into(),
            )
        }
    }
}
#[cfg(windows)]
mod cpu_windows;
#[cfg(windows)]
mod dxcore;
#[cfg(target_os = "linux")]
mod linux;
#[cfg(windows)]
mod windows;

/// Clasificación declarada por DXCore; no acredita operaciones numéricas.
pub struct DxCore;
impl Sonda for DxCore {
    fn consultar(&self) -> Consulta {
        #[cfg(windows)]
        {
            dxcore::consultar()
        }
        #[cfg(not(windows))]
        {
            Consulta::fallo(
                "windows-dxcore",
                EstadoConsulta::NoAplicable,
                "DXCore sólo se consulta en Windows".into(),
            )
        }
    }
}

/// Frontera tipada para una interfaz PJRT ya abierta por el adaptador autorizado.
/// Implementar este rasgo requiere consultar el cliente; no es entrada JSON.
pub trait ConsultaTpu {
    fn plataforma(&self) -> Result<String, String>;
    fn dispositivos(&self) -> Result<Vec<Observacion>, String>;
}
pub struct Tpu<'a>(pub &'a dyn ConsultaTpu);
/// El ejecutable de inventario no recibe por sí solo un cliente PJRT autorizado.
pub struct SinClienteTpu;
impl Sonda for SinClienteTpu {
    fn consultar(&self) -> Consulta {
        Consulta::fallo(
            "tpu-pjrt",
            EstadoConsulta::NoAplicable,
            "Cliente PJRT no suministrado por un adaptador; hardware TPU no evaluado".into(),
        )
    }
}
#[cfg(feature = "pjrt")]
pub mod pjrt;
impl Sonda for Tpu<'_> {
    fn consultar(&self) -> Consulta {
        let fuente = "tpu-pjrt";
        match self.0.plataforma() {
            Ok(p) if p.eq_ignore_ascii_case("tpu") => {}
            Ok(_) => {
                return Consulta::fallo(
                    fuente,
                    EstadoConsulta::NoDisponible,
                    "PJRT identifica otra plataforma".into(),
                )
            }
            Err(e) => return Consulta::fallo(fuente, EstadoConsulta::NoDisponible, e),
        }
        match self.0.dispositivos() {
            Ok(ds) if ds.iter().all(|d| d.clase == Clase::Tpu) => Consulta {
                observaciones: ds,
                ..Consulta::nueva(fuente)
            },
            Ok(_) => Consulta::fallo(
                fuente,
                EstadoConsulta::NoDisponible,
                "Clase PJRT discordante".into(),
            ),
            Err(e) => Consulta::fallo(fuente, EstadoConsulta::NoDisponible, e),
        }
    }
}
