use explorador_tensorial_sv::{sondas, Explorador, Sonda};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 1 {
        return Err("Uso: explorador-tensorial-sv; inventario JSON por salida estándar".into());
    }
    let e = Explorador::nuevo();
    #[allow(unused_mut)]
    #[cfg(not(target_os = "android"))]
    let mut ss: Vec<&dyn Sonda> = vec![
        &sondas::Cpu,
        &sondas::Sistema,
        &sondas::DxCore,
        &sondas::Nvidia,
        &sondas::SinClienteTpu,
    ];
    #[cfg(target_os = "android")]
    #[allow(unused_mut)]
    let mut ss: Vec<&dyn Sonda> = vec![
        &sondas::Cpu,
        &sondas::android::Vulkan,
        &sondas::android::Neuronal,
    ];
    #[cfg(feature = "hip")]
    ss.push(&sondas::amd_hip::AmdHip);
    let i = e.explorar(&ss)?;
    println!("{}", serde_json::to_string_pretty(&i)?);
    Ok(())
}
